-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 04, 2020 at 09:06 PM
-- Server version: 10.2.27-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kidzvill_re4tau`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_table`
--

CREATE TABLE `account_table` (
  `ref` int(11) NOT NULL,
  `purpuse_id` tinyint(4) NOT NULL,
  `purpuse_type` tinyint(1) NOT NULL,
  `amount` int(11) DEFAULT 0,
  `s_note` varchar(160) DEFAULT 'N/A',
  `serviceToken` bigint(20) DEFAULT NULL,
  `userID` int(11) DEFAULT NULL,
  `DOC` datetime DEFAULT current_timestamp(),
  `DOM` datetime DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_table`
--

INSERT INTO `account_table` (`ref`, `purpuse_id`, `purpuse_type`, `amount`, `s_note`, `serviceToken`, `userID`, `DOC`, `DOM`) VALUES
(1, 2, 1, 0, 'N/A', NULL, 12, '2016-03-14 19:13:00', '2019-12-25 10:22:36');

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `actLogID` int(11) NOT NULL,
  `hotelID` int(5) NOT NULL,
  `tblName` varchar(80) NOT NULL,
  `refID` int(20) NOT NULL,
  `Activity` varchar(10) NOT NULL,
  `timeStamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `agents`
--

CREATE TABLE `agents` (
  `agent_id` int(11) NOT NULL,
  `agent_name` varchar(150) NOT NULL,
  `address` varchar(250) DEFAULT NULL,
  `contact_no` varchar(20) NOT NULL,
  `comission` int(11) NOT NULL DEFAULT 0,
  `userID` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0,
  `DOC` datetime DEFAULT current_timestamp(),
  `DOM` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agents`
--

INSERT INTO `agents` (`agent_id`, `agent_name`, `address`, `contact_no`, `comission`, `userID`, `status`, `DOC`, `DOM`) VALUES
(1, 'Nazmul', 'Laway, South Surma, Sylhet', '01675456825', 5, NULL, 0, '2015-05-01 12:05:55', '2015-05-02 11:01:07'),
(2, 'Kawser Ahmmed', 'Biani Bazar, Sylhet.', '01768245298', 8, NULL, 0, '2015-05-01 12:13:09', '2015-05-02 11:02:11');

-- --------------------------------------------------------

--
-- Table structure for table `agent_total`
--

CREATE TABLE `agent_total` (
  `agent_total_id` int(11) NOT NULL,
  `reservation_id` int(11) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT 0,
  `userID` int(11) DEFAULT NULL,
  `DOC` datetime DEFAULT current_timestamp(),
  `DOM` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agent_total`
--

INSERT INTO `agent_total` (`agent_total_id`, `reservation_id`, `agent_id`, `status`, `userID`, `DOC`, `DOM`) VALUES
(1, 1, 2, 0, 2, '2015-05-19 00:21:49', NULL),
(2, 2, 1, 0, 2, '2015-05-19 00:22:57', NULL),
(3, 3, 1, 0, 2, '2015-05-19 00:37:01', NULL),
(4, 4, 1, 0, 2, '2015-05-19 00:39:47', NULL),
(5, 5, 2, 0, 2, '2015-05-19 00:43:33', NULL),
(6, 6, 1, 0, 1, '2015-05-19 14:05:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cashbox_info`
--

CREATE TABLE `cashbox_info` (
  `cashbox_id` int(11) NOT NULL,
  `opening_cashbox` int(7) NOT NULL,
  `thousand` int(5) NOT NULL,
  `five_hundred` int(5) NOT NULL,
  `one_hundred` int(8) NOT NULL,
  `fifty` int(8) NOT NULL,
  `twenty` int(8) NOT NULL,
  `ten` int(8) NOT NULL,
  `five` int(8) NOT NULL,
  `two` int(10) NOT NULL,
  `one` int(10) NOT NULL,
  `closing_cash` int(8) NOT NULL,
  `closing_date` datetime NOT NULL,
  `not_edit_future` varchar(5) NOT NULL,
  `creator` int(10) NOT NULL,
  `DOC` timestamp NOT NULL DEFAULT current_timestamp(),
  `DOM` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cashbox_info`
--

INSERT INTO `cashbox_info` (`cashbox_id`, `opening_cashbox`, `thousand`, `five_hundred`, `one_hundred`, `fifty`, `twenty`, `ten`, `five`, `two`, `one`, `closing_cash`, `closing_date`, `not_edit_future`, `creator`, `DOC`, `DOM`) VALUES
(4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1055, '0000-00-00 00:00:00', '0', 14, '2015-06-09 07:30:52', '2020-01-01 13:42:58');

-- --------------------------------------------------------

--
-- Table structure for table `cashbox_option`
--

CREATE TABLE `cashbox_option` (
  `cashbox_id` int(11) NOT NULL,
  `cashbox_name` varchar(150) NOT NULL,
  `status` int(11) DEFAULT 0,
  `userID` int(11) DEFAULT NULL,
  `DOC` datetime DEFAULT current_timestamp(),
  `DOM` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cashbox_option`
--

INSERT INTO `cashbox_option` (`cashbox_id`, `cashbox_name`, `status`, `userID`, `DOC`, `DOM`) VALUES
(1, 'Cashbox1', 1, NULL, '2015-05-01 14:38:36', '2015-05-02 11:03:24'),
(2, 'Cashbox2', 1, NULL, '2015-05-02 11:02:47', '2015-05-02 11:03:10'),
(3, 'Cashbox 2', 0, NULL, '2015-05-02 11:03:20', NULL),
(4, 'Cashbox 1', 0, NULL, '2015-05-02 11:03:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `catering_info`
--

CREATE TABLE `catering_info` (
  `catering_id` int(11) NOT NULL,
  `item_name` varchar(80) NOT NULL,
  `store_name` varchar(10) NOT NULL,
  `stock_amount` int(8) NOT NULL,
  `unit_buy_price` int(5) NOT NULL,
  `current_use_amount` int(6) NOT NULL,
  `damage_lost` int(6) NOT NULL,
  `creator` int(8) NOT NULL,
  `catering_doc` timestamp NOT NULL DEFAULT current_timestamp(),
  `catering_dom` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `catering_info`
--

INSERT INTO `catering_info` (`catering_id`, `item_name`, `store_name`, `stock_amount`, `unit_buy_price`, `current_use_amount`, `damage_lost`, `creator`, `catering_doc`, `catering_dom`) VALUES
(1, 'New table spoon', 'Restaurant', 0, 0, 24, 0, 17, '2015-10-18 07:24:34', '2016-02-04 10:18:32'),
(2, 'Half Plate', '', 15, 60, 14, 1, 14, '2015-11-15 14:31:30', '2016-01-16 11:57:57');

-- --------------------------------------------------------

--
-- Table structure for table `catering_log`
--

CREATE TABLE `catering_log` (
  `catering_log_id` int(11) NOT NULL,
  `item_id` int(10) NOT NULL,
  `purpose` int(11) NOT NULL,
  `provider_name` varchar(80) NOT NULL,
  `quantity` int(11) NOT NULL,
  `description` varchar(200) NOT NULL,
  `creator` int(11) NOT NULL,
  `doc` timestamp NOT NULL DEFAULT current_timestamp(),
  `dom` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `ip_address` varchar(16) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_activity` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `user_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `client_info`
--

CREATE TABLE `client_info` (
  `client_id` int(11) NOT NULL,
  `name_title_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `zip_code` int(11) DEFAULT NULL,
  `country_id` int(3) DEFAULT NULL,
  `contact_no` varchar(50) NOT NULL,
  `email` varchar(250) DEFAULT NULL,
  `passport` varchar(50) DEFAULT NULL,
  `national_id` varchar(50) DEFAULT NULL,
  `is_photo` tinyint(1) DEFAULT 0,
  `comment` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0,
  `userID` int(11) DEFAULT NULL,
  `DOC` datetime DEFAULT current_timestamp(),
  `DOM` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client_info`
--

INSERT INTO `client_info` (`client_id`, `name_title_id`, `first_name`, `last_name`, `gender`, `dob`, `address`, `city`, `zip_code`, `country_id`, `contact_no`, `email`, `passport`, `national_id`, `is_photo`, `comment`, `status`, `userID`, `DOC`, `DOM`) VALUES
(1, 1, 'Nazmul', 'Hossain', 'Male', '1991-05-06', 'Laway, South surma, Sylhet.', 'Sylhet', 3100, 22, '01785624785', 'wall.mate@gmail.com', '123698745632147', '23685412368547856', 0, 'He is good programmer. He like internet service. And Polite', 0, NULL, '2015-05-03 15:09:17', '2015-05-03 18:24:11'),
(2, 1, 'Ahsan', 'Ahmmed', 'Male', '1990-05-01', 'Taltola Sylhet', 'Sylhet', 3100, 22, '01685234569', 'ahssan@gmail.com', '', '', 1, 'He is good.', 0, NULL, '2015-05-03 15:18:13', NULL),
(5, 1, 'Prodip', 'Lal', 'Male', '1991-02-07', 'Tangor Hawor Sylhet', 'Sylhet', 0, 22, '01678954562', 'pradip@gmail.com', '', '', 1, 'He is good. And Engineer. And He I awsum', 0, 1, '2015-05-03 16:10:11', '2015-05-11 15:06:18'),
(6, 0, 'Kawser Bi', 'Ahmmed', 'Male', '0000-00-00', '', '', 0, 22, '01986583245', '', '', '', 1, '', 0, NULL, '2015-05-03 18:00:38', '2015-05-03 18:58:04'),
(7, 2, 'Sahana', 'Begam', 'Female', '1998-02-04', 'Laway, South surma, Sylhet.', 'Sylhet', 3100, 22, '01852365478', 'pradip@gmail.com', '', '', 1, 'She is good. But ', 0, NULL, '2015-05-06 00:12:44', '2015-05-06 19:12:19'),
(8, 3, 'Shirina', 'Akter', 'Female', '1980-03-06', 'Tangor Hawor Sylhet', 'Sylhet', 3100, 22, '01687524868', 'wall.mate@gmail.com', '', '', 1, '', 0, NULL, '2015-05-06 00:15:13', NULL),
(9, 6, 'Sahar', 'Ahmmed', 'Male', '1980-02-08', 'Laway, South surma, Sylhet.', 'Sylhet', 3100, 22, '01715896542', 'sahar@gmail.com', '', '', 1, '', 0, 2, '2015-05-10 11:20:31', NULL),
(10, 1, 'Sahadat', 'Hossain', 'Male', '1996-11-11', 'Biani Bazar', 'Sylhet', 3175, 22, '01731874641', '', '', '', 1, 'He is Kawser Vai In My.', 0, 1, '2015-05-11 17:54:32', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `country_id` int(11) NOT NULL,
  `Name` char(52) NOT NULL DEFAULT '',
  `status` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`country_id`, `Name`, `status`) VALUES
(1, 'Aruba', 0),
(2, 'Afghanistan', 0),
(3, 'Angola', 0),
(4, 'Anguilla', 0),
(5, 'Albania', 0),
(6, 'Andorra', 0),
(7, 'Netherlands Antilles', 0),
(8, 'United Arab Emirates', 0),
(9, 'Argentina', 0),
(10, 'Armenia', 0),
(11, 'American Samoa', 0),
(12, 'Antarctica', 0),
(13, 'French Southern territories', 0),
(14, 'Antigua and Barbuda', 0),
(15, 'Australia', 0),
(16, 'Austria', 0),
(17, 'Azerbaijan', 0),
(18, 'Burundi', 0),
(19, 'Belgium', 0),
(20, 'Benin', 0),
(21, 'Burkina Faso', 0),
(22, 'Bangladesh', 0),
(23, 'Bulgaria', 0),
(24, 'Bahrain', 0),
(25, 'Bahamas', 0),
(26, 'Bosnia and Herzegovina', 0),
(27, 'Belarus', 0),
(28, 'Belize', 0),
(29, 'Bermuda', 0),
(30, 'Bolivia', 0),
(31, 'Brazil', 0),
(32, 'Barbados', 0),
(33, 'Brunei', 0),
(34, 'Bhutan', 0),
(35, 'Bouvet Island', 0),
(36, 'Botswana', 0),
(37, 'Central African Republic', 0),
(38, 'Canada', 0),
(39, 'Cocos (Keeling) Islands', 0),
(40, 'Switzerland', 0),
(41, 'Chile', 0),
(42, 'China', 0),
(43, 'Côte d’Ivoire', 0),
(44, 'Cameroon', 0),
(45, 'Congo, The Democratic Republic of the', 0),
(46, 'Congo', 0),
(47, 'Cook Islands', 0),
(48, 'Colombia', 0),
(49, 'Comoros', 0),
(50, 'Cape Verde', 0),
(51, 'Costa Rica', 0),
(52, 'Cuba', 0),
(53, 'Christmas Island', 0),
(54, 'Cayman Islands', 0),
(55, 'Cyprus', 0),
(56, 'Czech Republic', 0),
(57, 'Germany', 0),
(58, 'Djibouti', 0),
(59, 'Dominica', 0),
(60, 'Denmark', 0),
(61, 'Dominican Republic', 0),
(62, 'Algeria', 0),
(63, 'Ecuador', 0),
(64, 'Egypt', 0),
(65, 'Eritrea', 0),
(66, 'Western Sahara', 0),
(67, 'Spain', 0),
(68, 'Estonia', 0),
(69, 'Ethiopia', 0),
(70, 'Finland', 0),
(71, 'Fiji Islands', 0),
(72, 'Falkland Islands', 0),
(73, 'France', 0),
(74, 'Faroe Islands', 0),
(75, 'Micronesia, Federated States of', 0),
(76, 'Gabon', 0),
(77, 'United Kingdom', 0),
(78, 'Georgia', 0),
(79, 'Ghana', 0),
(80, 'Gibraltar', 0),
(81, 'Guinea', 0),
(82, 'Guadeloupe', 0),
(83, 'Gambia', 0),
(84, 'Guinea-Bissau', 0),
(85, 'Equatorial Guinea', 0),
(86, 'Greece', 0),
(87, 'Grenada', 0),
(88, 'Greenland', 0),
(89, 'Guatemala', 0),
(90, 'French Guiana', 0),
(91, 'Guam', 0),
(92, 'Guyana', 0),
(93, 'Hong Kong', 0),
(94, 'Heard Island and McDonald Islands', 0),
(95, 'Honduras', 0),
(96, 'Croatia', 0),
(97, 'Haiti', 0),
(98, 'Hungary', 0),
(99, 'Indonesia', 0),
(100, 'India', 0),
(101, 'British Indian Ocean Territory', 0),
(102, 'Ireland', 0),
(103, 'Iran', 0),
(104, 'Iraq', 0),
(105, 'Iceland', 0),
(106, 'Israel', 0),
(107, 'Italy', 0),
(108, 'Jamaica', 0),
(109, 'Jordan', 0),
(110, 'Japan', 0),
(111, 'Kazakstan', 0),
(112, 'Kenya', 0),
(113, 'Kyrgyzstan', 0),
(114, 'Cambodia', 0),
(115, 'Kiribati', 0),
(116, 'Saint Kitts and Nevis', 0),
(117, 'South Korea', 0),
(118, 'Kuwait', 0),
(119, 'Laos', 0),
(120, 'Lebanon', 0),
(121, 'Liberia', 0),
(122, 'Libyan Arab Jamahiriya', 0),
(123, 'Saint Lucia', 0),
(124, 'Liechtenstein', 0),
(125, 'Sri Lanka', 0),
(126, 'Lesotho', 0),
(127, 'Lithuania', 0),
(128, 'Luxembourg', 0),
(129, 'Latvia', 0),
(130, 'Macao', 0),
(131, 'Morocco', 0),
(132, 'Monaco', 0),
(133, 'Moldova', 0),
(134, 'Madagascar', 0),
(135, 'Maldives', 0),
(136, 'Mexico', 0),
(137, 'Marshall Islands', 0),
(138, 'Macedonia', 0),
(139, 'Mali', 0),
(140, 'Malta', 0),
(141, 'Myanmar', 0),
(142, 'Mongolia', 0),
(143, 'Northern Mariana Islands', 0),
(144, 'Mozambique', 0),
(145, 'Mauritania', 0),
(146, 'Montserrat', 0),
(147, 'Martinique', 0),
(148, 'Mauritius', 0),
(149, 'Malawi', 0),
(150, 'Malaysia', 0),
(151, 'Mayotte', 0),
(152, 'Namibia', 0),
(153, 'New Caledonia', 0),
(154, 'Niger', 0),
(155, 'Norfolk Island', 0),
(156, 'Nigeria', 0),
(157, 'Nicaragua', 0),
(158, 'Niue', 0),
(159, 'Netherlands', 0),
(160, 'Norway', 0),
(161, 'Nepal', 0),
(162, 'Nauru', 0),
(163, 'New Zealand', 0),
(164, 'Oman', 0),
(165, 'Pakistan', 0),
(166, 'Panama', 0),
(167, 'Pitcairn', 0),
(168, 'Peru', 0),
(169, 'Philippines', 0),
(170, 'Palau', 0),
(171, 'Papua New Guinea', 0),
(172, 'Poland', 0),
(173, 'Puerto Rico', 0),
(174, 'North Korea', 0),
(175, 'Portugal', 0),
(176, 'Paraguay', 0),
(177, 'Palestine', 0),
(178, 'French Polynesia', 0),
(179, 'Qatar', 0),
(180, 'Réunion', 0),
(181, 'Romania', 0),
(182, 'Russian Federation', 0),
(183, 'Rwanda', 0),
(184, 'Saudi Arabia', 0),
(185, 'Sudan', 0),
(186, 'Senegal', 0),
(187, 'Singapore', 0),
(188, 'South Georgia and the South Sandwich Islands', 0),
(189, 'Saint Helena', 0),
(190, 'Svalbard and Jan Mayen', 0),
(191, 'Solomon Islands', 0),
(192, 'Sierra Leone', 0),
(193, 'El Salvador', 0),
(194, 'San Marino', 0),
(195, 'Somalia', 0),
(196, 'Saint Pierre and Miquelon', 0),
(197, 'Sao Tome and Principe', 0),
(198, 'Suriname', 0),
(199, 'Slovakia', 0),
(200, 'Slovenia', 0),
(201, 'Sweden', 0),
(202, 'Swaziland', 0),
(203, 'Seychelles', 0),
(204, 'Syria', 0),
(205, 'Turks and Caicos Islands', 0),
(206, 'Chad', 0),
(207, 'Togo', 0),
(208, 'Thailand', 0),
(209, 'Tajikistan', 0),
(210, 'Tokelau', 0),
(211, 'Turkmenistan', 0),
(212, 'East Timor', 0),
(213, 'Tonga', 0),
(214, 'Trinidad and Tobago', 0),
(215, 'Tunisia', 0),
(216, 'Turkey', 0),
(217, 'Tuvalu', 0),
(218, 'Taiwan', 0),
(219, 'Tanzania', 0),
(220, 'Uganda', 0),
(221, 'Ukraine', 0),
(222, 'United States Minor Outlying Islands', 0),
(223, 'Uruguay', 0),
(224, 'United States', 0),
(225, 'Uzbekistan', 0),
(226, 'Holy See (Vatican City State)', 0),
(227, 'Saint Vincent and the Grenadines', 0),
(228, 'Venezuela', 0),
(229, 'Virgin Islands, British', 0),
(230, 'Virgin Islands, U.S.', 0),
(231, 'Vietnam', 0),
(232, 'Vanuatu', 0),
(233, 'Wallis and Futuna', 0),
(234, 'Samoa', 0),
(235, 'Yemen', 0),
(236, 'Yugoslavia', 0),
(237, 'South Africa', 0),
(238, 'Zambia', 0),
(239, 'Zimbabwe', 0);

-- --------------------------------------------------------

--
-- Table structure for table `discount_client`
--

CREATE TABLE `discount_client` (
  `discount_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `reservation_id` int(11) DEFAULT NULL,
  `discount_amount` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 0,
  `userID` int(11) DEFAULT NULL,
  `DOC` datetime DEFAULT current_timestamp(),
  `DOM` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `discount_client`
--

INSERT INTO `discount_client` (`discount_id`, `client_id`, `reservation_id`, `discount_amount`, `status`, `userID`, `DOC`, `DOM`) VALUES
(1, 5, 3, 100, 0, 2, '2015-05-19 00:37:01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employee_salary_log`
--

CREATE TABLE `employee_salary_log` (
  `salary_log_id` int(6) NOT NULL,
  `user_id` int(4) NOT NULL,
  `salary_amount` double NOT NULL,
  `extra_payment` double NOT NULL,
  `reduced_amount` double NOT NULL,
  `salary_month` char(5) NOT NULL,
  `salary_year` int(4) NOT NULL,
  `mode` char(10) NOT NULL,
  `account_table_ref_id` int(13) NOT NULL,
  `salary_doc` timestamp NOT NULL DEFAULT current_timestamp(),
  `salary_dom` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `salary_creator` int(4) NOT NULL,
  `salary_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `entertainment_info`
--

CREATE TABLE `entertainment_info` (
  `entertainment_id` int(11) NOT NULL,
  `honor_name` varchar(30) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `resignation` varchar(25) NOT NULL,
  `DOC` varchar(15) NOT NULL,
  `creator` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `entertainment_order_info`
--

CREATE TABLE `entertainment_order_info` (
  `entertainment_order_id` int(11) NOT NULL,
  `order_info_id` int(20) NOT NULL,
  `entertainment_user` int(8) NOT NULL,
  `doc` datetime NOT NULL DEFAULT current_timestamp(),
  `dom` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `creator` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `extra_charge`
--

CREATE TABLE `extra_charge` (
  `extra_charge_id` int(11) NOT NULL,
  `reservation_id` int(11) NOT NULL,
  `extra_service_id` int(11) NOT NULL,
  `charge_amount` int(11) DEFAULT 0,
  `status` tinyint(4) DEFAULT 0,
  `userID` int(11) DEFAULT NULL,
  `DOC` datetime DEFAULT current_timestamp(),
  `DOM` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `extra_charge`
--

INSERT INTO `extra_charge` (`extra_charge_id`, `reservation_id`, `extra_service_id`, `charge_amount`, `status`, `userID`, `DOC`, `DOM`) VALUES
(1, 1, 1, 500, 0, 2, '2015-05-19 00:21:49', NULL),
(2, 2, 1, 200, 0, 2, '2015-05-19 00:22:57', NULL),
(3, 5, 1, 300, 0, 2, '2015-05-19 00:43:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `extra_service`
--

CREATE TABLE `extra_service` (
  `extra_service_id` int(11) NOT NULL,
  `extra_service_name` varchar(200) NOT NULL,
  `status` tinyint(1) DEFAULT 0,
  `userID` int(11) DEFAULT NULL,
  `DOC` datetime DEFAULT current_timestamp(),
  `DOM` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `extra_service`
--

INSERT INTO `extra_service` (`extra_service_id`, `extra_service_name`, `status`, `userID`, `DOC`, `DOM`) VALUES
(1, 'Additional Charge', 0, NULL, '2015-05-03 22:22:21', '2015-05-10 13:55:51');

-- --------------------------------------------------------

--
-- Table structure for table `hotel_setup`
--

CREATE TABLE `hotel_setup` (
  `hotel_id` int(3) NOT NULL,
  `hotel_name` char(100) NOT NULL,
  `hotel_grade` char(8) NOT NULL,
  `hotel_address` char(150) NOT NULL,
  `hotel_type` tinyint(1) NOT NULL,
  `hotel_contact` char(15) NOT NULL,
  `hotel_email` varchar(100) NOT NULL,
  `hotel_website` varchar(100) NOT NULL,
  `hotel_vat` float NOT NULL,
  `hotel_doc` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotel_setup`
--

INSERT INTO `hotel_setup` (`hotel_id`, `hotel_name`, `hotel_grade`, `hotel_address`, `hotel_type`, `hotel_contact`, `hotel_email`, `hotel_website`, `hotel_vat`, `hotel_doc`) VALUES
(1, 'KidzVilla Food Zone', '3', ' Federal Green Tower ( 1st Floor), Road-01, Block-E, Uposhahar R/A, Sylhet', 2, '01617-601079', '', '', 15, '2019-12-30 12:25:57');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(40) COLLATE utf8_bin NOT NULL,
  `login` varchar(50) COLLATE utf8_bin NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `name_title`
--

CREATE TABLE `name_title` (
  `name_title_id` int(11) NOT NULL,
  `title_name` varchar(25) NOT NULL,
  `status` tinyint(1) DEFAULT 0,
  `userID` int(11) DEFAULT NULL,
  `DOC` datetime DEFAULT current_timestamp(),
  `DOM` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `name_title`
--

INSERT INTO `name_title` (`name_title_id`, `title_name`, `status`, `userID`, `DOC`, `DOM`) VALUES
(1, 'Mr.', 0, NULL, '2015-05-03 14:04:22', '2015-05-04 01:13:09'),
(2, 'Mrs.', 0, NULL, '2015-05-03 14:04:46', '2015-05-04 01:13:06'),
(3, 'Mis.', 0, NULL, '2015-05-03 14:04:57', NULL),
(4, 'Dr.', 0, NULL, '2015-05-03 14:05:23', NULL),
(5, 'Md.', 0, NULL, '2015-05-04 01:08:15', '2015-05-04 01:13:03'),
(6, 'Eng.', 0, NULL, '2015-05-04 01:16:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_cancel_reason`
--

CREATE TABLE `order_cancel_reason` (
  `reason_id` int(11) NOT NULL,
  `cancel_reason` varchar(200) NOT NULL,
  `doc` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `creator` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_cancel_reason`
--

INSERT INTO `order_cancel_reason` (`reason_id`, `cancel_reason`, `doc`, `creator`) VALUES
(1, 'Customer Left', '2015-05-31 18:00:00', 15),
(2, 'Customer left', '2015-06-02 18:00:00', 15);

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `order_details_id` int(11) NOT NULL,
  `product_id` int(20) NOT NULL,
  `order_id` int(20) NOT NULL,
  `quantity` int(5) NOT NULL,
  `sale_prices` int(8) NOT NULL,
  `guest_number` varchar(3) DEFAULT 'All',
  `prep_comment` varchar(200) NOT NULL,
  `service_in_room_id` int(20) NOT NULL,
  `creator` int(10) NOT NULL,
  `doc` varchar(20) NOT NULL,
  `dom` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`order_details_id`, `product_id`, `order_id`, `quantity`, `sale_prices`, `guest_number`, `prep_comment`, `service_in_room_id`, `creator`, `doc`, `dom`) VALUES
(1, 5, 2, 2, 130, 'All', '', 22, 12, '2019-12-29', '2019-12-29 07:00:00'),
(2, 140, 4, 3, 380, 'All', '', 23, 12, '2019-12-29', '2019-12-29 07:00:00'),
(3, 124, 4, 2, 120, 'All', '', 24, 12, '2019-12-29', '2019-12-29 07:00:00'),
(4, 244, 6, 2, 40, 'All', '', 25, 12, '2019-12-29', '2019-12-29 07:00:00'),
(5, 244, 9, 1, 40, 'All', '', 26, 12, '2019-12-30', '2019-12-30 07:00:00'),
(7, 244, 13, 2, 40, 'All', '', 28, 12, '2019-12-30', '2019-12-30 07:00:00'),
(8, 244, 15, 2, 40, 'All', '', 29, 12, '2019-12-31', '2019-12-31 07:00:00'),
(9, 244, 16, 2, 40, 'All', '', 30, 12, '2019-12-31', '2019-12-31 07:00:00'),
(10, 296, 24, 1, 70, 'All', '', 31, 12, '2019-12-31', '2019-12-31 07:00:00'),
(11, 286, 25, 1, 80, 'All', '', 32, 12, '2019-12-31', '2019-12-31 07:00:00'),
(12, 256, 27, 1, 80, '2', '', 33, 12, '2019-12-31', '2019-12-31 07:00:00'),
(13, 256, 27, 1, 80, '2', '', 34, 12, '2019-12-31', '2019-12-31 07:00:00'),
(14, 257, 28, 1, 100, '1', '', 35, 12, '2019-12-31', '2019-12-31 07:00:00'),
(15, 64, 29, 1, 15, 'All', '', 36, 12, '2019-12-31', '2019-12-31 07:00:00'),
(16, 256, 32, 1, 80, 'All', '', 37, 12, '2019-12-31', '2019-12-31 07:00:00'),
(17, 256, 33, 1, 80, 'All', '', 38, 12, '2019-12-31', '2019-12-31 07:00:00'),
(18, 284, 33, 1, 80, 'All', '', 39, 12, '2019-12-31', '2019-12-31 07:00:00'),
(19, 285, 33, 1, 80, 'All', '', 40, 12, '2019-12-31', '2019-12-31 07:00:00'),
(20, 285, 34, 2, 80, 'All', '', 41, 12, '2019-12-31', '2019-12-31 07:00:00'),
(21, 252, 36, 2, 60, 'All', '', 42, 12, '2019-12-31', '2019-12-31 07:00:00'),
(22, 252, 37, 3, 60, 'All', '', 43, 12, '2019-12-31', '2019-12-31 07:00:00'),
(23, 256, 37, 1, 80, 'All', '', 44, 12, '2019-12-31', '2019-12-31 07:00:00'),
(24, 282, 37, 2, 70, 'All', '', 45, 12, '2019-12-31', '2019-12-31 07:00:00'),
(25, 294, 38, 1, 70, 'All', '', 46, 12, '2019-12-31', '2019-12-31 07:00:00'),
(26, 294, 39, 1, 70, 'All', '', 47, 12, '2019-12-31', '2019-12-31 07:00:00'),
(27, 282, 40, 1, 70, 'All', '', 48, 12, '2019-12-31', '2019-12-31 07:00:00'),
(28, 256, 41, 1, 80, 'All', '', 49, 12, '2019-12-31', '2019-12-31 07:00:00'),
(29, 282, 43, 2, 70, 'All', '', 50, 12, '2019-12-31', '2019-12-31 07:00:00'),
(30, 282, 44, 2, 70, 'All', '', 51, 12, '2019-12-31', '2019-12-31 07:00:00'),
(31, 252, 45, 2, 60, 'All', '', 52, 12, '2019-12-31', '2019-12-31 07:00:00'),
(32, 272, 46, 1, 120, 'All', '', 53, 12, '2019-12-31', '2019-12-31 07:00:00'),
(33, 252, 47, 4, 60, 'All', '', 54, 12, '2019-12-31', '2019-12-31 07:00:00'),
(34, 256, 47, 1, 80, 'All', '', 55, 12, '2019-12-31', '2019-12-31 07:00:00'),
(35, 252, 48, 2, 60, 'All', '', 56, 12, '2019-12-31', '2019-12-31 07:00:00'),
(36, 253, 48, 2, 60, 'All', '', 57, 12, '2019-12-31', '2019-12-31 07:00:00'),
(37, 246, 48, 1, 130, 'All', '', 58, 12, '2019-12-31', '2019-12-31 07:00:00'),
(38, 282, 49, 3, 70, 'All', '', 59, 12, '2019-12-31', '2019-12-31 07:00:00'),
(39, 245, 49, 1, 125, 'All', '', 60, 12, '2019-12-31', '2019-12-31 07:00:00'),
(40, 245, 49, 1, 125, 'All', '', 61, 12, '2019-12-31', '2019-12-31 07:00:00'),
(41, 245, 50, 1, 125, 'All', '', 62, 12, '2019-12-31', '2019-12-31 07:00:00'),
(42, 245, 50, 1, 125, '1', '', 63, 12, '2019-12-31', '2019-12-31 07:00:00'),
(43, 245, 50, 1, 125, 'All', '', 64, 12, '2019-12-31', '2019-12-31 07:00:00'),
(44, 246, 50, 1, 130, 'All', '', 65, 12, '2019-12-31', '2019-12-31 07:00:00'),
(45, 245, 50, 1, 125, 'All', '', 66, 12, '2019-12-31', '2019-12-31 07:00:00'),
(46, 247, 50, 1, 180, 'All', '', 67, 12, '2019-12-31', '2019-12-31 07:00:00'),
(47, 245, 51, 1, 125, 'All', '', 68, 12, '2019-12-31', '2019-12-31 07:00:00'),
(48, 245, 51, 1, 125, 'All', '', 69, 12, '2019-12-31', '2019-12-31 07:00:00'),
(49, 246, 51, 1, 130, 'All', '', 70, 12, '2019-12-31', '2019-12-31 07:00:00'),
(50, 282, 51, 3, 70, 'All', '', 71, 12, '2019-12-31', '2019-12-31 07:00:00'),
(51, 256, 53, 2, 80, 'All', '', 72, 12, '2019-12-31', '2019-12-31 07:00:00'),
(52, 288, 53, 1, 80, 'All', '', 73, 12, '2019-12-31', '2019-12-31 07:00:00'),
(53, 249, 54, 1, 110, 'All', '', 74, 12, '2019-12-31', '2019-12-31 07:00:00'),
(54, 252, 54, 3, 60, 'All', '', 75, 12, '2019-12-31', '2019-12-31 07:00:00'),
(55, 252, 55, 1, 60, 'All', '', 76, 12, '2020-01-01', '2020-01-01 07:00:00'),
(56, 253, 55, 1, 60, 'All', '', 77, 12, '2020-01-01', '2020-01-01 07:00:00'),
(57, 255, 55, 1, 130, 'All', '', 78, 12, '2020-01-01', '2020-01-01 07:00:00'),
(58, 245, 55, 1, 125, 'All', '', 79, 12, '2020-01-01', '2020-01-01 07:00:00'),
(59, 252, 56, 1, 60, 'All', '', 80, 12, '2020-01-01', '2020-01-01 07:00:00'),
(60, 253, 56, 1, 60, 'All', '', 81, 12, '2020-01-01', '2020-01-01 07:00:00'),
(61, 255, 56, 1, 130, 'All', '', 82, 12, '2020-01-01', '2020-01-01 07:00:00'),
(62, 245, 56, 1, 125, 'All', '', 83, 12, '2020-01-01', '2020-01-01 07:00:00'),
(63, 245, 56, 1, 125, 'All', '', 84, 12, '2020-01-01', '2020-01-01 07:00:00'),
(64, 246, 56, 1, 130, 'All', '', 85, 12, '2020-01-01', '2020-01-01 07:00:00'),
(65, 244, 60, 2, 40, 'All', '', 86, 12, '2020-01-01', '2020-01-01 07:00:00'),
(66, 77, 61, 2, 180, 'All', '', 87, 12, '2020-01-01', '2020-01-01 07:00:00'),
(67, 286, 62, 2, 80, 'All', '', 88, 12, '2020-01-01', '2020-01-01 07:00:00'),
(68, 286, 62, 2, 80, 'All', '', 89, 12, '2020-01-01', '2020-01-01 07:00:00'),
(69, 270, 63, 1, 100, 'All', '', 90, 12, '2020-01-01', '2020-01-01 07:00:00'),
(70, 272, 63, 2, 120, 'All', '', 91, 12, '2020-01-01', '2020-01-01 07:00:00'),
(71, 300, 63, 3, 10, 'All', '', 92, 12, '2020-01-01', '2020-01-01 07:00:00'),
(72, 249, 65, 1, 130, 'All', '', 93, 12, '2020-01-01', '2020-01-01 07:00:00'),
(73, 285, 65, 2, 80, 'All', '', 94, 12, '2020-01-01', '2020-01-01 07:00:00'),
(74, 256, 65, 1, 80, 'All', '', 95, 12, '2020-01-01', '2020-01-01 07:00:00'),
(75, 301, 66, 1, 15, 'All', '', 96, 12, '2020-01-01', '2020-01-01 07:00:00'),
(76, 257, 67, 1, 100, 'All', '', 97, 12, '2020-01-01', '2020-01-01 07:00:00'),
(77, 256, 67, 1, 80, 'All', '', 98, 12, '2020-01-01', '2020-01-01 07:00:00'),
(78, 249, 67, 1, 130, 'All', '', 99, 12, '2020-01-01', '2020-01-01 07:00:00'),
(79, 252, 68, 1, 80, 'All', '', 100, 12, '2020-01-01', '2020-01-01 07:00:00'),
(80, 256, 68, 1, 80, 'All', '', 101, 12, '2020-01-01', '2020-01-01 07:00:00'),
(83, 252, 70, 3, 80, 'All', '', 104, 12, '2020-01-01', '2020-01-01 07:00:00'),
(84, 256, 70, 2, 80, 'All', '', 105, 12, '2020-01-01', '2020-01-01 07:00:00'),
(85, 249, 70, 1, 130, 'All', '', 106, 12, '2020-01-01', '2020-01-01 07:00:00'),
(86, 301, 70, 2, 15, 'All', '', 107, 12, '2020-01-01', '2020-01-01 07:00:00'),
(87, 257, 71, 1, 100, 'All', '', 108, 12, '2020-01-01', '2020-01-01 07:00:00'),
(88, 300, 72, 1, 10, 'All', '', 109, 12, '2020-01-01', '2020-01-01 07:00:00'),
(90, 252, 74, 4, 80, 'All', '', 111, 12, '2020-01-02', '2020-01-02 07:00:00'),
(91, 256, 74, 2, 80, 'All', '', 112, 12, '2020-01-02', '2020-01-02 07:00:00'),
(92, 301, 74, 1, 15, 'All', '', 113, 12, '2020-01-02', '2020-01-02 07:00:00'),
(93, 300, 75, 1, 10, 'All', '', 114, 12, '2020-01-02', '2020-01-02 07:00:00'),
(94, 256, 76, 1, 80, 'All', '', 115, 12, '2020-01-02', '2020-01-02 07:00:00'),
(95, 282, 77, 2, 70, 'All', '', 116, 12, '2020-01-02', '2020-01-02 07:00:00'),
(96, 279, 78, 1, 100, 'All', '', 117, 12, '2020-01-02', '2020-01-02 07:00:00'),
(97, 252, 80, 6, 80, 'All', '', 118, 12, '2020-01-02', '2020-01-02 07:00:00'),
(98, 256, 80, 3, 80, 'All', '', 119, 12, '2020-01-02', '2020-01-02 07:00:00'),
(99, 272, 80, 10, 120, 'All', '', 120, 12, '2020-01-02', '2020-01-02 07:00:00'),
(100, 301, 80, 2, 15, 'All', '', 121, 12, '2020-01-02', '2020-01-02 07:00:00'),
(101, 245, 80, 2, 125, 'All', '', 122, 12, '2020-01-02', '2020-01-02 07:00:00'),
(102, 245, 80, 2, 125, 'All', '', 123, 12, '2020-01-02', '2020-01-02 07:00:00'),
(103, 245, 81, 2, 125, 'All', '', 124, 12, '2020-01-02', '2020-01-02 07:00:00'),
(104, 245, 82, 2, 125, 'All', '', 125, 12, '2020-01-02', '2020-01-02 07:00:00'),
(105, 245, 82, 2, 125, 'All', '', 126, 12, '2020-01-02', '2020-01-02 07:00:00'),
(106, 272, 83, 10, 120, 'All', '', 127, 12, '2020-01-02', '2020-01-02 07:00:00'),
(107, 256, 83, 3, 80, 'All', '', 128, 12, '2020-01-02', '2020-01-02 07:00:00'),
(108, 252, 83, 6, 80, 'All', '', 129, 12, '2020-01-02', '2020-01-02 07:00:00'),
(109, 245, 83, 2, 125, 'All', '', 130, 12, '2020-01-02', '2020-01-02 07:00:00'),
(110, 245, 83, 2, 125, 'All', '', 131, 12, '2020-01-02', '2020-01-02 07:00:00'),
(111, 245, 83, 2, 125, 'All', '', 132, 12, '2020-01-02', '2020-01-02 07:00:00'),
(112, 245, 84, 2, 125, 'All', '', 133, 12, '2020-01-02', '2020-01-02 07:00:00'),
(113, 245, 84, 2, 125, 'All', '', 134, 12, '2020-01-02', '2020-01-02 07:00:00'),
(114, 245, 85, 2, 125, 'All', '', 135, 12, '2020-01-02', '2020-01-02 07:00:00'),
(115, 245, 86, 2, 125, 'All', '', 136, 12, '2020-01-02', '2020-01-02 07:00:00'),
(116, 252, 87, 6, 80, 'All', '', 137, 12, '2020-01-02', '2020-01-02 07:00:00'),
(117, 256, 87, 3, 80, 'All', '', 138, 12, '2020-01-02', '2020-01-02 07:00:00'),
(118, 272, 87, 10, 120, 'All', '', 139, 12, '2020-01-02', '2020-01-02 07:00:00'),
(119, 245, 87, 2, 125, 'All', '', 140, 12, '2020-01-02', '2020-01-02 07:00:00'),
(120, 301, 87, 2, 15, 'All', '', 141, 12, '2020-01-02', '2020-01-02 07:00:00'),
(121, 245, 87, 2, 125, 'All', '', 142, 12, '2020-01-02', '2020-01-02 07:00:00'),
(122, 300, 88, 1, 10, 'All', '', 143, 12, '2020-01-02', '2020-01-02 07:00:00'),
(123, 245, 89, 2, 125, 'All', '', 144, 12, '2020-01-02', '2020-01-02 07:00:00'),
(124, 256, 91, 2, 80, 'All', '', 145, 12, '2020-01-02', '2020-01-02 07:00:00'),
(125, 300, 92, 1, 10, 'All', '', 146, 12, '2020-01-02', '2020-01-02 07:00:00'),
(126, 282, 92, 2, 70, 'All', '', 147, 12, '2020-01-02', '2020-01-02 07:00:00'),
(127, 299, 92, 2, 125, 'All', '', 148, 12, '2020-01-02', '2020-01-02 07:00:00'),
(128, 270, 93, 3, 100, 'All', '', 149, 12, '2020-01-02', '2020-01-02 07:00:00'),
(129, 256, 93, 1, 80, 'All', '', 150, 12, '2020-01-02', '2020-01-02 07:00:00'),
(130, 256, 95, 1, 80, 'All', '', 151, 12, '2020-01-02', '2020-01-02 07:00:00'),
(131, 256, 95, 1, 80, 'All', '', 152, 12, '2020-01-02', '2020-01-02 07:00:00'),
(132, 256, 96, 1, 80, 'All', '', 153, 12, '2020-01-02', '2020-01-02 07:00:00'),
(133, 272, 96, 1, 120, 'All', '', 154, 12, '2020-01-02', '2020-01-02 07:00:00'),
(134, 282, 96, 1, 70, 'All', '', 155, 12, '2020-01-02', '2020-01-02 07:00:00'),
(135, 301, 97, 1, 15, 'All', '', 156, 12, '2020-01-02', '2020-01-02 07:00:00'),
(136, 251, 98, 1, 160, 'All', '', 157, 12, '2020-01-03', '2020-01-03 07:00:00'),
(137, 257, 98, 1, 100, 'All', '', 158, 12, '2020-01-03', '2020-01-03 07:00:00'),
(138, 251, 100, 1, 160, 'All', '', 159, 12, '2020-01-03', '2020-01-03 07:00:00'),
(139, 247, 101, 1, 180, 'All', '', 160, 12, '2020-01-03', '2020-01-03 07:00:00'),
(140, 247, 103, 1, 180, 'All', '', 161, 12, '2020-01-03', '2020-01-03 07:00:00'),
(141, 247, 103, 1, 180, 'All', '', 162, 12, '2020-01-03', '2020-01-03 07:00:00'),
(142, 247, 105, 1, 180, 'All', '', 163, 12, '2020-01-03', '2020-01-03 07:00:00'),
(143, 247, 105, 1, 180, 'All', '', 164, 12, '2020-01-03', '2020-01-03 07:00:00'),
(144, 270, 106, 1, 100, 'All', '', 165, 12, '2020-01-03', '2020-01-03 07:00:00'),
(145, 256, 106, 1, 80, 'All', '', 166, 12, '2020-01-03', '2020-01-03 07:00:00'),
(147, 282, 108, 1, 70, 'All', '', 168, 12, '2020-01-03', '2020-01-03 07:00:00'),
(148, 256, 110, 2, 80, 'All', '', 169, 12, '2020-01-03', '2020-01-03 07:00:00'),
(149, 256, 110, 2, 80, 'All', '', 170, 12, '2020-01-03', '2020-01-03 07:00:00'),
(150, 256, 112, 1, 80, 'All', '', 171, 12, '2020-01-03', '2020-01-03 07:00:00'),
(151, 256, 112, 1, 80, 'All', '', 172, 12, '2020-01-03', '2020-01-03 07:00:00'),
(153, 256, 113, 2, 80, 'All', '', 174, 12, '2020-01-03', '2020-01-03 07:00:00'),
(154, 272, 113, 2, 120, 'All', '', 175, 12, '2020-01-03', '2020-01-03 07:00:00'),
(155, 272, 113, 1, 120, 'All', '', 176, 12, '2020-01-03', '2020-01-03 07:00:00'),
(156, 246, 113, 1, 130, 'All', '', 177, 12, '2020-01-03', '2020-01-03 07:00:00'),
(157, 301, 113, 1, 15, 'All', '', 178, 12, '2020-01-03', '2020-01-03 07:00:00'),
(158, 245, 114, 1, 125, 'All', '', 179, 12, '2020-01-03', '2020-01-03 07:00:00'),
(159, 245, 114, 1, 125, 'All', '', 180, 12, '2020-01-03', '2020-01-03 07:00:00'),
(160, 245, 116, 1, 125, 'All', '', 181, 12, '2020-01-03', '2020-01-03 07:00:00'),
(162, 256, 117, 1, 80, 'All', '', 183, 12, '2020-01-03', '2020-01-03 07:00:00'),
(163, 300, 118, 3, 10, 'All', '', 184, 12, '2020-01-03', '2020-01-03 07:00:00'),
(164, 300, 119, 1, 10, 'All', '', 185, 12, '2020-01-03', '2020-01-03 07:00:00'),
(166, 254, 121, 1, 280, 'All', '', 187, 12, '2020-01-03', '2020-01-03 07:00:00'),
(167, 249, 122, 1, 130, 'All', '', 188, 12, '2020-01-03', '2020-01-03 07:00:00'),
(168, 256, 122, 1, 80, 'All', '', 189, 12, '2020-01-03', '2020-01-03 07:00:00'),
(169, 288, 122, 1, 80, 'All', '', 190, 12, '2020-01-03', '2020-01-03 07:00:00'),
(170, 288, 124, 1, 80, 'All', '', 191, 12, '2020-01-03', '2020-01-03 07:00:00'),
(171, 261, 125, 1, 260, 'All', '', 192, 12, '2020-01-04', '2020-01-04 07:00:00'),
(172, 257, 125, 2, 100, 'All', '', 193, 12, '2020-01-04', '2020-01-04 07:00:00'),
(173, 257, 126, 1, 100, 'All', '', 194, 12, '2020-01-04', '2020-01-04 07:00:00'),
(174, 245, 126, 1, 125, 'All', '', 195, 12, '2020-01-04', '2020-01-04 07:00:00'),
(175, 256, 126, 1, 80, 'All', '', 196, 12, '2020-01-04', '2020-01-04 07:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `order_info`
--

CREATE TABLE `order_info` (
  `order_id` int(11) NOT NULL,
  `table_id` int(30) NOT NULL,
  `client_id` varchar(50) NOT NULL,
  `client_name` varchar(100) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `guest_quantity` int(30) DEFAULT NULL,
  `waiter` int(6) NOT NULL,
  `comments` varchar(100) NOT NULL,
  `total_amount` int(10) NOT NULL,
  `discount_amount` int(8) DEFAULT 0,
  `service_charge` int(5) NOT NULL DEFAULT 0,
  `advance_paid` int(5) NOT NULL,
  `paid_amount` int(8) NOT NULL DEFAULT 0,
  `status` varchar(10) NOT NULL,
  `order_type` int(1) NOT NULL,
  `order_place` int(2) NOT NULL DEFAULT 0,
  `room_number` varchar(12) NOT NULL,
  `running` varchar(10) NOT NULL,
  `creator` int(20) NOT NULL,
  `doc` date NOT NULL,
  `dom` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_info`
--

INSERT INTO `order_info` (`order_id`, `table_id`, `client_id`, `client_name`, `contact_number`, `guest_quantity`, `waiter`, `comments`, `total_amount`, `discount_amount`, `service_charge`, `advance_paid`, `paid_amount`, `status`, `order_type`, `order_place`, `room_number`, `running`, `creator`, `doc`, `dom`) VALUES
(1, 3, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-29', '2019-12-30 13:43:51'),
(2, 8, '0', '', '', 2, 0, '', 260, 0, 0, 0, 0, 'inactive', 0, 0, '', 'finish', 12, '2019-12-29', '2019-12-29 13:26:14'),
(3, 4, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-29', '2019-12-29 13:20:31'),
(4, 3, '0', '', '', 2, 0, '', 1380, 0, 0, 0, 1380, 'inactive', 0, 0, '', 'edit', 12, '2019-12-29', '2019-12-30 10:20:01'),
(5, 8, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-29', '2019-12-30 09:43:47'),
(6, 7, '0', '', '', 1, 0, '', 80, 0, 0, 0, 80, 'inactive', 0, 0, '', 'finish', 12, '2019-12-29', '2019-12-29 13:39:24'),
(7, 13, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-30', '2019-12-30 13:33:52'),
(8, 3, '0', '', '', 0, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-30', '2019-12-31 04:45:59'),
(9, 16, '0', '', '', 2, 0, '', 40, 0, 0, 0, 0, 'inactive', 0, 0, '', 'finish', 12, '2019-12-30', '2019-12-30 13:07:46'),
(10, 22, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-30', '2019-12-30 13:43:51'),
(11, 22, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-30', '2019-12-30 13:46:56'),
(12, 20, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'finish', 12, '2019-12-30', '2019-12-30 17:24:04'),
(13, 22, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-30', '2019-12-31 03:55:31'),
(14, 15, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 04:23:55'),
(15, 21, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 05:22:54'),
(16, 7, '0', '', '', 2, 0, '', 80, 0, 0, 0, 0, 'inactive', 0, 0, '', 'finish', 12, '2019-12-31', '2019-12-31 07:35:36'),
(17, 3, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 07:37:11'),
(18, 7, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 07:39:18'),
(19, 0, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 07:39:18'),
(20, 0, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 07:39:18'),
(21, 0, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 07:39:19'),
(22, 0, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 07:39:19'),
(23, 0, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 07:39:32'),
(24, 7, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 07:40:03'),
(25, 3, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 07:40:34'),
(26, 0, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 07:41:37'),
(27, 3, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 07:42:45'),
(28, 7, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 07:44:08'),
(29, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 09:31:23'),
(30, 0, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 10:58:23'),
(31, 22, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 10:58:23'),
(32, 22, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 11:02:53'),
(33, 15, '0', '', '', 4, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 11:08:42'),
(34, 20, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 11:39:22'),
(35, 19, '0', '', '', 5, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 11:39:23'),
(36, 19, '0', '', '', 5, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 11:41:11'),
(37, 19, '0', '', '', 5, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 11:57:28'),
(38, 22, '0', '', '', 1, 0, '', 0, 0, 0, 0, 70, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 12:02:07'),
(39, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 70, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 12:05:33'),
(40, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 70, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 12:11:17'),
(41, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 80, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 12:31:08'),
(42, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 12:46:25'),
(43, 18, '0', '', '', 2, 0, '', 0, 0, 0, 0, 140, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 12:48:27'),
(44, 19, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 12:50:30'),
(45, 18, '0', '', '', 2, 0, '', 0, 0, 0, 0, 120, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 13:00:48'),
(46, 3, '0', '', '', 1, 0, '', 0, 0, 0, 0, 120, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 13:22:47'),
(47, 7, '0', '', '', 3, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 14:56:53'),
(48, 18, '0', '', '', 4, 0, '', 0, 0, 0, 0, 370, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 15:08:00'),
(49, 22, '0', '', '', 5, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 15:09:32'),
(50, 21, '0', '', '', 5, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 15:14:16'),
(51, 21, '0', '', '', 1, 0, '', 0, 0, 0, 0, 335, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 15:24:53'),
(52, 3, '0', '', '', 5, 0, '', 0, 0, 15, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 15:35:47'),
(53, 21, '0', '', '', 5, 0, '', 0, 0, 0, 0, 240, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2019-12-31 15:39:00'),
(54, 3, '0', '', '', 3, 0, '', 0, 0, 0, 0, 290, 'inactive', 0, 0, '', 'running', 12, '2019-12-31', '2020-01-01 06:04:47'),
(55, 21, '0', '', '', 3, 0, '', 0, 0, 0, 0, 250, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-01 06:19:31'),
(56, 21, '0', '', '', 3, 0, '', 0, 0, 0, 0, 425, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-01 07:03:03'),
(57, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-01 07:06:04'),
(58, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-01 07:14:56'),
(59, 19, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-01 08:58:16'),
(60, 3, '0', '', '', 4, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-01 09:01:29'),
(61, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 360, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-01 09:05:30'),
(62, 15, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-01 10:43:27'),
(63, 21, '0', '', '', 4, 0, '', 0, 0, 0, 0, 370, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-01 10:54:46'),
(64, 19, '0', '', '', 4, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-01 11:07:51'),
(65, 15, '0', '', '', 2, 0, '', 0, 0, 0, 0, 370, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-01 11:28:55'),
(66, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 15, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-01 12:41:46'),
(67, 18, '0', '', '', 3, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-01 13:24:16'),
(68, 16, '0', '', '', 2, 0, '', 0, 0, 0, 0, 160, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-01 13:36:35'),
(70, 15, '0', '', '', 4, 0, '', 0, 0, 0, 0, 560, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-01 14:22:53'),
(71, 16, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-01 14:26:06'),
(72, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-01', '2020-01-02 05:22:11'),
(74, 18, '0', '', '', 4, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 08:00:15'),
(75, 21, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 08:04:44'),
(76, 18, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 09:50:30'),
(77, 15, '0', '', '', 2, 0, '', 0, 0, 0, 0, 140, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 10:38:39'),
(78, 18, '0', '', '', 2, 0, '', 0, 0, 0, 0, 100, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 11:15:03'),
(79, 21, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 11:15:27'),
(80, 22, '0', '', '', 10, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 11:19:30'),
(81, 22, '0', '', '', 12, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 11:23:04'),
(82, 22, '0', '', '', 10, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 11:24:06'),
(83, 22, '0', '', '', 10, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 11:28:59'),
(84, 22, '0', '', '', 10, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 11:29:35'),
(85, 21, '0', '', '', 10, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 11:29:59'),
(86, 21, '0', '', '', 8, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 11:30:27'),
(87, 21, '0', '', '', 10, 0, '', 0, 0, 0, 0, 1950, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 11:36:21'),
(88, 15, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 11:42:27'),
(89, 21, '0', '', '', 9, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 11:58:02'),
(90, 19, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 11:58:02'),
(91, 19, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 12:35:29'),
(92, 18, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 12:54:14'),
(93, 3, '0', '', '', 5, 0, '', 0, 0, 0, 0, 380, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 12:56:46'),
(94, 15, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 12:56:46'),
(95, 15, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 12:57:35'),
(96, 15, '0', '', '', 2, 0, '', 0, 0, 0, 0, 270, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-02 13:18:26'),
(97, 17, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-02', '2020-01-03 10:15:55'),
(98, 15, '0', '', '', 3, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 10:20:44'),
(99, 15, '0', '', '', 3, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 10:20:45'),
(100, 15, '0', '', '', 3, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 10:58:17'),
(101, 15, '0', '', '', 3, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'finish', 12, '2020-01-03', '2020-01-03 11:00:31'),
(102, 15, '0', '', '', 3, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 11:00:31'),
(103, 15, '0', '', '', 3, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 11:02:42'),
(104, 15, '0', '', '', 3, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 11:02:42'),
(105, 15, '0', '', '', 3, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 11:27:35'),
(106, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 11:34:50'),
(107, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 11:34:51'),
(108, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 11:48:09'),
(109, 15, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 11:48:10'),
(110, 15, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 11:54:57'),
(111, 19, '0', '', '', 6, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 11:54:57'),
(112, 19, '0', '', '', 6, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 12:35:40'),
(113, 17, '0', '', '', 6, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 12:41:29'),
(114, 3, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 12:46:44'),
(115, 15, '0', '', '', 6, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 12:46:45'),
(116, 15, '0', '', '', 6, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 12:50:24'),
(117, 17, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 14:24:35'),
(118, 18, '0', '', '', 3, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 14:32:19'),
(119, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 14:34:39'),
(120, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 14:34:40'),
(121, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 14:41:12'),
(122, 15, '0', '', '', 3, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 14:44:32'),
(123, 15, '0', '', '', 3, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-03 14:44:32'),
(124, 15, '0', '', '', 2, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-03', '2020-01-04 05:17:48'),
(125, 15, '0', '', '', 4, 0, '', 0, 0, 0, 0, 0, 'inactive', 0, 0, '', 'running', 12, '2020-01-04', '2020-01-04 07:28:46'),
(126, 15, '0', '', '', 1, 0, '', 0, 0, 0, 0, 0, 'active', 0, 0, '', 'running', 12, '2020-01-04', '2020-01-04 07:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `order_reference_table`
--

CREATE TABLE `order_reference_table` (
  `reference_id` int(11) NOT NULL,
  `order_id` int(12) NOT NULL,
  `reference_table` varchar(50) NOT NULL,
  `ref_id` int(12) NOT NULL,
  `grand_total` int(10) NOT NULL,
  `discount_type` int(1) NOT NULL,
  `discounts_value` int(6) NOT NULL,
  `discount_id` int(20) NOT NULL,
  `service_value` int(4) NOT NULL,
  `service_type` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_reference_table`
--

INSERT INTO `order_reference_table` (`reference_id`, `order_id`, `reference_table`, `ref_id`, `grand_total`, `discount_type`, `discounts_value`, `discount_id`, `service_value`, `service_type`) VALUES
(1, 1, '', 0, 0, 0, 0, 0, 0, 0),
(2, 2, 'payment_history', 0, 260, 0, 0, 0, 0, 0),
(3, 3, '', 0, 0, 0, 0, 0, 0, 0),
(4, 4, 'payment_history', 0, 1380, 0, 0, 0, 0, 0),
(5, 5, '', 0, 0, 0, 0, 0, 0, 0),
(6, 6, 'payment_history', 0, 80, 0, 0, 0, 0, 0),
(7, 7, '', 0, 0, 0, 0, 0, 0, 0),
(8, 8, '', 0, 0, 0, 0, 0, 0, 0),
(9, 9, 'payment_history', 0, 40, 0, 0, 0, 0, 0),
(10, 10, '', 0, 0, 0, 0, 0, 0, 0),
(11, 11, '', 0, 0, 0, 0, 0, 0, 0),
(12, 12, 'payment_history', 0, 0, 0, 0, 0, 0, 0),
(13, 13, '', 0, 0, 0, 0, 0, 0, 0),
(14, 14, '', 0, 0, 0, 0, 0, 0, 0),
(15, 15, '', 0, 0, 0, 0, 0, 0, 0),
(16, 16, 'payment_history', 0, 80, 0, 0, 0, 0, 0),
(17, 17, '', 0, 0, 0, 0, 0, 0, 0),
(18, 18, '', 0, 0, 0, 0, 0, 0, 0),
(19, 19, '', 0, 0, 0, 0, 0, 0, 0),
(20, 20, '', 0, 0, 0, 0, 0, 0, 0),
(21, 21, '', 0, 0, 0, 0, 0, 0, 0),
(22, 22, '', 0, 0, 0, 0, 0, 0, 0),
(23, 23, '', 0, 0, 0, 0, 0, 0, 0),
(24, 24, '', 0, 0, 0, 0, 0, 0, 0),
(25, 25, '', 0, 0, 0, 0, 0, 0, 0),
(26, 26, '', 0, 0, 0, 0, 0, 0, 0),
(27, 27, '', 0, 0, 0, 0, 0, 0, 0),
(28, 28, '', 0, 0, 0, 0, 0, 0, 0),
(29, 29, '', 0, 0, 0, 0, 0, 0, 0),
(30, 30, '', 0, 0, 0, 0, 0, 0, 0),
(31, 31, '', 0, 0, 0, 0, 0, 0, 0),
(32, 32, '', 0, 0, 0, 0, 0, 0, 0),
(33, 33, '', 0, 0, 0, 0, 0, 0, 0),
(34, 34, '', 0, 0, 0, 0, 0, 0, 0),
(35, 35, '', 0, 0, 0, 0, 0, 0, 0),
(36, 36, '', 0, 0, 0, 0, 0, 0, 0),
(37, 37, '', 0, 0, 0, 0, 0, 0, 0),
(38, 38, '', 0, 0, 0, 0, 0, 0, 0),
(39, 39, '', 0, 0, 0, 0, 0, 0, 0),
(40, 40, '', 0, 0, 0, 0, 0, 0, 0),
(41, 41, '', 0, 0, 0, 0, 0, 0, 0),
(42, 42, '', 0, 0, 0, 0, 0, 0, 0),
(43, 43, '', 0, 0, 0, 0, 0, 0, 0),
(44, 44, '', 0, 0, 0, 0, 0, 0, 0),
(45, 45, '', 0, 0, 0, 0, 0, 0, 0),
(46, 46, '', 0, 0, 0, 0, 0, 0, 0),
(47, 47, '', 0, 0, 0, 0, 0, 0, 0),
(48, 48, '', 0, 0, 0, 0, 0, 0, 0),
(49, 49, '', 0, 0, 0, 0, 0, 0, 0),
(50, 50, '', 0, 0, 0, 0, 0, 0, 0),
(51, 51, '', 0, 0, 0, 0, 0, 0, 0),
(52, 52, '', 0, 0, 0, 0, 0, 15, 0),
(53, 53, '', 0, 0, 0, 0, 0, 0, 0),
(54, 54, '', 0, 0, 0, 0, 0, 0, 0),
(55, 55, '', 0, 0, 0, 0, 0, 0, 0),
(56, 56, '', 0, 0, 0, 0, 0, 0, 0),
(57, 57, '', 0, 0, 0, 0, 0, 0, 0),
(58, 58, '', 0, 0, 0, 0, 0, 0, 0),
(59, 59, '', 0, 0, 0, 0, 0, 0, 0),
(60, 60, '', 0, 0, 0, 0, 0, 0, 0),
(61, 61, '', 0, 0, 0, 0, 0, 0, 0),
(62, 62, '', 0, 0, 0, 0, 0, 0, 0),
(63, 63, '', 0, 0, 0, 0, 0, 0, 0),
(64, 64, '', 0, 0, 0, 0, 0, 0, 0),
(65, 65, '', 0, 0, 0, 0, 0, 0, 0),
(66, 66, '', 0, 0, 0, 0, 0, 0, 0),
(67, 67, '', 0, 0, 0, 0, 0, 0, 0),
(68, 68, '', 0, 0, 0, 0, 0, 0, 0),
(70, 70, '', 0, 0, 0, 0, 0, 0, 0),
(71, 71, '', 0, 0, 0, 0, 0, 0, 0),
(72, 72, '', 0, 0, 0, 0, 0, 0, 0),
(74, 74, '', 0, 0, 0, 0, 0, 0, 0),
(75, 75, '', 0, 0, 0, 0, 0, 0, 0),
(76, 76, '', 0, 0, 0, 0, 0, 0, 0),
(77, 77, '', 0, 0, 0, 0, 0, 0, 0),
(78, 78, '', 0, 0, 0, 0, 0, 0, 0),
(79, 79, '', 0, 0, 0, 0, 0, 0, 0),
(80, 80, '', 0, 0, 0, 0, 0, 0, 0),
(81, 81, '', 0, 0, 0, 0, 0, 0, 0),
(82, 82, '', 0, 0, 0, 0, 0, 0, 0),
(83, 83, '', 0, 0, 0, 0, 0, 0, 0),
(84, 84, '', 0, 0, 0, 0, 0, 0, 0),
(85, 85, '', 0, 0, 0, 0, 0, 0, 0),
(86, 86, '', 0, 0, 0, 0, 0, 0, 0),
(87, 87, '', 0, 0, 0, 0, 0, 0, 0),
(88, 88, '', 0, 0, 0, 0, 0, 0, 0),
(89, 89, '', 0, 0, 0, 0, 0, 0, 0),
(90, 90, '', 0, 0, 0, 0, 0, 0, 0),
(91, 91, '', 0, 0, 0, 0, 0, 0, 0),
(92, 92, '', 0, 0, 0, 0, 0, 0, 0),
(93, 93, '', 0, 0, 0, 0, 0, 0, 0),
(94, 94, '', 0, 0, 0, 0, 0, 0, 0),
(95, 95, '', 0, 0, 0, 0, 0, 0, 0),
(96, 96, '', 0, 0, 0, 0, 0, 0, 0),
(97, 97, '', 0, 0, 0, 0, 0, 0, 0),
(98, 98, '', 0, 0, 0, 0, 0, 0, 0),
(99, 99, '', 0, 0, 0, 0, 0, 0, 0),
(100, 100, '', 0, 0, 0, 0, 0, 0, 0),
(101, 101, 'payment_history', 0, 0, 0, 0, 0, 0, 0),
(102, 102, '', 0, 0, 0, 0, 0, 0, 0),
(103, 103, '', 0, 0, 0, 0, 0, 0, 0),
(104, 104, '', 0, 0, 0, 0, 0, 0, 0),
(105, 105, '', 0, 0, 0, 0, 0, 0, 0),
(106, 106, '', 0, 0, 0, 0, 0, 0, 0),
(107, 107, '', 0, 0, 0, 0, 0, 0, 0),
(108, 108, '', 0, 0, 0, 0, 0, 0, 0),
(109, 109, '', 0, 0, 0, 0, 0, 0, 0),
(110, 110, '', 0, 0, 0, 0, 0, 0, 0),
(111, 111, '', 0, 0, 0, 0, 0, 0, 0),
(112, 112, '', 0, 0, 0, 0, 0, 0, 0),
(113, 113, '', 0, 0, 0, 0, 0, 0, 0),
(114, 114, '', 0, 0, 0, 0, 0, 0, 0),
(115, 115, '', 0, 0, 0, 0, 0, 0, 0),
(116, 116, '', 0, 0, 0, 0, 0, 0, 0),
(117, 117, '', 0, 0, 0, 0, 0, 0, 0),
(118, 118, '', 0, 0, 0, 0, 0, 0, 0),
(119, 119, '', 0, 0, 0, 0, 0, 0, 0),
(120, 120, '', 0, 0, 0, 0, 0, 0, 0),
(121, 121, '', 0, 0, 0, 0, 0, 0, 0),
(122, 122, '', 0, 0, 0, 0, 0, 0, 0),
(123, 123, '', 0, 0, 0, 0, 0, 0, 0),
(124, 124, '', 0, 0, 0, 0, 0, 0, 0),
(125, 125, '', 0, 0, 0, 0, 0, 0, 0),
(126, 126, '', 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `package_info`
--

CREATE TABLE `package_info` (
  `package_info_id` int(11) NOT NULL,
  `package_id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `quantity` int(3) NOT NULL,
  `doc` date NOT NULL,
  `dom` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `creator` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `package_info`
--

INSERT INTO `package_info` (`package_info_id`, `package_id`, `product_id`, `quantity`, `doc`, `dom`, `creator`) VALUES
(1, 220, 133, 1, '2015-10-21', '2015-10-20 18:00:00', 17),
(2, 221, 86, 1, '2015-10-21', '2015-10-20 18:00:00', 17),
(3, 221, 213, 1, '2015-10-21', '2015-10-20 18:00:00', 17),
(4, 221, 105, 1, '2015-10-21', '2015-10-20 18:00:00', 17),
(5, 222, 213, 1, '2015-10-21', '2015-10-20 18:00:00', 17),
(6, 222, 140, 1, '2015-10-21', '2015-10-20 18:00:00', 17),
(7, 223, 106, 1, '2015-10-21', '2015-10-20 18:00:00', 17),
(8, 223, 100, 1, '2015-10-21', '2015-10-20 18:00:00', 17),
(9, 223, 86, 1, '2015-10-21', '2015-10-20 18:00:00', 17),
(10, 220, 94, 1, '2015-10-21', '2015-10-20 18:00:00', 17);

-- --------------------------------------------------------

--
-- Table structure for table `payment_history`
--

CREATE TABLE `payment_history` (
  `payment_history_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `reservation_id` int(11) DEFAULT NULL,
  `payment_amount` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 0,
  `userID` int(11) DEFAULT NULL,
  `DOC` datetime DEFAULT current_timestamp(),
  `DOM` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prep_options`
--

CREATE TABLE `prep_options` (
  `prep_options_id` int(11) NOT NULL,
  `option_name` varchar(240) NOT NULL,
  `creator` int(20) NOT NULL,
  `doc` date NOT NULL,
  `dom` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prep_options`
--

INSERT INTO `prep_options` (`prep_options_id`, `option_name`, `creator`, `doc`, `dom`) VALUES
(1, 'Spicy', 14, '2015-06-01', '2015-05-31 18:00:00'),
(3, 'Extra Sauce', 15, '2015-06-08', '2015-06-07 18:00:00'),
(4, 'Without oil', 15, '2015-06-08', '2015-06-07 18:00:00'),
(5, 'Extra chilli', 15, '2015-06-08', '2015-06-07 18:00:00'),
(6, 'None', 15, '2015-06-08', '2015-06-07 18:00:00'),
(7, 'Cool', 15, '2015-06-08', '2015-06-07 18:00:00'),
(8, 'Full Hot', 15, '2015-06-08', '2015-06-07 18:00:00'),
(10, 'FOOD WITH RAPPING', 15, '2015-06-09', '2015-06-08 18:00:00'),
(11, 'Quick Service', 15, '2015-10-03', '2015-10-02 18:00:00'),
(12, 'nice Test', 15, '2015-10-03', '2015-10-02 18:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(130) NOT NULL,
  `back_color` varchar(50) NOT NULL,
  `font_color` varchar(50) NOT NULL,
  `resource_category` varchar(8) NOT NULL,
  `creator` varchar(30) NOT NULL,
  `doc` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `category_discr` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`category_id`, `category_name`, `back_color`, `font_color`, `resource_category`, `creator`, `doc`, `category_discr`) VALUES
(8, 'Chinese Soup', '#e64a00', '#ffffff', '0', '14', '2015-10-21 15:04:15', ''),
(9, 'Beverage/ Drinks', '#e64a00', '#ffffff', '0', '14', '2015-10-21 15:04:40', ''),
(10, 'Noodles', '#e64a00', '#ffffff', '0', '14', '2015-10-21 15:04:48', ''),
(29, 'Fast Food', '#004080', '#ffffff', '0', '12', '2019-12-29 13:31:13', 'dsfg'),
(30, 'Pasta & Chowmein', '#000000', '#ffffff', '0', '12', '2019-12-31 09:40:26', ''),
(31, 'Pasta & Chowmein', '#000000', '#ffffff', '0', '12', '2019-12-31 09:40:37', ''),
(32, 'Chicken', '#000000', '#ffffff', '0', '12', '2019-12-31 09:40:47', ''),
(33, 'Sub Sandwich', '#000000', '#ffffff', '0', '12', '2019-12-31 09:40:54', ''),
(34, 'Pizza', '#000000', '#ffffff', '0', '12', '2019-12-31 09:41:14', ''),
(35, 'Chicken Burger', '#000000', '#ffffff', '0', '12', '2019-12-31 09:41:21', ''),
(36, 'Soup', '#000000', '#ffffff', '0', '12', '2019-12-31 09:41:30', ''),
(37, 'Coffee Item', '#000000', '#ffffff', '0', '12', '2019-12-31 09:41:36', ''),
(38, 'Juice & Beverage', '#000000', '#ffffff', '0', '12', '2019-12-31 09:41:44', ''),
(39, 'Icecream', '#ff0000', '#ffffff', '0', '12', '2019-12-31 09:41:52', ''),
(40, 'Water', '#000000', '#000000', '0', '12', '2020-01-01 10:04:13', '');

-- --------------------------------------------------------

--
-- Table structure for table `product_info`
--

CREATE TABLE `product_info` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `sale_price` int(11) NOT NULL,
  `cost_price` int(11) NOT NULL,
  `stock_amount` int(10) NOT NULL,
  `unit_name` int(8) NOT NULL,
  `category` int(20) NOT NULL,
  `product_code` varchar(30) NOT NULL,
  `show_in_kitchen` varchar(10) NOT NULL,
  `service_insert_id` int(10) NOT NULL,
  `package_definition` varchar(10) NOT NULL DEFAULT '0',
  `creator` int(20) NOT NULL,
  `DOC` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DOM` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_info`
--

INSERT INTO `product_info` (`product_id`, `product_name`, `sale_price`, `cost_price`, `stock_amount`, `unit_name`, `category`, `product_code`, `show_in_kitchen`, `service_insert_id`, `package_definition`, `creator`, `DOC`, `DOM`) VALUES
(31, 'Green', 100, 100, -16, 1, 3, 'S5', 'YES', 39, '0', 14, '2015-10-15 17:00:13', '2015-05-27 13:19:51'),
(32, 'Mixed', 100, 100, -14, 1, 3, 'S6', 'YES', 40, '0', 14, '2016-03-02 09:48:06', '2015-05-27 13:20:21'),
(33, 'Chicken Bhuna', 140, 140, -153, 1, 4, 'B4', 'YES', 41, '0', 14, '2016-03-12 06:22:57', '2015-05-27 13:21:39'),
(34, 'Beef Bhuna', 180, 0, 889, 1, 4, 'B5', 'YES', 42, '0', 14, '2016-03-12 13:36:16', '2015-05-27 13:22:22'),
(35, 'Beef Dupiaza', 260, 0, 1000, 1, 4, 'B6', 'YES', 43, '0', 14, '2016-02-21 09:14:24', '2015-05-27 13:23:25'),
(36, 'Beef Satkara', 260, 0, 927, 1, 4, 'B7', 'YES', 44, '0', 14, '2016-03-11 14:41:38', '2015-05-27 13:24:17'),
(37, 'Beef Jhal Fraizee', 230, 0, 966, 1, 4, 'B8', 'YES', 45, '0', 14, '2016-03-02 10:27:22', '2015-05-27 13:25:12'),
(38, 'Mutton Curry', 150, 150, -1, 1, 4, 'B9', 'YES', 46, '0', 14, '2016-01-25 16:58:37', '2015-05-27 13:25:55'),
(39, 'Mutton Kurma', 200, 200, -2, 1, 4, 'B10', 'YES', 47, '0', 14, '2016-03-03 10:22:33', '2015-05-27 13:26:27'),
(40, 'Mutton Dupiaza', 200, 200, -1, 1, 4, 'B11', 'YES', 48, '0', 14, '2016-02-27 05:13:40', '2015-05-27 13:26:52'),
(41, 'Vegetable Dupiaza', 60, 60, -142, 1, 4, 'B12', 'YES', 49, '0', 14, '2016-03-03 11:09:12', '2015-05-27 13:27:29'),
(42, 'Plain Daal', 45, 45, -207, 1, 4, 'B13', 'YES', 50, '0', 14, '2016-03-12 07:17:19', '2015-05-27 13:28:06'),
(43, 'Daal Butter Fry', 70, 70, -17, 1, 4, 'B14', 'YES', 51, '0', 14, '2016-01-13 07:17:21', '2015-05-27 13:28:37'),
(44, 'Daal Bhuna', 60, 60, -229, 1, 4, 'B15', 'YES', 52, '0', 14, '2016-03-01 16:56:30', '2015-05-27 13:29:28'),
(45, 'Chicken Biriyani', 150, 150, 21, 1, 6, 'BP1', 'YES', 53, '0', 14, '2016-03-12 16:11:16', '2015-05-27 13:32:19'),
(46, 'Hyderbadi Ghost Biriyani', 195, 195, -2, 1, 6, 'BP2', 'YES', 54, '0', 14, '2015-07-20 13:55:09', '2015-05-27 13:33:02'),
(47, 'Beef Biriyani', 180, 0, 987, 1, 6, 'BP3', 'YES', 55, '0', 14, '2016-03-03 09:08:22', '2015-05-27 13:33:53'),
(48, 'Mutton Biriyani', 150, 150, -4, 1, 6, 'BP4', 'YES', 56, '0', 14, '2016-03-12 11:16:43', '2015-05-27 13:34:30'),
(49, 'Vegetable Pulao', 120, 120, -5, 1, 6, 'BP5', 'YES', 57, '0', 14, '2016-02-07 09:19:46', '2015-05-27 13:35:03'),
(50, 'Jeera Pulao', 110, 110, 0, 1, 6, 'BP7', 'YES', 58, '0', 14, '2015-05-31 12:27:48', '2015-05-27 13:35:59'),
(51, 'Plain Pulao', 90, 90, -16, 1, 6, 'BP8', 'YES', 59, '0', 14, '2016-02-05 12:20:35', '2015-05-27 13:36:30'),
(52, 'Peace Pulao', 110, 110, 0, 1, 6, 'BP9', 'YES', 60, '0', 14, '2015-05-31 12:27:48', '2015-05-27 13:37:06'),
(53, 'Kashmiri Pulao', 150, 150, 0, 1, 6, 'BP10', 'YES', 61, '0', 14, '2015-05-31 12:27:48', '2015-05-27 13:37:54'),
(54, 'Garlic', 50, 50, 0, 1, 5, 'N3', 'YES', 62, '0', 14, '2015-05-31 12:27:48', '2015-05-27 13:39:22'),
(55, 'Keema', 90, 90, 0, 1, 5, 'N4', 'YES', 63, '0', 14, '2015-05-31 12:27:48', '2015-05-27 13:39:47'),
(56, 'peshwari', 90, 90, 0, 1, 5, 'N5', 'YES', 64, '0', 14, '2015-05-31 12:27:48', '2015-05-27 13:40:35'),
(57, 'Pad Thai', 350, 350, -3, 1, 10, 'ND1', 'YES', 65, '0', 14, '2016-03-21 07:44:28', '2015-05-27 13:50:07'),
(58, 'Chicken', 190, 190, -163, 1, 10, 'ND2', 'YES', 66, '0', 14, '2016-03-14 07:25:12', '2015-05-27 13:52:40'),
(59, 'Prawn', 210, 210, -14, 1, 10, 'ND3', 'YES', 67, '0', 14, '2015-12-07 16:47:43', '2015-05-27 13:53:10'),
(60, 'Beef Noodles', 210, 0, -3, 1, 10, 'ND4', 'YES', 68, '0', 14, '2016-02-19 13:02:07', '2015-05-27 13:53:41'),
(61, 'Vegetable', 150, 150, -19, 1, 10, 'ND5', 'YES', 69, '0', 14, '2016-03-13 12:10:36', '2015-05-27 13:55:39'),
(62, 'Egg', 160, 160, -37, 1, 10, 'ND6', 'YES', 70, '0', 14, '2016-03-12 16:36:06', '2015-05-27 13:56:13'),
(63, 'Hiltown Special', 280, 280, -15, 1, 10, 'ND7', 'YES', 71, '0', 14, '2016-03-04 15:58:05', '2015-05-27 13:57:00'),
(64, 'Tea- Black', 15, 15, -776, 3, 9, 'bd1', 'YES', 72, '0', 14, '2019-12-31 07:44:30', '2015-05-27 13:59:20'),
(66, 'Tea- Milk', 25, 25, -2349, 3, 9, 'bd2', 'YES', 74, '0', 14, '2016-03-14 06:15:22', '2015-05-27 13:59:58'),
(67, 'Coffee- Black', 40, 0, 67, 3, 9, 'bd3', 'NO', 75, '0', 14, '2016-02-06 13:47:38', '2015-05-27 14:01:02'),
(68, 'Coffee With Coffee Mate', 80, 80, 100, 3, 9, 'BD4', 'YES', 76, '0', 14, '2015-10-12 16:53:36', '2015-05-27 14:03:18'),
(69, 'Ice Coffee', 60, 60, 66, 3, 9, 'bd5', 'YES', 77, '0', 14, '2015-10-29 14:45:02', '2015-05-27 14:04:05'),
(70, 'Soft Drinks', 20, 20, -1315, 5, 9, 'bd6', 'YES', 78, '0', 14, '2016-03-14 07:48:06', '2015-05-27 14:05:05'),
(71, 'Mineral (1500)', 30, 30, -2272, 5, 9, 'bd7', 'YES', 79, '0', 14, '2016-03-14 07:53:44', '2015-05-27 14:06:10'),
(72, 'Mineral (500)', 20, 0, -390, 5, 9, 'bd8', 'NO', 80, '0', 14, '2016-03-14 06:44:05', '2015-05-27 14:06:41'),
(73, 'Ice Cream (Vanilla, Stawbery)', 70, 70, -7, 1, 9, 'BD9', 'NO', 81, '0', 14, '2015-12-27 10:02:24', '2015-05-27 14:07:22'),
(74, 'Milk Shake', 80, 80, 74, 6, 9, 'BD11', 'NO', 82, '0', 14, '2016-03-22 11:27:07', '2015-05-27 14:07:59'),
(76, 'Lassi', 100, 100, -31, 6, 9, 'BD12', 'NO', 84, '0', 14, '2016-03-12 04:17:32', '2015-05-27 14:10:23'),
(77, 'Chicken & Vegetable Soup', 180, 180, 88, 1, 8, 'CS1', 'YES', 85, '0', 14, '2020-01-01 09:01:51', '2015-05-27 14:14:56'),
(78, 'Chicken Corn Soup', 180, 180, -73, 1, 8, 'CS2', 'YES', 86, '0', 14, '2016-03-10 16:08:30', '2015-05-27 14:15:36'),
(79, 'Szechuan Soup', 300, 300, -5, 1, 8, 'CS3', 'YES', 87, '0', 14, '2016-01-31 14:31:46', '2015-05-27 14:16:20'),
(80, 'Hot & Sour Soup', 240, 240, -8, 1, 8, 'CS4', 'YES', 88, '0', 14, '2016-01-30 15:21:51', '2015-05-27 14:17:10'),
(81, 'Chicken Noodles Soup', 170, 170, 0, 1, 8, 'CS5', 'YES', 89, '0', 14, '2015-05-31 12:27:48', '2015-05-27 14:17:37'),
(82, 'Szechuan Fried Chicken', 280, 280, -1, 1, 7, 'c1', 'YES', 90, '0', 14, '2015-06-16 15:35:54', '2015-05-28 10:19:04'),
(83, 'Chicken Chili Onion', 270, 270, 85, 1, 7, 'c2', 'YES', 91, '0', 14, '2016-02-27 07:55:11', '2015-05-28 10:19:34'),
(84, 'Chicken in Garlic Sauce', 280, 280, -2, 1, 7, 'c3', 'YES', 92, '0', 14, '2016-03-08 08:57:01', '2015-05-28 10:20:27'),
(85, 'Sweet & Sour Chicken', 290, 290, 0, 1, 7, 'c4', 'YES', 93, '0', 14, '2015-05-31 12:27:48', '2015-05-28 10:21:17'),
(86, 'Masala Chicken', 280, 280, -58, 1, 7, 'c5', 'YES', 94, '0', 14, '2016-03-13 14:41:46', '2015-05-28 10:21:58'),
(87, 'Hot Sauce Chicken', 290, 290, -1, 1, 7, 'c6', 'YES', 95, '0', 14, '2016-02-10 09:53:15', '2015-05-28 10:22:45'),
(88, 'Chicken Jhal Fry', 290, 290, -2, 1, 7, 'c7', 'YES', 96, '0', 14, '2015-11-03 09:29:49', '2015-05-28 10:24:02'),
(89, 'Prawn Masala', 350, 350, -36, 1, 7, 'c8', 'YES', 97, '0', 14, '2016-03-05 11:52:49', '2015-05-28 10:24:37'),
(90, 'Special China Prawn', 320, 320, 0, 1, 7, 'c9', 'YES', 98, '0', 14, '2015-05-31 12:27:48', '2015-05-28 10:25:17'),
(91, 'Sweet & Sour Prawn', 350, 350, -1, 1, 7, 'c10', 'YES', 99, '0', 14, '2016-01-26 16:20:24', '2015-05-28 10:25:50'),
(92, 'Prawn with Garlic Sauce', 350, 350, 0, 1, 7, 'c11', 'YES', 100, '0', 14, '2015-05-31 12:27:48', '2015-05-28 10:45:41'),
(93, 'Prawn Chili Onion', 350, 350, -3, 1, 7, 'c12', 'YES', 101, '0', 14, '2016-02-19 15:27:23', '2015-05-28 10:46:41'),
(94, 'Beef Chili Dry', 330, 0, 1000, 1, 7, 'c13', 'YES', 102, '0', 14, '2016-01-11 09:33:45', '2015-05-28 10:47:14'),
(95, 'Beef Chili Onion', 310, 0, 1000, 1, 7, 'c14', 'YES', 103, '0', 14, '2016-02-21 09:53:02', '2015-05-28 10:48:47'),
(96, 'Beef Masala', 310, 0, 996, 1, 7, 'c15', 'YES', 104, '0', 14, '2016-02-21 15:58:37', '2015-05-28 10:50:16'),
(97, 'Beef Garlic Sauce', 310, 0, 1000, 1, 7, 'c16', 'YES', 105, '0', 14, '2016-01-11 09:36:21', '2015-05-28 10:51:09'),
(98, 'Hot Sauce Beef', 280, 280, 0, 1, 7, 'c17', 'YES', 106, '0', 14, '2015-05-31 12:27:48', '2015-05-28 10:52:07'),
(99, 'Sweet Sauce Beef', 290, 290, -1, 1, 7, 'c18', 'YES', 107, '0', 14, '2015-12-24 14:49:47', '2015-05-28 10:53:47'),
(100, 'Mixed Vegetable', 150, 150, -40, 1, 7, 'c19', 'YES', 108, '0', 14, '2016-02-23 15:10:27', '2015-05-28 10:54:36'),
(101, 'Chicken Vegetable', 180, 180, -30, 1, 7, 'c20', 'YES', 109, '0', 14, '2016-03-10 16:54:26', '2015-05-28 10:55:35'),
(102, 'Prawn Vegetable', 200, 200, -2, 1, 7, 'c21', 'YES', 110, '0', 14, '2016-01-11 16:39:42', '2015-05-28 10:56:25'),
(103, 'Beef Vegetable', 250, 0, 1000, 1, 7, 'c22', 'YES', 111, '0', 14, '2016-02-21 09:53:45', '2015-05-28 10:56:55'),
(104, 'Chicken & Mushroom Vegetable', 250, 250, -4, 1, 7, 'c23', 'YES', 112, '0', 14, '2016-02-19 15:27:54', '2015-05-28 10:58:15'),
(105, 'Egg Fried Rice', 180, 180, 51, 1, 11, 'cr1', 'YES', 113, '0', 14, '2016-03-10 16:54:16', '2015-05-28 11:02:52'),
(106, 'Chicken Fried Rice', 190, 190, -41, 1, 11, 'cr2', 'YES', 114, '0', 14, '2016-03-13 16:23:49', '2015-05-28 11:03:24'),
(107, 'Szechuan Fried Rice', 250, 250, -2, 1, 11, 'cr3', 'YES', 115, '0', 14, '2015-10-31 12:11:05', '2015-05-28 11:05:03'),
(108, 'Vegetable Fried Rice', 160, 160, -10, 1, 11, 'cr4', 'YES', 116, '0', 14, '2015-12-24 15:05:29', '2015-05-28 11:05:39'),
(109, 'Masala Fried Rice', 230, 230, 0, 1, 11, 'cr5', 'YES', 117, '0', 14, '2015-05-31 12:27:48', '2015-05-28 11:06:27'),
(110, 'Special Fried Rice', 260, 260, -20, 1, 11, 'cr6', 'YES', 118, '0', 14, '2016-01-12 17:50:39', '2015-05-28 11:07:01'),
(111, 'Prawn Fried Rice', 200, 200, -4, 1, 11, 'cr7', 'YES', 119, '0', 14, '2016-01-11 16:38:41', '2015-05-28 11:08:44'),
(112, 'Beef Fried Rice', 200, 0, 1000, 1, 11, 'cr8', 'YES', 120, '0', 14, '2016-01-11 09:36:47', '2015-05-28 11:09:26'),
(113, 'Streamed Rice', 120, 120, -2, 1, 11, 'cr9', 'YES', 121, '0', 14, '2015-12-24 09:27:43', '2015-05-28 11:10:11'),
(114, 'Chicken', 190, 190, -15, 1, 12, 'ch1', 'YES', 122, '0', 14, '2015-10-24 10:38:25', '2015-05-28 11:11:47'),
(115, 'Beef', 200, 0, 1000, 1, 12, 'ch2', 'YES', 123, '0', 14, '2016-01-11 09:37:24', '2015-05-28 11:12:13'),
(116, 'Hiltown Special', 280, 280, -3, 1, 12, 'ch3', 'YES', 124, '0', 14, '2015-10-23 16:34:01', '2015-05-28 11:12:55'),
(117, 'American', 250, 250, 0, 1, 12, 'ch4', 'YES', 125, '0', 14, '2015-05-31 12:27:48', '2015-05-28 11:13:25'),
(118, 'Hiltown Special Sizzling', 450, 450, -12, 1, 13, 'sz1', 'YES', 126, '0', 12, '2016-01-11 09:56:40', '2015-05-28 13:20:12'),
(119, 'Beef Sizzling', 360, 0, 994, 1, 13, 'sz2', 'YES', 127, '0', 12, '2016-02-07 15:55:49', '2015-05-28 13:20:56'),
(120, 'Chicken Sizzling', 320, 320, -11, 1, 13, 'sz3', 'YES', 128, '0', 12, '2016-03-08 08:58:26', '2015-05-28 13:21:27'),
(121, 'Prawn Sizzling', 350, 350, -2, 1, 13, 'sz3', 'YES', 129, '0', 12, '2016-01-15 15:13:52', '2015-05-28 13:22:16'),
(122, 'Plain', 35, 35, -1766, 1, 15, 'rice', 'YES', 130, '0', 14, '2016-03-12 13:36:10', '2015-06-01 09:35:58'),
(123, 'Coffee - Milk', 60, 60, -562, 3, 9, 'coffee', 'YES', 131, '0', 15, '2016-03-12 06:37:05', '2015-06-03 10:22:32'),
(124, 'Traditional 1: Parata/ Chapati, Mix Veg./ Egg/, Tea/Coffee', 120, 120, -20, 2, 17, 'br1', 'YES', 132, '0', 15, '2019-12-29 13:26:57', '2015-06-05 12:55:39'),
(125, 'Traditional 2: Plain Naan, Mix Veg./ Egg/, Tea/Coffee', 120, 120, 100, 2, 17, 'br2', 'YES', 133, '0', 15, '2015-06-06 13:08:18', '2015-06-05 12:56:15'),
(126, 'Continental: Toast (With butter jam)/ Omelette Tea/ Coffee', 100, 100, 0, 2, 17, 'br3', 'YES', 134, 'on', 15, '2015-06-05 13:01:45', '2015-06-05 12:58:03'),
(127, 'Omelette', 25, 25, 0, 1, 17, 'br4', 'YES', 135, 'on', 15, '2015-06-05 12:59:18', '2015-06-05 12:59:18'),
(128, 'Scrambled Eggs on Toast', 60, 60, 62, 1, 17, 'br5', 'YES', 136, '0', 15, '2016-03-12 06:36:25', '2015-06-05 13:00:09'),
(129, 'French Bread (sweet)', 60, 60, -15, 1, 17, 'br6', 'YES', 137, '0', 15, '2015-10-17 07:25:56', '2015-06-05 13:01:06'),
(130, 'Parata- Plain', 30, 30, -2325, 4, 17, 'br7', 'YES', 138, '0', 15, '2016-03-14 03:11:29', '2015-06-05 13:03:16'),
(131, 'Parata- Shahi', 60, 60, -16, 4, 17, 'br8', 'YES', 139, '0', 15, '2016-03-04 03:45:34', '2015-06-05 13:03:43'),
(132, 'Chapati', 30, 30, -339, 4, 17, 'br9', 'YES', 140, '0', 15, '2016-03-13 14:41:57', '2015-06-05 13:04:36'),
(133, 'Vegetable', 60, 60, -987, 1, 17, 'br10', 'YES', 141, '0', 15, '2016-03-13 03:06:58', '2015-06-05 13:05:14'),
(134, 'Daal Bhuna', 60, 60, -598, 1, 17, 'br11', 'YES', 142, '0', 15, '2016-03-13 14:42:10', '2015-06-05 13:05:45'),
(135, 'Tea', 25, 25, 161, 3, 17, 'tea', 'YES', 143, '0', 15, '2016-03-04 14:29:38', '2015-06-05 13:06:15'),
(136, 'Coffee', 60, 60, 321, 3, 17, 'coffee', 'YES', 144, '0', 15, '2016-03-14 06:56:42', '2015-06-05 13:06:46'),
(137, 'Stuff Rice', 25, 0, -101, 1, 18, 'sr1', 'YES', 145, '0', 14, '2016-03-13 10:33:44', '2015-06-06 13:02:45'),
(138, 'Stuff Curry', 40, 40, -97, 1, 18, 'curry', 'YES', 146, '0', 14, '2016-03-13 10:33:47', '2015-06-06 13:03:14'),
(139, 'Stuff Daal', 20, 20, -54, 1, 18, 'daal', 'YES', 147, '0', 14, '2016-03-13 10:33:53', '2015-06-06 13:04:37'),
(140, 'Thai Fried Chicken', 380, 0, -46, 1, 19, 't1', 'YES', 148, '0', 15, '2019-12-29 13:26:45', '2015-06-07 06:52:05'),
(141, 'Bankok Style Fried Chicken', 320, 0, 100, 1, 19, 't2', 'YES', 149, '0', 15, '2015-10-28 10:30:36', '2015-06-07 06:52:42'),
(142, 'Green Chicken Curry', 340, 0, 100, 1, 19, 't3', 'YES', 150, '0', 15, '2015-06-07 06:53:52', '2015-06-07 06:53:52'),
(143, 'Foil Chicken', 450, 0, 100, 1, 19, 't4', 'YES', 151, '0', 15, '2015-06-07 06:55:00', '2015-06-07 06:55:00'),
(144, 'Slice Chicken Red Curry', 350, 0, 100, 1, 19, 't5', 'YES', 152, '0', 15, '2015-06-07 06:55:48', '2015-06-07 06:55:48'),
(145, 'Beef Red Curry', 370, 0, 98, 1, 19, 't6', 'YES', 153, '0', 15, '2016-01-11 10:56:19', '2015-06-07 06:56:45'),
(146, 'Beef In Oyster Sauce', 310, 0, 100, 1, 19, 't7', 'YES', 154, '0', 15, '2016-01-11 10:56:02', '2015-06-07 06:57:26'),
(147, 'King Prawn Masala', 550, 0, 100, 1, 19, 't8', 'YES', 155, '0', 15, '2015-06-07 06:59:30', '2015-06-07 06:58:28'),
(148, 'Special King Prawn', 560, 0, 100, 1, 19, 't9', 'YES', 156, '0', 15, '2015-06-07 06:59:14', '2015-06-07 06:59:14'),
(149, 'Prawn With Green Peas', 350, 0, 99, 1, 19, 't9', 'YES', 157, '0', 15, '2015-10-24 16:41:30', '2015-06-07 07:00:13'),
(150, 'Thai Fried Rice', 300, 0, 89, 1, 20, 'tr1', 'YES', 158, '0', 15, '2016-02-16 08:49:03', '2015-06-07 07:03:04'),
(151, 'Hiltown Special Fried Rice', 330, 0, 91, 1, 20, 'tr2', 'YES', 159, '0', 15, '2016-01-26 16:19:36', '2015-06-07 07:03:39'),
(152, 'Thai Vegetable Fried Rice', 280, 0, 99, 1, 20, 'tr3', 'YES', 160, '0', 15, '2015-10-24 16:26:10', '2015-06-07 07:04:19'),
(153, 'Thai Mixed Vegetable ', 300, 0, 99, 1, 21, 'tv1', 'YES', 161, '0', 15, '2015-12-10 13:48:52', '2015-06-07 07:05:15'),
(154, 'Hiltown Special Vegetable ', 330, 0, 99, 1, 21, 'tv2', 'YES', 162, '0', 15, '2015-12-14 15:00:32', '2015-06-07 07:05:47'),
(155, 'Tomato Shorba', 90, 0, 100, 1, 22, 'is1', 'YES', 163, '0', 15, '2015-12-10 13:48:52', '2015-06-07 07:08:59'),
(156, 'Mulligatawny Soup', 110, 0, 100, 1, 22, 'is2', 'YES', 164, '0', 15, '2015-06-07 07:09:51', '2015-06-07 07:09:51'),
(157, 'Rui Fish Large', 160, 0, 14, 1, 4, 'rui', 'YES', 165, '0', 14, '2016-03-07 06:24:25', '2015-06-10 08:57:00'),
(158, 'Rui Fish Small', 120, 0, 83, 1, 4, 'ruis', 'YES', 166, '0', 14, '2016-02-10 08:32:47', '2015-06-10 12:07:07'),
(159, 'Pabda Fish Small', 250, 0, 8, 1, 4, 'pabda', 'YES', 167, '0', 14, '2016-02-10 09:52:59', '2015-06-10 12:07:58'),
(160, 'Pabda Fish Large', 350, 0, 48, 1, 4, 'pabdas', 'YES', 168, '0', 14, '2016-03-04 12:37:34', '2015-06-10 12:08:31'),
(161, 'Rupchada Large', 350, 0, -8, 1, 4, 'rupchada', 'YES', 169, '0', 14, '2016-03-12 06:37:27', '2015-06-10 12:09:16'),
(162, 'Rupchada Small', 250, 0, 571, 1, 4, 'rupchadas', 'YES', 170, '0', 14, '2016-03-12 07:16:47', '2015-06-10 12:09:36'),
(163, 'Koi Large', 150, 0, 100, 1, 4, 'koi', 'YES', 171, '0', 14, '2015-06-10 12:10:02', '2015-06-10 12:10:02'),
(164, 'Chicken Mughlai', 120, 0, 917, 1, 1, 'A18', 'YES', 172, '0', 15, '2016-03-12 14:44:07', '2015-06-14 12:08:11'),
(165, 'Thai Soup Special', 290, 0, 840, 1, 25, 'ts1', 'YES', 173, '0', 15, '2016-03-10 16:08:17', '2015-06-15 13:29:26'),
(166, 'Tom Yum Gong/ Gai', 380, 0, 1000, 1, 25, 'ts2', 'YES', 174, '0', 15, '2015-06-15 13:30:05', '2015-06-15 13:30:05'),
(167, 'Thai Corn Soup', 220, 0, 989, 1, 25, 'ts3', 'YES', 175, '0', 15, '2016-01-28 15:24:00', '2015-06-15 13:30:35'),
(168, 'Thai Clear Vegetable Soup', 250, 0, 992, 1, 25, 'ts4', 'YES', 176, '0', 15, '2015-12-24 17:12:07', '2015-06-15 13:31:25'),
(169, 'Hiltown Special Soup', 350, 0, 999, 1, 25, 'ts5', 'YES', 177, '0', 15, '2015-12-29 15:02:11', '2015-06-15 13:31:54'),
(170, 'Sweet And Sour king Prawn Soup', 550, 0, 998, 1, 25, 'ts6', 'YES', 178, '0', 15, '2016-02-06 14:44:17', '2015-06-15 13:32:44'),
(171, 'Complimentary Breakfast 1', 30, 0, 257, 2, 26, 'cb1', 'YES', 179, '0', 15, '2016-03-14 02:55:09', '2015-06-16 12:42:05'),
(172, 'Complimentary Fresh 1 ( L )', 15, 0, 81, 5, 26, 'cb2', 'YES', 180, '0', 15, '2016-03-14 02:55:16', '2015-06-16 12:42:35'),
(173, 'Complimentary Fresh 500 ml', 15, 0, 1893, 5, 26, 'cb3', 'YES', 181, '0', 15, '2016-03-14 01:08:25', '2015-06-16 12:42:57'),
(174, 'Set Menu 1', 270, 0, 994, 2, 27, 'Sarbot, Dates 2pcs, Jilapi 1 p', 'YES', 182, '0', 14, '2015-07-02 14:48:59', '2015-06-20 09:06:49'),
(175, 'Set Menu 2', 330, 0, 1000, 2, 27, 'Sarbot, Dates 2pcs, Jilapi 1 p', 'YES', 183, '0', 14, '2015-06-20 09:09:48', '2015-06-20 09:09:48'),
(176, 'Set Menu 3', 580, 0, 1000, 2, 27, 'Fresh Fruit Juice, Dates 2pcs,', 'YES', 184, '0', 14, '2015-06-20 09:12:48', '2015-06-20 09:12:48'),
(177, 'Set Menu 4', 650, 0, 1000, 2, 27, 'Black Current Juice, Dates 2pc', 'YES', 185, '0', 14, '2015-06-20 09:21:24', '2015-06-20 09:17:04'),
(178, 'VIP Menu', 750, 0, 1000, 2, 27, 'vip', 'YES', 186, '0', 14, '2015-06-20 09:36:28', '2015-06-20 09:20:45'),
(179, 'Chicken Noodles Soup', 170, 0, 999, 1, 8, 'cs5', 'YES', 187, '0', 14, '2016-01-15 16:18:27', '2015-07-22 09:50:37'),
(180, 'M Water 2 Ltr', 35, 0, 968, 5, 9, '2ltr', 'YES', 188, '0', 14, '2015-10-24 08:54:28', '2015-07-23 07:48:53'),
(181, 'Chicken Dupiaza', 220, 0, 100, 1, 4, 'chicdup', 'YES', 189, 'on', 14, '2015-10-12 07:28:35', '2015-07-23 09:19:20'),
(182, 'Hiltown Special Noodles', 280, 0, 1000, 1, 10, 'hilnood', 'YES', 190, 'on', 14, '2015-10-12 07:36:13', '2015-07-23 10:11:58'),
(183, 'Chicken Kurma', 250, 0, 998, 1, 4, 'kurma', 'YES', 191, '0', 14, '2015-07-24 09:37:58', '2015-07-24 09:37:01'),
(184, 'Achari Murgh-1 person', 200, 0, 998, 1, 23, 'ind1', 'YES', 192, '0', 14, '2016-01-15 15:14:05', '2015-08-06 14:00:03'),
(185, 'Beef Achari ', 200, 0, 998, 1, 23, 'ind2', 'YES', 193, '0', 14, '2016-01-11 10:55:16', '2015-08-06 14:01:18'),
(186, 'Beef bhuna', 180, 0, 1000, 1, 23, 'ind7', 'YES', 194, '0', 14, '2016-01-11 10:53:28', '2015-08-06 14:02:05'),
(187, 'Amritsari Tikka Masala', 200, 0, 1000, 1, 23, 'ind2', 'YES', 195, '0', 14, '2015-08-07 09:04:56', '2015-08-07 09:04:56'),
(188, 'Mix Salad', 100, 0, 992, 1, 3, 'mixsalad', 'YES', 196, '0', 14, '2016-01-26 08:39:00', '2015-08-09 11:56:53'),
(189, 'Chiken Mughlai', 120, 0, 934, 1, 1, 'chickenmughlai', 'YES', 197, '0', 14, '2016-03-14 06:43:55', '2015-08-09 11:58:00'),
(190, 'chicmas', 280, 0, 99, 1, 7, 'chicken masala', 'YES', 198, '0', 17, '2015-10-12 07:32:28', '2015-09-22 12:54:02'),
(191, 'Fresh Orange Juice', 110, 0, 954, 6, 9, 'foj', 'NO', 199, '0', 17, '2016-03-12 03:23:43', '2015-10-08 11:10:21'),
(192, 'Fresh Mango Juice', 110, 0, 997, 6, 9, 'fmj', 'NO', 200, '0', 17, '2016-03-05 11:58:32', '2015-10-08 11:10:45'),
(193, 'Ice Cream', 60, 0, -36, 3, 9, 'ic', 'YES', 201, '0', 17, '2016-02-20 06:48:25', '2015-10-08 11:13:27'),
(194, 'Half Chicken', 86, 0, 954, 1, 4, 'hc', 'YES', 202, '0', 17, '2016-03-09 15:33:54', '2015-10-08 11:14:42'),
(195, 'Half Beef', 90, 0, 998, 1, 4, 'hb', 'YES', 203, '0', 17, '2016-01-11 10:52:52', '2015-10-08 11:15:41'),
(196, 'Coke 1 Ltr', 60, 0, 993, 7, 9, 'coke', 'YES', 204, '0', 17, '2015-10-28 16:40:29', '2015-10-13 14:47:38'),
(197, 'Parata', 10, 0, 865, 4, 26, 'cmt1', 'YES', 205, '0', 17, '2016-01-31 01:58:34', '2015-10-13 14:48:53'),
(198, 'chapati', 10, 0, 994, 4, 26, 'cmt2', 'YES', 206, '0', 17, '2015-11-09 02:10:11', '2015-10-13 14:49:44'),
(199, 'Vegetable', 10, 0, 927, 1, 26, 'cmt3', 'YES', 207, '0', 17, '2016-01-15 03:04:47', '2015-10-13 14:50:20'),
(200, 'Omelette', 10, 0, 944, 1, 26, 'cmt4', 'YES', 208, '0', 17, '2016-01-15 03:04:53', '2015-10-13 14:50:43'),
(201, 'Tea', 10, 0, 954, 3, 26, 'cmt5', 'YES', 209, '0', 17, '2016-01-31 01:58:54', '2015-10-13 14:51:04'),
(202, 'Coffee', 10, 0, 955, 3, 26, 'cmt6', 'YES', 210, '0', 17, '2016-01-15 03:05:00', '2015-10-13 14:51:33'),
(203, 'Plain pulao', 60, 0, 998, 1, 4, 'pp', 'YES', 211, '0', 15, '2015-10-16 14:10:08', '2015-10-14 14:08:59'),
(204, 'Karahi Murgh', 190, 0, 998, 1, 23, 'karahi', 'YES', 212, '0', 15, '2015-12-27 17:01:56', '2015-10-14 14:20:21'),
(205, 'Murgh Mirch masala', 190, 0, 1000, 1, 23, 'murgh mirch', 'YES', 213, '0', 15, '2015-10-14 14:21:15', '2015-10-14 14:21:15'),
(206, 'Beef Panjabi', 190, 0, 1000, 1, 23, 'panjabi', 'YES', 214, '0', 15, '2016-01-11 10:31:12', '2015-10-14 14:21:45'),
(207, 'Beef Karahi', 240, 0, 993, 1, 23, 'beef karahi', 'YES', 215, '0', 15, '2016-03-10 16:28:05', '2015-10-14 14:22:23'),
(208, 'Achari Mutton', 195, 0, 1000, 1, 23, 'achari mutton', 'YES', 216, '0', 15, '2015-10-14 14:23:03', '2015-10-14 14:23:03'),
(209, 'Bhuna Mutton', 190, 0, 1000, 1, 23, 'bhuna mutton', 'YES', 217, '0', 15, '2015-10-14 14:23:29', '2015-10-14 14:23:29'),
(210, 'Mutton Karahi', 250, 0, 1000, 1, 23, 'mutton karahi', 'YES', 218, '0', 15, '2015-10-14 14:24:08', '2015-10-14 14:24:08'),
(211, 'Prawn Masala', 300, 0, 999, 1, 23, 'prawn masala', 'YES', 219, '0', 15, '2015-11-22 11:45:01', '2015-10-14 14:25:02'),
(212, 'Karahi Prawns', 350, 0, 1000, 1, 23, 'karahi prawns', 'YES', 220, '0', 15, '2015-10-14 14:25:40', '2015-10-14 14:25:40'),
(213, 'Mixed Vegetable', 85, 0, 0, 1, 23, 'mixed veg', 'YES', 221, '0', 15, '2015-10-21 15:11:09', '2015-10-14 14:27:55'),
(216, 'vegetable dupiaza', 95, 0, 0, 0, 23, 'veg dupizaza', 'YES', 224, '0', 15, '2015-10-14 15:05:34', '2015-10-14 15:05:34'),
(217, 'vegetable curry', 85, 0, 0, 0, 23, 'vegetable curry', 'YES', 225, '0', 15, '2015-10-14 15:14:17', '2015-10-14 15:14:17'),
(218, 'daal tharka', 90, 0, 1010, 1, 23, 'daal tharka ', 'YES', 226, '0', 15, '2015-12-24 09:54:01', '2015-10-14 15:17:18'),
(219, 'daal butter fry ', 110, 0, 0, 0, 23, 'daal butter fry', 'YES', 227, '0', 15, '2015-10-14 15:19:06', '2015-10-14 15:19:06'),
(220, 'Lunch Box- 3', 270, 0, 1000, 2, 28, 'lb3', 'YES', 228, 'on', 17, '2015-10-21 15:14:43', '2015-10-21 14:22:23'),
(221, 'Lunch Box 4', 200, 0, 1000, 2, 28, 'lb4', 'YES', 229, 'on', 17, '2015-10-21 15:13:52', '2015-10-21 14:24:29'),
(222, 'Lunch Box 1', 350, 0, 1000, 2, 28, 'lb1', 'YES', 230, 'on', 17, '2015-10-21 15:15:32', '2015-10-21 15:15:32'),
(223, 'Lunch Box 2', 320, 0, 1000, 2, 28, 'lb2', 'YES', 231, 'on', 17, '2015-10-21 15:15:54', '2015-10-21 15:15:54'),
(224, 'Bowal Small', 250, 0, 966, 1, 4, 'bowal', 'YES', 232, '0', 17, '2016-03-02 11:02:50', '2015-10-23 13:15:34'),
(225, 'Bowal Big', 300, 0, 943, 1, 4, 'bigbw', 'YES', 233, '0', 17, '2016-03-03 10:23:00', '2015-10-23 13:16:08'),
(226, 'Half Beef', 90, 0, 999, 2, 4, 'beef', 'YES', 234, '0', 15, '2016-02-22 11:47:36', '2015-12-29 09:04:20'),
(227, 'Chicken Biriyani Bangla', 125, 0, 99999, 1, 4, 'B32', 'YES', 235, '0', 15, '2016-01-13 09:29:00', '2016-01-08 10:39:41'),
(228, 'Thai Fried Chicken (Half)', 190, 0, 9981, 1, 19, 't35', 'YES', 236, '0', 15, '2016-03-12 13:52:16', '2016-01-08 10:40:33'),
(229, 'Glass Of Milk', 80, 80, 999, 6, 9, '101', 'YES', 237, '0', 19, '2016-01-10 13:27:13', '2016-01-10 13:26:14'),
(230, 'Begun Bharta', 60, 0, 83, 1, 4, 'bb', 'YES', 238, '0', 15, '2016-03-12 06:38:18', '2016-01-13 15:34:00'),
(231, 'Shutki Bharta', 60, 0, 88, 1, 4, 'bba', 'YES', 239, '0', 15, '2016-03-04 12:40:05', '2016-01-13 15:34:49'),
(232, 'Fish Bharta', 100, 0, 89, 1, 4, 'bbaa', 'YES', 240, '0', 15, '2016-03-04 12:41:41', '2016-01-13 15:35:54'),
(233, 'Alu Bharta', 60, 0, 82, 1, 4, 'bbaaa', 'YES', 241, '0', 15, '2016-03-12 06:39:08', '2016-01-13 15:36:45'),
(234, 'ShimBhazi', 60, 0, 75, 1, 4, 'bbaaac', 'YES', 242, '0', 15, '2016-03-07 06:23:37', '2016-01-13 15:37:34'),
(235, 'Half Vegetable', 30, 0, 1000, 1, 4, 'hv', 'YES', 243, 'on', 15, '2016-01-16 13:29:10', '2016-01-16 13:29:10'),
(236, 'Boiled Egg', 25, 10, 997, 4, 17, 'b12', 'YES', 244, '0', 15, '2016-02-21 02:12:33', '2016-01-17 07:54:22'),
(237, 'Bread Toast With butter Jem (2) p.c.s', 60, 40, 16657, 4, 17, '12345', 'YES', 245, '0', 15, '2016-02-16 15:19:55', '2016-01-18 03:55:47'),
(238, 'Complimentary.Mum 500', 15, 15, 999, 5, 26, 'mum', 'YES', 246, '0', 15, '2016-01-31 01:59:07', '2016-01-29 06:31:13'),
(239, 'Rupchada Medium', 300, 0, 991, 1, 4, 'rpm', 'YES', 247, '0', 19, '2016-03-05 16:53:35', '2016-01-29 09:55:40'),
(240, 'Thai Soup Half', 145, 100, 999, 1, 25, 'TH', 'YES', 248, '0', 15, '2016-01-31 14:54:19', '2016-01-31 14:53:48'),
(241, 'Mum 1500 ml', 20, 20, 9997, 5, 26, 'Mum 1500', 'YES', 249, '0', 15, '2016-02-05 04:26:56', '2016-02-05 03:40:38'),
(243, 'Pabda Medium ', 300, 0, 999, 1, 4, 'pdm', 'YES', 251, '0', 17, '2016-03-07 06:26:23', '2016-03-04 12:38:20'),
(244, 'Berger', 40, 10, 89, 4, 29, '201', 'YES', 252, '0', 12, '2020-01-01 08:58:26', '2019-12-29 13:32:11'),
(245, 'Chicken Pasta', 125, 45, 9955, 0, 30, 'Chicken Pasta', 'YES', 253, '0', 12, '2020-01-04 07:29:18', '2019-12-31 05:45:56'),
(246, 'Naga Pasta', 130, 50, 9995, 4, 30, 'Naga Pasta', 'YES', 254, '0', 12, '2020-01-03 12:37:59', '2019-12-31 05:47:16'),
(247, 'KidzVilla Special Pasta', 180, 70, 9994, 0, 30, 'KidzVilla Special Pasta', 'YES', 255, '0', 12, '2020-01-03 11:02:59', '2019-12-31 05:47:54'),
(248, 'Oven Bake Pasta', 190, 70, 10000, 4, 30, 'Oven Bake Pasta', 'YES', 256, '0', 12, '2020-01-01 06:59:02', '2019-12-31 05:48:24'),
(249, 'Chicken Chowmein', 130, 20, 9995, 4, 30, 'Chicken Chowmein', 'YES', 257, '0', 12, '2020-01-03 14:41:31', '2019-12-31 05:49:16'),
(250, 'Sze-Chuan Chowmein', 140, 35, 10000, 0, 30, 'Sze-Chuan Chowmein', 'YES', 258, '0', 12, '2020-01-01 06:58:01', '2019-12-31 05:50:01'),
(251, 'KidzVilla Special Chowmein', 160, 45, 9998, 0, 30, 'KidzVilla Special Chowmein', 'YES', 259, '0', 12, '2020-01-03 10:21:56', '2019-12-31 05:50:35'),
(252, 'Fried Chicken 1PC', 80, 30, 956, 4, 32, 'Fried Chicken 1PC', 'YES', 260, '0', 12, '2020-01-03 12:37:16', '2019-12-31 05:56:01'),
(253, 'Crispy Chicken Drumstick 1PC', 120, 30, 996, 4, 32, 'Crispy Chicken Drumstick 1PC', 'YES', 261, '0', 12, '2020-01-01 06:55:51', '2019-12-31 05:57:04'),
(254, 'Crispy Chicken Wings 4PCs with French Fry', 280, 80, 999, 4, 32, 'Crispy Chicken Wings 4PCs with', 'YES', 262, '0', 12, '2020-01-03 14:35:07', '2019-12-31 05:58:46'),
(255, 'BBQ Chicken 1PC', 140, 35, 998, 4, 32, 'BBQ Chicken 1PC', 'YES', 263, '0', 12, '2020-01-01 06:52:53', '2019-12-31 05:59:34'),
(256, 'French Fry', 80, 20, 956, 4, 32, 'French Fry', 'YES', 264, '0', 12, '2020-01-04 07:29:30', '2019-12-31 06:00:07'),
(257, 'Chicken Sub Sandwich', 100, 30, 993, 4, 33, 'Chicken Sub Sandwich', 'YES', 265, '0', 12, '2020-01-04 07:28:53', '2019-12-31 06:00:56'),
(258, 'Chicken Cheese Sub Sandwich', 150, 60, 1000, 4, 33, 'Chicken Cheese Sub Sandwich', 'YES', 266, '0', 12, '2019-12-31 06:01:35', '2019-12-31 06:01:35'),
(259, 'Crispy Chicken Sub Sandwich', 130, 25, 1000, 4, 33, 'Crispy Chicken Sub Sandwich', 'YES', 267, '0', 12, '2019-12-31 06:02:16', '2019-12-31 06:02:16'),
(260, 'Naga Chicken Sub Sandwich', 125, 30, 1000, 4, 33, 'Naga Chicken Sub Sandwich', 'YES', 268, '0', 12, '2019-12-31 06:02:55', '2019-12-31 06:02:55'),
(261, 'Chicken Pizza 6 inch', 260, 120, 999, 4, 34, 'Chicken Pizza 6 inch', 'YES', 269, '0', 12, '2020-01-04 05:18:02', '2019-12-31 06:04:07'),
(262, 'Chicken Pizza 10 inch', 380, 130, 1000, 4, 34, 'Chicken Pizza 10 inch', 'YES', 270, '0', 12, '2019-12-31 06:04:38', '2019-12-31 06:04:38'),
(263, 'Chicken BBQ Pizza 6 inch', 300, 120, 1000, 4, 34, 'Chicken BBQ Pizza 6 inch', 'YES', 271, '0', 12, '2019-12-31 06:05:24', '2019-12-31 06:05:24'),
(264, 'Chicken BBQ Pizza 10 inch', 420, 130, 1000, 0, 34, 'Chicken BBQ Pizza 10 inch', 'YES', 272, '0', 12, '2019-12-31 06:06:02', '2019-12-31 06:06:02'),
(265, 'KidzVilla Special Pizza 6 inch', 380, 150, 1000, 4, 34, 'KidzVilla Special Pizza 6 inch', 'YES', 273, '0', 12, '2019-12-31 06:06:56', '2019-12-31 06:06:56'),
(266, 'KidzVilla Special Pizza 10 inch', 540, 160, 1000, 0, 34, 'KidzVilla Special Pizza 10inch', 'YES', 274, '0', 12, '2019-12-31 06:07:20', '2019-12-31 06:07:20'),
(267, 'Mexican Chicken Pizza 6 inch', 380, 150, 1000, 0, 34, 'Mexican Chicken Pizza 6 inch', 'YES', 275, '0', 12, '2019-12-31 06:08:05', '2019-12-31 06:08:05'),
(268, 'Mexican Chicken Pizza 10 inch', 550, 160, 1000, 4, 34, 'Mexican Chicken Pizza 10 inch', 'YES', 276, '0', 12, '2019-12-31 06:08:28', '2019-12-31 06:08:28'),
(270, 'Chicken Crispy Burger', 100, 25, 995, 4, 35, 'Chicken Crispy Burger', 'YES', 278, '0', 12, '2020-01-03 11:28:37', '2019-12-31 06:13:16'),
(271, 'Chicken Crispy Burger', 100, 25, 1000, 4, 35, 'Chicken Crispy Burger', 'YES', 279, '0', 12, '2019-12-31 06:14:07', '2019-12-31 06:14:07'),
(272, 'Chicken Cheese Burger', 120, 25, 963, 4, 35, 'Chicken Cheese Burger', 'YES', 280, '0', 12, '2020-01-03 12:37:45', '2019-12-31 06:15:08'),
(273, 'Double Crunch Chicken Burger', 200, 50, 1000, 4, 35, 'Double Crunch Chicken Burger', 'YES', 281, '0', 12, '2019-12-31 06:15:47', '2019-12-31 06:15:47'),
(274, 'KidzVilla Special Burger', 230, 50, 1000, 4, 35, 'KidzVilla Special Burger', 'YES', 282, '0', 12, '2019-12-31 06:16:24', '2019-12-31 06:16:24'),
(275, 'Chicken Naga Burger', 140, 25, 1000, 4, 35, 'Chicken Naga Burger', 'YES', 283, '0', 12, '2019-12-31 06:17:02', '2019-12-31 06:17:02'),
(276, 'Chicken Naga Burger', 140, 25, 1000, 4, 35, 'Chicken Naga Burger', 'YES', 284, '0', 12, '2019-12-31 06:18:05', '2019-12-31 06:18:05'),
(277, 'Chicken Party Burger', 120, 35, 1000, 4, 35, 'Chicken Party Burger', 'YES', 285, '0', 12, '2019-12-31 06:18:38', '2019-12-31 06:18:38'),
(278, 'BBQ Chicken Burger', 120, 35, 1000, 4, 35, 'BBQ Chicken Burger', 'YES', 286, '0', 12, '2019-12-31 06:19:09', '2019-12-31 06:19:09'),
(279, 'Chicken Corn Soup', 100, 30, 999, 3, 36, 'Chicken Corn Soup', 'YES', 287, '0', 12, '2020-01-02 10:38:58', '2019-12-31 06:20:31'),
(280, 'Vegetable Soup', 80, 20, 1000, 3, 36, 'Vegetable Soup', 'YES', 288, '0', 12, '2019-12-31 06:23:20', '2019-12-31 06:23:20'),
(281, 'Cold Coffee', 80, 40, 1000, 4, 37, 'Cold Coffee', 'YES', 289, '0', 12, '2019-12-31 06:24:53', '2019-12-31 06:24:53'),
(282, 'Hot Coffee', 70, 30, 981, 3, 37, 'Hot Coffee', 'YES', 290, '0', 12, '2020-01-03 11:35:16', '2019-12-31 06:25:31'),
(283, 'Dark Coffee', 70, 20, 1000, 3, 37, 'Dark Coffee', 'YES', 291, '0', 12, '2019-12-31 06:25:57', '2019-12-31 06:25:57'),
(284, 'Cappuccino Coffee', 80, 35, 999, 3, 37, 'Cappuccino Coffee', 'YES', 292, '0', 12, '2019-12-31 11:03:23', '2019-12-31 06:26:33'),
(285, 'Hot Chocolate Coffee', 80, 30, 995, 3, 37, 'Hot Chocolate Coffee', 'YES', 293, '0', 12, '2020-01-01 11:08:32', '2019-12-31 06:27:14'),
(286, 'Strawberry Red Lemon', 80, 30, 995, 6, 38, 'Strawberry Red Lemon', 'YES', 294, '0', 12, '2020-01-01 09:06:04', '2019-12-31 06:28:05'),
(287, 'Mint Lime', 100, 50, 1000, 6, 38, 'Strawberry Red Lemon', 'YES', 295, '0', 12, '2019-12-31 06:29:27', '2019-12-31 06:29:27'),
(288, 'Virgin Mojoto', 80, 30, 997, 5, 38, 'Virgin Mojoto', 'YES', 296, '0', 12, '2020-01-03 14:44:41', '2019-12-31 06:30:03'),
(289, 'Orio Shake', 130, 50, 1000, 6, 38, 'Orio Shake', 'YES', 297, '0', 12, '2019-12-31 06:57:48', '2019-12-31 06:57:48'),
(290, 'Strawberry Shake', 120, 60, 1000, 6, 38, 'Strawberry Shake', 'YES', 298, '0', 12, '2019-12-31 06:59:01', '2019-12-31 06:59:01'),
(291, 'Vanilla Shake', 120, 60, 1000, 6, 38, 'Vanilla Shake', 'YES', 299, '0', 12, '2019-12-31 06:59:26', '2019-12-31 06:59:26'),
(292, 'Mango Shake', 110, 60, 1000, 6, 38, 'Mango Shake', 'YES', 300, '0', 12, '2019-12-31 07:00:29', '2019-12-31 07:00:29'),
(293, 'Chocolate Shake', 110, 60, 1000, 6, 38, 'Chocolate Shake', 'YES', 301, '0', 12, '2019-12-31 07:00:59', '2019-12-31 07:00:59'),
(294, 'Scoope-Vanila', 70, 35, 998, 6, 39, 'Scoope-Vanila', 'YES', 302, '0', 12, '2019-12-31 12:02:15', '2019-12-31 07:02:05'),
(295, 'Scoope-Strawberry', 70, 35, 1000, 3, 39, 'Scoope-Strawberry', 'YES', 303, '0', 12, '2019-12-31 07:17:09', '2019-12-31 07:17:09'),
(296, 'Scoope-Chocolate', 70, 35, 999, 3, 39, 'Scoope-Chocolate', 'YES', 304, '0', 12, '2019-12-31 07:39:42', '2019-12-31 07:17:36'),
(297, 'Scoope-Mango', 70, 35, 1000, 3, 39, 'Scoope-Mango', 'YES', 305, '0', 12, '2019-12-31 07:18:09', '2019-12-31 07:18:09'),
(298, '3 Scoope Mix', 120, 90, 1000, 3, 39, '3 Scoope Mix', 'YES', 306, '0', 12, '2019-12-31 07:18:42', '2019-12-31 07:18:42'),
(299, 'Chicken Pasta', 125, 45, 998, 0, 30, 'Chicken Pasta', 'YES', 307, '0', 12, '2020-01-02 12:48:33', '2019-12-31 15:14:02'),
(300, 'Water 250ml', 10, 6, 44, 4, 40, 'Water 250ml', 'YES', 308, '0', 12, '2020-01-03 14:32:35', '2020-01-01 10:08:35'),
(301, 'Water 500ml', 15, 6, 684, 5, 40, 'Water 500ml', 'YES', 309, '0', 12, '2020-01-03 12:38:12', '2020-01-01 10:09:48');

-- --------------------------------------------------------

--
-- Table structure for table `product_unit_name`
--

CREATE TABLE `product_unit_name` (
  `unit_name_id` int(11) NOT NULL,
  `unitName` varchar(50) NOT NULL,
  `doc` varchar(12) NOT NULL,
  `creator` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_unit_name`
--

INSERT INTO `product_unit_name` (`unit_name_id`, `unitName`, `doc`, `creator`) VALUES
(1, 'portion', '2015-05-31', 12),
(2, 'Package', '2015-06-05', 15),
(3, 'Cup', '2015-06-05', 15),
(4, 'Pcs', '2015-06-05', 15),
(5, 'bottle', '2015-06-06', 14),
(6, 'Glass', '2015-06-06', 15),
(7, 'Littre', '2015-10-13', 17);

-- --------------------------------------------------------

--
-- Table structure for table `rate_setup`
--

CREATE TABLE `rate_setup` (
  `rate_id` int(11) NOT NULL,
  `main_rate_typ` tinyint(1) NOT NULL,
  `rate_type_id` int(11) NOT NULL,
  `room_typ_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `rate_amount` int(11) NOT NULL DEFAULT 0,
  `userID` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0,
  `DOC` datetime DEFAULT current_timestamp(),
  `DOM` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reservation_new`
--

CREATE TABLE `reservation_new` (
  `reservation_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `reservation_date` date NOT NULL,
  `checkin_date` datetime DEFAULT NULL,
  `real_checkin_date` datetime DEFAULT NULL,
  `checkout_date` datetime DEFAULT NULL,
  `real_checkout_date` datetime DEFAULT NULL,
  `cencel_date` datetime DEFAULT NULL,
  `real_cencel_date` datetime DEFAULT NULL,
  `reservation_status` tinyint(1) DEFAULT 0,
  `status` tinyint(1) DEFAULT 0,
  `userID` int(11) DEFAULT NULL,
  `DOC` datetime DEFAULT current_timestamp(),
  `DOM` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservation_new`
--

INSERT INTO `reservation_new` (`reservation_id`, `client_id`, `reservation_date`, `checkin_date`, `real_checkin_date`, `checkout_date`, `real_checkout_date`, `cencel_date`, `real_cencel_date`, `reservation_status`, `status`, `userID`, `DOC`, `DOM`) VALUES
(1, 9, '2015-05-19', '2015-05-19 12:38:29', '2015-05-19 12:38:29', NULL, NULL, NULL, NULL, 2, 0, 2, '2015-05-19 00:21:49', '2015-05-19 00:38:29'),
(2, 1, '2015-05-19', '2015-05-19 12:23:39', '2015-05-19 12:23:39', '2015-05-20 12:26:50', '2015-05-19 12:26:50', NULL, NULL, 3, 0, 2, '2015-05-19 00:22:57', '2015-05-19 00:26:50'),
(3, 5, '2015-05-19', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 2, '2015-05-19 00:37:01', NULL),
(4, 7, '2015-05-14', '2015-05-14 12:40:24', '2015-05-19 12:40:24', '2015-05-17 12:40:47', '2015-05-19 12:40:47', NULL, NULL, 3, 0, 2, '2015-05-19 00:39:47', '2015-05-19 00:40:48'),
(5, 2, '2015-05-19', '2015-05-14 12:44:04', '2015-05-19 12:44:04', '2015-05-19 12:45:04', '2015-05-19 12:45:04', NULL, NULL, 3, 0, 2, '2015-05-19 00:43:33', '2015-05-19 00:45:05'),
(6, 6, '2015-05-18', '2015-05-18 02:07:00', '2015-05-19 02:07:00', '2015-05-19 02:15:48', '2015-05-19 02:15:48', NULL, NULL, 3, 0, 1, '2015-05-19 14:05:39', '2015-05-19 14:15:48');

-- --------------------------------------------------------

--
-- Table structure for table `reserved_room`
--

CREATE TABLE `reserved_room` (
  `reserved_room_id` int(11) NOT NULL,
  `reservation_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `rate_id` int(11) DEFAULT NULL,
  `room_dates` date NOT NULL,
  `is_status` tinyint(1) DEFAULT 0,
  `status` tinyint(1) DEFAULT 0,
  `userID` int(11) DEFAULT NULL,
  `DOC` datetime DEFAULT current_timestamp(),
  `DOM` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_booking`
--

CREATE TABLE `restaurant_booking` (
  `res_booking_id` int(11) NOT NULL,
  `person_name` varchar(150) NOT NULL,
  `contact_number` varchar(18) NOT NULL,
  `address` varchar(200) NOT NULL,
  `booking_place` int(1) NOT NULL,
  `total_person` int(5) NOT NULL,
  `per_person_amount` int(5) NOT NULL,
  `total_amount_main` int(6) NOT NULL,
  `discount_amount` int(5) NOT NULL,
  `hall_rent` int(5) NOT NULL,
  `total_money` int(8) NOT NULL,
  `service_charge` int(5) NOT NULL,
  `total_paid` int(10) NOT NULL,
  `advance` int(7) NOT NULL,
  `due` int(7) NOT NULL,
  `booking_date` date NOT NULL,
  `booking_time` varchar(30) NOT NULL,
  `advance_date` date NOT NULL,
  `programme_name` varchar(200) NOT NULL,
  `comment` varchar(200) NOT NULL,
  `DOC` timestamp NOT NULL DEFAULT current_timestamp(),
  `DOM` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `creator` int(10) NOT NULL,
  `transaction_status` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_booking_menu`
--

CREATE TABLE `restaurant_booking_menu` (
  `booking_menu_id` int(11) NOT NULL,
  `item1` varchar(100) DEFAULT NULL,
  `item2` varchar(100) DEFAULT NULL,
  `item3` varchar(100) DEFAULT NULL,
  `item4` varchar(80) DEFAULT NULL,
  `item5` varchar(80) DEFAULT NULL,
  `item6` varchar(80) DEFAULT NULL,
  `item7` varchar(80) DEFAULT NULL,
  `item8` varchar(80) DEFAULT NULL,
  `item9` varchar(80) DEFAULT NULL,
  `item10` varchar(80) DEFAULT NULL,
  `item11` varchar(80) DEFAULT NULL,
  `item12` varchar(80) DEFAULT NULL,
  `item13` varchar(80) NOT NULL,
  `item14` varchar(80) NOT NULL,
  `booking_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_booking_other`
--

CREATE TABLE `restaurant_booking_other` (
  `booking_other_id` int(11) NOT NULL,
  `other1` varchar(100) DEFAULT NULL,
  `other2` varchar(100) DEFAULT NULL,
  `other3` varchar(100) DEFAULT NULL,
  `other4` varchar(80) DEFAULT NULL,
  `other5` varchar(80) DEFAULT NULL,
  `other6` varchar(80) DEFAULT NULL,
  `price1` int(5) NOT NULL,
  `price2` int(5) NOT NULL,
  `price3` int(5) NOT NULL,
  `price4` int(5) NOT NULL,
  `price5` int(5) NOT NULL,
  `price6` int(5) NOT NULL,
  `other7` varchar(80) DEFAULT NULL,
  `other8` varchar(80) DEFAULT NULL,
  `other9` varchar(80) DEFAULT NULL,
  `other10` varchar(80) DEFAULT NULL,
  `other11` varchar(80) DEFAULT NULL,
  `other12` varchar(80) DEFAULT NULL,
  `booking_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_expense`
--

CREATE TABLE `restaurant_expense` (
  `restaurant_expense_id` int(11) NOT NULL,
  `providerName` varchar(100) NOT NULL,
  `purpose` varchar(240) NOT NULL,
  `amount` int(10) NOT NULL,
  `comment` varchar(200) NOT NULL,
  `creator` int(20) NOT NULL,
  `doc` datetime NOT NULL,
  `dom` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_transaction`
--

CREATE TABLE `restaurant_transaction` (
  `transaction_id` int(11) NOT NULL,
  `transaction_type` varchar(8) NOT NULL,
  `transaction_amount` int(8) NOT NULL,
  `transaction_date` date NOT NULL,
  `purpose` varchar(20) NOT NULL,
  `table_ref_name` varchar(60) NOT NULL,
  `table_ref_id` int(19) NOT NULL,
  `transaction_comment` varchar(100) DEFAULT NULL,
  `DOC` datetime NOT NULL DEFAULT current_timestamp(),
  `DOM` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `creator` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restaurant_transaction`
--

INSERT INTO `restaurant_transaction` (`transaction_id`, `transaction_type`, `transaction_amount`, `transaction_date`, `purpose`, `table_ref_name`, `table_ref_id`, `transaction_comment`, `DOC`, `DOM`, `creator`) VALUES
(1, 'in', 1380, '2019-12-29', 'Sale', 'order_info', 4, NULL, '2019-12-29 06:28:31', '2019-12-29 13:28:31', 12),
(2, 'in', 80, '2019-12-29', 'Sale', 'order_info', 6, NULL, '2019-12-29 06:37:02', '2019-12-29 13:37:02', 12);

-- --------------------------------------------------------

--
-- Table structure for table `rest_access_auth`
--

CREATE TABLE `rest_access_auth` (
  `access_auth_id` int(11) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `module_name` varchar(20) NOT NULL,
  `value` int(1) NOT NULL,
  `auth_doc` date NOT NULL,
  `auth_creator` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rest_access_auth`
--

INSERT INTO `rest_access_auth` (`access_auth_id`, `user_type`, `module_name`, `value`, `auth_doc`, `auth_creator`) VALUES
(1, 'superadmin', 'pos_terminal', 1, '2016-02-06', 12),
(2, 'superadmin', 'invoice_info', 1, '2016-02-06', 12),
(3, 'superadmin', 'report_infos', 1, '2016-02-06', 12),
(4, 'superadmin', 'credit_transactions', 1, '2016-02-06', 12),
(5, 'superadmin', 'product_catagories', 1, '2016-02-06', 12),
(6, 'superadmin', 'product_info', 1, '2016-02-06', 12),
(7, 'superadmin', 'package_products', 1, '2016-02-06', 12),
(8, 'superadmin', 'table_layout', 1, '2016-02-06', 12),
(9, 'superadmin', 'preparation_options', 1, '2016-02-06', 12),
(10, 'superadmin', 'expense_entry', 1, '2016-02-06', 12),
(11, 'superadmin', 'stock_system', 1, '2016-02-06', 12),
(12, 'superadmin', 'cashbox_system', 1, '2016-02-06', 12),
(13, 'superadmin', 'salary_log', 1, '2016-02-06', 12),
(14, 'superadmin', 'booking_info', 1, '2016-02-06', 12),
(15, 'superadmin', 'entertain_info', 1, '2016-02-06', 12),
(16, 'superadmin', 'order_cancl_raeson', 1, '2016-02-06', 12),
(17, 'superadmin', 'stuff_setup', 1, '2016-02-06', 12),
(33, 'admin', 'pos_terminal', 0, '2016-02-06', 12),
(34, 'admin', 'invoice_info', 0, '2016-02-06', 12),
(35, 'admin', 'report_infos', 0, '2016-02-06', 12),
(36, 'admin', 'credit_transactions', 0, '2016-02-06', 12),
(37, 'admin', 'product_catagories', 0, '2016-02-06', 12),
(38, 'admin', 'product_info', 0, '2016-02-06', 12),
(39, 'admin', 'package_products', 0, '2016-02-06', 12),
(40, 'admin', 'table_layout', 0, '2016-02-06', 12),
(41, 'admin', 'preparation_options', 0, '2016-02-06', 12),
(42, 'admin', 'expense_entry', 0, '2016-02-06', 12),
(43, 'admin', 'stock_system', 0, '2016-02-06', 12),
(44, 'admin', 'cashbox_system', 0, '2016-02-06', 12),
(45, 'admin', 'salary_log', 0, '2016-02-06', 12),
(46, 'admin', 'booking_info', 0, '2016-02-06', 12),
(47, 'admin', 'entertain_info', 0, '2016-02-06', 12),
(48, 'admin', 'order_cancl_raeson', 0, '2016-02-06', 12),
(49, 'admin', 'stuff_setup', 0, '2016-02-06', 12),
(50, 'manager', 'pos_terminal', 0, '2016-02-06', 12),
(51, 'manager', 'invoice_info', 0, '2016-02-06', 12),
(52, 'manager', 'report_infos', 0, '2016-02-06', 12),
(53, 'manager', 'credit_transactions', 0, '2016-02-06', 12),
(54, 'manager', 'product_catagories', 0, '2016-02-06', 12),
(55, 'manager', 'product_info', 0, '2016-02-06', 12),
(56, 'manager', 'package_products', 0, '2016-02-06', 12),
(57, 'manager', 'table_layout', 0, '2016-02-06', 12),
(58, 'manager', 'preparation_options', 0, '2016-02-06', 12),
(59, 'manager', 'expense_entry', 0, '2016-02-06', 12),
(60, 'manager', 'stock_system', 0, '2016-02-06', 12),
(61, 'manager', 'cashbox_system', 0, '2016-02-06', 12),
(62, 'manager', 'salary_log', 0, '2016-02-06', 12),
(63, 'manager', 'booking_info', 0, '2016-02-06', 12),
(64, 'manager', 'entertain_info', 0, '2016-02-06', 12),
(65, 'manager', 'order_cancl_raeson', 0, '2016-02-06', 12),
(66, 'manager', 'stuff_setup', 0, '2016-02-06', 12),
(67, 'accountant', 'pos_terminal', 0, '2016-02-06', 12),
(68, 'accountant', 'invoice_info', 0, '2016-02-06', 12),
(69, 'accountant', 'report_infos', 0, '2016-02-06', 12),
(70, 'accountant', 'credit_transactions', 0, '2016-02-06', 12),
(71, 'accountant', 'product_catagories', 0, '2016-02-06', 12),
(72, 'accountant', 'product_info', 0, '2016-02-06', 12),
(73, 'accountant', 'package_products', 0, '2016-02-06', 12),
(74, 'accountant', 'table_layout', 0, '2016-02-06', 12),
(75, 'accountant', 'preparation_options', 0, '2016-02-06', 12),
(76, 'accountant', 'expense_entry', 0, '2016-02-06', 12),
(77, 'accountant', 'stock_system', 0, '2016-02-06', 12),
(78, 'accountant', 'cashbox_system', 0, '2016-02-06', 12),
(79, 'accountant', 'salary_log', 0, '2016-02-06', 12),
(80, 'accountant', 'booking_info', 0, '2016-02-06', 12),
(81, 'accountant', 'entertain_info', 0, '2016-02-06', 12),
(82, 'accountant', 'order_cancl_raeson', 0, '2016-02-06', 12),
(83, 'accountant', 'stuff_setup', 0, '2016-02-06', 12),
(84, 'stockist', 'pos_terminal', 0, '2016-02-06', 12),
(85, 'stockist', 'invoice_info', 0, '2016-02-06', 12),
(86, 'stockist', 'report_infos', 0, '2016-02-06', 12),
(87, 'stockist', 'credit_transactions', 0, '2016-02-06', 12),
(88, 'stockist', 'product_catagories', 0, '2016-02-06', 12),
(89, 'stockist', 'product_info', 0, '2016-02-06', 12),
(90, 'stockist', 'package_products', 0, '2016-02-06', 12),
(91, 'stockist', 'table_layout', 0, '2016-02-06', 12),
(92, 'stockist', 'preparation_options', 0, '2016-02-06', 12),
(93, 'stockist', 'expense_entry', 0, '2016-02-06', 12),
(94, 'stockist', 'stock_system', 0, '2016-02-06', 12),
(95, 'stockist', 'cashbox_system', 0, '2016-02-06', 12),
(96, 'stockist', 'salary_log', 0, '2016-02-06', 12),
(97, 'stockist', 'booking_info', 0, '2016-02-06', 12),
(98, 'stockist', 'entertain_info', 0, '2016-02-06', 12),
(99, 'stockist', 'order_cancl_raeson', 0, '2016-02-06', 12),
(100, 'stockist', 'stuff_setup', 0, '2016-02-06', 12),
(101, 'seller', 'pos_terminal', 1, '2016-02-06', 12),
(102, 'seller', 'invoice_info', 1, '2016-02-06', 12),
(103, 'seller', 'report_infos', 1, '2016-02-06', 12),
(104, 'seller', 'credit_transactions', 1, '2016-02-06', 12),
(105, 'seller', 'product_catagories', 1, '2016-02-06', 12),
(106, 'seller', 'product_info', 1, '2016-02-06', 12),
(107, 'seller', 'package_products', 1, '2016-02-06', 12),
(108, 'seller', 'table_layout', 1, '2016-02-06', 12),
(109, 'seller', 'preparation_options', 1, '2016-02-06', 12),
(110, 'seller', 'expense_entry', 1, '2016-02-06', 12),
(111, 'seller', 'stock_system', 1, '2016-02-06', 12),
(112, 'seller', 'cashbox_system', 1, '2016-02-06', 12),
(113, 'seller', 'salary_log', 1, '2016-02-06', 12),
(114, 'seller', 'booking_info', 1, '2016-02-06', 12),
(115, 'seller', 'entertain_info', 1, '2016-02-06', 12),
(116, 'seller', 'order_cancl_raeson', 1, '2016-02-06', 12),
(117, 'seller', 'stuff_setup', 1, '2016-02-06', 12),
(118, 'waiter', 'pos_terminal', 0, '2016-02-06', 12),
(119, 'waiter', 'invoice_info', 0, '2016-02-06', 12),
(120, 'waiter', 'report_infos', 0, '2016-02-06', 12),
(121, 'waiter', 'credit_transactions', 0, '2016-02-06', 12),
(122, 'waiter', 'product_catagories', 0, '2016-02-06', 12),
(123, 'waiter', 'product_info', 0, '2016-02-06', 12),
(124, 'waiter', 'package_products', 0, '2016-02-06', 12),
(125, 'waiter', 'table_layout', 0, '2016-02-06', 12),
(126, 'waiter', 'preparation_options', 0, '2016-02-06', 12),
(127, 'waiter', 'expense_entry', 0, '2016-02-06', 12),
(128, 'waiter', 'stock_system', 0, '2016-02-06', 12),
(129, 'waiter', 'cashbox_system', 0, '2016-02-06', 12),
(130, 'waiter', 'salary_log', 0, '2016-02-06', 12),
(131, 'waiter', 'booking_info', 0, '2016-02-06', 12),
(132, 'waiter', 'entertain_info', 0, '2016-02-06', 12),
(133, 'waiter', 'order_cancl_raeson', 0, '2016-02-06', 12),
(134, 'waiter', 'stuff_setup', 0, '2016-02-06', 12);

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `room_id` int(11) NOT NULL,
  `room_number` int(11) NOT NULL,
  `room_typ_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `room_tag` varchar(255) DEFAULT NULL,
  `dirty_status` tinyint(1) DEFAULT 0,
  `guest_status` tinyint(1) DEFAULT 0,
  `block_status` tinyint(1) DEFAULT 0,
  `userID` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0,
  `DOC` datetime NOT NULL DEFAULT current_timestamp(),
  `DOM` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`room_id`, `room_number`, `room_typ_id`, `class_id`, `room_tag`, `dirty_status`, `guest_status`, `block_status`, `userID`, `status`, `DOC`, `DOM`) VALUES
(1, 101, 1, 1, NULL, 0, 0, 0, 2, 0, '2015-04-28 13:11:10', '2015-05-19 01:48:18'),
(2, 102, 1, 1, NULL, 0, 0, 0, 1, 0, '2015-04-28 13:11:10', '2015-05-19 13:42:37'),
(3, 103, 1, 1, 'good,exillent', 0, 0, 0, 2, 0, '2015-04-28 13:11:10', '2015-05-19 02:19:43'),
(4, 105, 1, 1, NULL, 0, 0, 0, 2, 0, '2015-04-28 13:11:10', '2015-05-19 00:45:57'),
(11, 110, 1, 1, NULL, 0, 0, 0, 1, 0, '2015-04-28 16:39:31', '2015-05-19 14:20:10'),
(12, 111, 1, 1, 'This is nice', 0, 0, 0, 1, 0, '2015-04-28 16:39:31', '2015-05-19 09:52:48'),
(13, 115, 1, 1, NULL, 0, 0, 0, NULL, 0, '2015-04-28 17:16:04', '2015-04-29 10:55:15'),
(14, 112, 1, 1, NULL, 0, 0, 0, 2, 0, '2015-04-28 17:16:04', '2015-05-19 01:48:11'),
(15, 113, 1, 1, NULL, 0, 0, 0, 2, 0, '2015-04-28 17:16:23', '2015-05-18 14:43:50'),
(16, 108, 2, 3, NULL, 0, 0, 0, 2, 0, '2015-04-28 17:47:11', '2015-05-19 00:45:52'),
(17, 502, 2, 3, NULL, 0, 0, 0, NULL, 0, '2015-04-28 17:47:11', '2015-04-29 10:41:26'),
(18, 503, 2, 1, NULL, 0, 0, 0, NULL, 0, '2015-04-28 18:01:49', '2015-04-29 10:41:26'),
(19, 504, 2, 1, NULL, 0, 0, 0, NULL, 0, '2015-04-28 18:01:49', '2015-04-29 10:41:26'),
(20, 508, 2, 1, 'Good,Nice', 0, 0, 0, NULL, 0, '2015-04-28 18:01:49', '2015-05-02 18:47:56'),
(36, 450, 2, 2, NULL, 0, 0, 0, 1, 0, '2015-04-28 23:04:48', '2015-05-18 02:04:25'),
(37, 452, 2, 2, NULL, 0, 0, 0, NULL, 0, '2015-04-28 23:04:48', '2015-04-29 10:41:26'),
(46, 258, 1, 2, NULL, 0, 0, 0, NULL, 0, '2015-05-02 18:16:29', NULL),
(47, 201, 1, 2, NULL, 0, 0, 0, NULL, 0, '2015-05-02 18:16:29', NULL),
(79, 254, 1, 2, NULL, 0, 0, 0, NULL, 0, '2015-05-02 18:17:09', NULL),
(101, 202, 1, 2, NULL, 0, 0, 0, NULL, 0, '2015-05-02 18:18:49', NULL),
(102, 203, 1, 2, NULL, 0, 0, 0, NULL, 0, '2015-05-02 18:18:49', NULL),
(103, 205, 1, 2, NULL, 0, 0, 0, NULL, 0, '2015-05-02 18:19:03', NULL),
(104, 204, 1, 2, NULL, 0, 0, 0, NULL, 0, '2015-05-02 18:19:15', NULL),
(106, 505, 2, 1, NULL, 0, 0, 0, NULL, 0, '2015-05-02 18:32:33', NULL),
(107, 506, 2, 1, NULL, 0, 0, 0, 2, 0, '2015-05-02 18:32:33', '2015-05-18 22:05:53'),
(108, 507, 2, 1, NULL, 0, 0, 0, NULL, 0, '2015-05-02 18:32:40', NULL),
(109, 802, 3, 1, NULL, 0, 0, 0, NULL, 0, '2015-05-02 18:35:00', NULL),
(110, 801, 3, 1, NULL, 0, 0, 0, NULL, 0, '2015-05-02 18:35:00', NULL),
(112, 806, 3, 1, NULL, 0, 0, 0, NULL, 0, '2015-05-02 18:42:17', NULL),
(113, 810, 3, 1, NULL, 0, 0, 0, 2, 0, '2015-05-02 18:42:57', '2015-05-18 22:05:56'),
(114, 451, 2, 2, NULL, 0, 0, 0, NULL, 0, '2015-05-02 18:44:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `room_type`
--

CREATE TABLE `room_type` (
  `room_typ_id` int(11) NOT NULL,
  `room_typ_name` varchar(100) NOT NULL,
  `max_adults` int(8) DEFAULT 0,
  `max_childs` int(8) DEFAULT 0,
  `status` tinyint(1) DEFAULT 0,
  `userID` int(6) DEFAULT NULL,
  `DOC` datetime NOT NULL DEFAULT current_timestamp(),
  `DOM` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room_type`
--

INSERT INTO `room_type` (`room_typ_id`, `room_typ_name`, `max_adults`, `max_childs`, `status`, `userID`, `DOC`, `DOM`) VALUES
(1, 'Single', 1, 1, 0, NULL, '2015-04-27 19:39:27', '2015-04-28 01:56:14'),
(2, 'Double', 2, 2, 0, NULL, '2015-04-27 20:45:38', NULL),
(3, 'Suite', 6, 8, 0, NULL, '2015-04-27 20:49:42', '2015-04-28 02:13:44'),
(4, 'Triple', 3, 4, 0, NULL, '2015-04-27 20:53:30', '2015-04-28 02:11:39'),
(5, 'Twin Single', 2, 4, 0, NULL, '2015-04-28 01:44:10', '2015-04-28 02:13:48'),
(7, 'Twin Double', 4, 4, 0, NULL, '2015-04-30 20:09:21', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_id` int(11) NOT NULL,
  `service_name` varchar(250) NOT NULL,
  `service_typ_id` int(11) NOT NULL,
  `service_rate` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 0,
  `userID` int(11) DEFAULT NULL,
  `DOC` datetime DEFAULT current_timestamp(),
  `DOM` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_id`, `service_name`, `service_typ_id`, `service_rate`, `status`, `userID`, `DOC`, `DOM`) VALUES
(1, 'Jam Jelly', 1, 50, 0, NULL, '2015-05-01 09:29:40', '2015-05-01 10:45:12'),
(2, 'Chiken Nudols', 1, 120, 0, NULL, '2015-05-01 09:33:31', '2015-05-01 10:40:33'),
(3, 'Chicken Burger', 1, 100, 0, NULL, '2015-05-01 09:48:26', '2015-05-01 10:39:48'),
(7, 'test', 1, 500, 0, NULL, '2015-05-20 18:02:44', '2015-05-20 18:03:43'),
(8, 'Test', 1, 540, 0, NULL, '2015-05-20 18:46:58', NULL),
(39, 'Green', 0, 100, 0, NULL, '2015-05-27 19:19:51', NULL),
(40, 'Mixed', 0, 100, 0, NULL, '2015-05-27 19:20:21', NULL),
(41, 'Chicken Bhuna', 0, 140, 0, NULL, '2015-05-27 19:21:39', NULL),
(42, 'Beef Bhuna', 1, 180, 0, NULL, '2015-05-27 19:22:22', '2016-01-11 15:29:29'),
(43, 'Beef Dupiaza', 1, 260, 0, NULL, '2015-05-27 19:23:25', '2016-02-21 15:14:24'),
(44, 'Beef Satkara', 1, 260, 0, NULL, '2015-05-27 19:24:17', '2016-01-11 15:30:51'),
(45, 'Beef Jhal Fraizee', 1, 230, 0, NULL, '2015-05-27 19:25:12', '2016-02-21 15:27:53'),
(46, 'Mutton Curry', 0, 150, 0, NULL, '2015-05-27 19:25:55', NULL),
(47, 'Mutton Kurma', 0, 200, 0, NULL, '2015-05-27 19:26:27', NULL),
(48, 'Mutton Dupiaza', 0, 200, 0, NULL, '2015-05-27 19:26:52', NULL),
(49, 'Vegetable Dupiaza', 1, 60, 0, NULL, '2015-05-27 19:27:29', '2015-06-06 19:48:30'),
(50, 'Plain Daal', 1, 45, 0, NULL, '2015-05-27 19:28:06', '2015-06-05 19:08:13'),
(51, 'Daal Butter Fry', 0, 70, 0, NULL, '2015-05-27 19:28:36', NULL),
(52, 'Daal Bhuna', 0, 60, 0, NULL, '2015-05-27 19:29:28', NULL),
(53, 'Chicken Biriyani', 1, 150, 0, NULL, '2015-05-27 19:32:19', '2015-06-06 19:48:50'),
(54, 'Hyderbadi Ghost Biriyani', 0, 195, 0, NULL, '2015-05-27 19:33:02', NULL),
(55, 'Beef Biriyani', 1, 180, 0, NULL, '2015-05-27 19:33:53', '2016-01-11 15:32:21'),
(56, 'Mutton Biriyani', 0, 150, 0, NULL, '2015-05-27 19:34:30', NULL),
(57, 'Vegetable Pulao', 0, 120, 0, NULL, '2015-05-27 19:35:02', NULL),
(58, 'Jeera Pulao', 0, 110, 0, NULL, '2015-05-27 19:35:59', NULL),
(59, 'Plain Pulao', 0, 90, 0, NULL, '2015-05-27 19:36:30', NULL),
(60, 'Peace Pulao', 0, 110, 0, NULL, '2015-05-27 19:37:06', NULL),
(61, 'Kashmiri Pulao', 0, 150, 0, NULL, '2015-05-27 19:37:54', NULL),
(62, 'Garlic', 0, 50, 0, NULL, '2015-05-27 19:39:22', NULL),
(63, 'Keema', 0, 90, 0, NULL, '2015-05-27 19:39:47', NULL),
(64, 'peshwari', 0, 90, 0, NULL, '2015-05-27 19:40:35', NULL),
(65, 'Pad Thai', 0, 350, 0, NULL, '2015-05-27 19:50:07', NULL),
(66, 'Chicken', 0, 190, 0, NULL, '2015-05-27 19:52:40', NULL),
(67, 'Prawn', 0, 210, 0, NULL, '2015-05-27 19:53:10', NULL),
(68, 'Beef Noodles', 1, 210, 0, NULL, '2015-05-27 19:53:41', '2016-01-11 15:33:04'),
(69, 'Vegetable', 0, 150, 0, NULL, '2015-05-27 19:55:38', NULL),
(70, 'Egg', 0, 160, 0, NULL, '2015-05-27 19:56:13', NULL),
(71, 'Hiltown Special', 0, 280, 0, NULL, '2015-05-27 19:57:00', NULL),
(72, 'Tea- Black', 1, 15, 0, NULL, '2015-05-27 19:59:20', '2015-05-27 20:02:13'),
(74, 'Tea- Milk', 1, 25, 0, NULL, '2015-05-27 19:59:58', '2015-06-06 19:09:01'),
(75, 'Coffee- Black', 1, 40, 0, NULL, '2015-05-27 20:01:02', '2015-05-27 20:02:05'),
(76, 'Coffee With Coffee Mate', 1, 80, 0, NULL, '2015-05-27 20:03:18', '2015-06-06 19:33:48'),
(77, 'Ice Coffee', 1, 60, 0, NULL, '2015-05-27 20:04:05', '2015-06-06 19:09:21'),
(78, 'Soft Drinks', 1, 20, 0, NULL, '2015-05-27 20:05:05', '2015-06-06 19:10:50'),
(79, 'Mineral (1500)', 1, 30, 0, NULL, '2015-05-27 20:06:10', '2015-06-06 19:11:12'),
(80, 'Mineral (500)', 1, 20, 0, NULL, '2015-05-27 20:06:41', '2015-06-06 19:11:45'),
(81, 'Ice Cream (Vanilla, Stawbery)', 0, 70, 0, NULL, '2015-05-27 20:07:22', NULL),
(82, 'Milk Shake', 1, 80, 0, NULL, '2015-05-27 20:07:59', '2015-06-06 19:36:18'),
(84, 'Lassi', 1, 100, 0, NULL, '2015-05-27 20:10:23', '2015-06-06 19:36:34'),
(85, 'Chicken & Vegetable Soup', 1, 180, 0, NULL, '2015-05-27 20:14:56', '2015-05-27 20:15:07'),
(86, 'Chicken Corn Soup', 0, 180, 0, NULL, '2015-05-27 20:15:36', NULL),
(87, 'Szechuan Soup', 0, 300, 0, NULL, '2015-05-27 20:16:20', NULL),
(88, 'Hot & Sour Soup', 1, 240, 0, NULL, '2015-05-27 20:17:10', NULL),
(89, 'Chicken Noodles Soup', 0, 170, 0, NULL, '2015-05-27 20:17:37', NULL),
(90, 'Szechuan Fried Chicken', 0, 280, 0, NULL, '2015-05-28 16:19:04', NULL),
(91, 'Chicken Chili Onion', 1, 270, 0, NULL, '2015-05-28 16:19:34', '2015-06-06 19:35:31'),
(92, 'Chicken in Garlic Sauce', 0, 280, 0, NULL, '2015-05-28 16:20:27', NULL),
(93, 'Sweet & Sour Chicken', 0, 290, 0, NULL, '2015-05-28 16:21:17', NULL),
(94, 'Masala Chicken', 0, 280, 0, NULL, '2015-05-28 16:21:58', NULL),
(95, 'Hot Sauce Chicken', 0, 290, 0, NULL, '2015-05-28 16:22:45', NULL),
(96, 'Chicken Jhal Fry', 0, 290, 0, NULL, '2015-05-28 16:24:02', NULL),
(97, 'Prawn Masala', 0, 350, 0, NULL, '2015-05-28 16:24:37', NULL),
(98, 'Special China Prawn', 0, 320, 0, NULL, '2015-05-28 16:25:17', NULL),
(99, 'Sweet & Sour Prawn', 0, 350, 0, NULL, '2015-05-28 16:25:50', NULL),
(100, 'Prawn with Garlic Sauce', 0, 350, 0, NULL, '2015-05-28 16:45:41', NULL),
(101, 'Prawn Chili Onion', 1, 350, 0, NULL, '2015-05-28 16:46:41', '2015-05-28 16:49:24'),
(102, 'Beef Chili Dry', 1, 330, 0, NULL, '2015-05-28 16:47:14', '2016-01-11 15:33:45'),
(103, 'Beef Chili Onion', 1, 310, 0, NULL, '2015-05-28 16:48:47', '2016-02-21 15:53:02'),
(104, 'Beef Masala', 1, 310, 0, NULL, '2015-05-28 16:50:16', '2016-01-11 15:35:45'),
(105, 'Beef Garlic Sauce', 1, 310, 0, NULL, '2015-05-28 16:51:09', '2016-01-11 15:36:21'),
(106, 'Hot Sauce Beef', 1, 280, 0, NULL, '2015-05-28 16:52:07', '2015-05-28 16:52:57'),
(107, 'Sweet Sauce Beef', 0, 290, 0, NULL, '2015-05-28 16:53:47', NULL),
(108, 'Mixed Vegetable', 0, 150, 0, NULL, '2015-05-28 16:54:36', NULL),
(109, 'Chicken Vegetable', 1, 180, 0, NULL, '2015-05-28 16:55:35', '2015-05-28 16:57:10'),
(110, 'Prawn Vegetable', 1, 200, 0, NULL, '2015-05-28 16:56:25', '2015-05-28 16:57:22'),
(111, 'Beef Vegetable', 1, 250, 0, NULL, '2015-05-28 16:56:55', '2016-02-21 15:53:45'),
(112, 'Chicken & Mushroom Vegetable', 0, 250, 0, NULL, '2015-05-28 16:58:15', NULL),
(113, 'Egg Fried Rice', 1, 180, 0, NULL, '2015-05-28 17:02:52', '2015-06-06 19:35:17'),
(114, 'Chicken Fried Rice', 1, 190, 0, NULL, '2015-05-28 17:03:24', '2015-06-06 19:36:49'),
(115, 'Szechuan Fried Rice', 1, 250, 0, NULL, '2015-05-28 17:05:03', NULL),
(116, 'Vegetable Fried Rice', 0, 160, 0, NULL, '2015-05-28 17:05:39', NULL),
(117, 'Masala Fried Rice', 0, 230, 0, NULL, '2015-05-28 17:06:27', '2015-05-28 17:07:49'),
(118, 'Special Fried Rice', 0, 260, 0, NULL, '2015-05-28 17:07:01', NULL),
(119, 'Prawn Fried Rice', 0, 200, 0, NULL, '2015-05-28 17:08:44', NULL),
(120, 'Beef Fried Rice', 1, 200, 0, NULL, '2015-05-28 17:09:26', '2016-01-11 15:36:47'),
(121, 'Streamed Rice', 0, 120, 0, NULL, '2015-05-28 17:10:11', NULL),
(122, 'Chicken', 0, 190, 0, NULL, '2015-05-28 17:11:47', NULL),
(123, 'Beef', 1, 200, 0, NULL, '2015-05-28 17:12:13', '2016-01-11 15:37:24'),
(124, 'Hiltown Special', 0, 280, 0, NULL, '2015-05-28 17:12:55', NULL),
(125, 'American', 0, 250, 0, NULL, '2015-05-28 17:13:25', NULL),
(126, 'Hiltown Special Sizzling', 0, 450, 0, NULL, '2015-05-28 19:20:12', NULL),
(127, 'Beef Sizzling', 1, 360, 0, NULL, '2015-05-28 19:20:56', '2016-01-11 15:37:47'),
(128, 'Chicken Sizzling', 0, 320, 0, NULL, '2015-05-28 19:21:27', NULL),
(129, 'Prawn Sizzling', 1, 350, 0, NULL, '2015-05-28 19:22:16', '2015-05-31 17:23:23'),
(130, 'Plain', 1, 35, 0, NULL, '2015-06-01 15:35:58', NULL),
(131, 'Coffee - Milk', 1, 60, 0, NULL, '2015-06-03 16:22:32', '2015-06-06 19:34:09'),
(132, 'Traditional 1: Parata/ Chapati, Mix Veg./ Egg/, Tea/Coffee', 1, 120, 0, NULL, '2015-06-05 18:55:39', NULL),
(133, 'Traditional 2: Plain Naan, Mix Veg./ Egg/, Tea/Coffee', 1, 120, 0, NULL, '2015-06-05 18:56:15', '2015-06-05 18:58:14'),
(134, 'Continental: Toast (With butter jam)/ Omelette Tea/ Coffee', 1, 100, 0, NULL, '2015-06-05 18:58:03', NULL),
(135, 'Omelette', 1, 25, 0, NULL, '2015-06-05 18:59:18', NULL),
(136, 'Scrambled Eggs on Toast', 1, 60, 0, NULL, '2015-06-05 19:00:09', NULL),
(137, 'French Bread (sweet)', 1, 60, 0, NULL, '2015-06-05 19:01:06', NULL),
(138, 'Parata- Plain', 1, 30, 0, NULL, '2015-06-05 19:03:16', NULL),
(139, 'Parata- Shahi', 1, 60, 0, NULL, '2015-06-05 19:03:43', NULL),
(140, 'Chapati', 1, 30, 0, NULL, '2015-06-05 19:04:36', NULL),
(141, 'Vegetable', 0, 60, 0, NULL, '2015-06-05 19:05:14', '2015-06-06 19:49:15'),
(142, 'Daal Bhuna', 1, 60, 0, NULL, '2015-06-05 19:05:45', NULL),
(143, 'Tea', 1, 25, 0, NULL, '2015-06-05 19:06:15', '2015-06-06 19:07:35'),
(144, 'Coffee', 1, 60, 0, NULL, '2015-06-05 19:06:46', '2015-06-06 19:07:57'),
(145, 'Stuff Rice', 1, 25, 0, NULL, '2015-06-06 19:02:45', '2015-06-06 19:13:42'),
(146, 'Stuff Curry', 1, 40, 0, NULL, '2015-06-06 19:03:14', '2015-06-07 17:56:27'),
(147, 'Stuff Daal', 1, 20, 0, NULL, '2015-06-06 19:04:37', '2015-06-07 17:56:45'),
(148, 'Thai Fried Chicken', 1, 380, 0, NULL, '2015-06-07 12:52:05', NULL),
(149, 'Bankok Style Fried Chicken', 1, 320, 0, NULL, '2015-06-07 12:52:42', NULL),
(150, 'Green Chicken Curry', 1, 340, 0, NULL, '2015-06-07 12:53:52', NULL),
(151, 'Foil Chicken', 1, 450, 0, NULL, '2015-06-07 12:54:59', NULL),
(152, 'Slice Chicken Red Curry', 1, 350, 0, NULL, '2015-06-07 12:55:48', NULL),
(153, 'Beef Red Curry', 1, 370, 0, NULL, '2015-06-07 12:56:45', '2016-01-11 16:56:19'),
(154, 'Beef In Oyster Sauce', 1, 310, 0, NULL, '2015-06-07 12:57:26', '2016-01-11 16:56:02'),
(155, 'King Prawn Masala', 1, 550, 0, NULL, '2015-06-07 12:58:28', '2015-06-07 12:59:30'),
(156, 'Special King Prawn', 1, 560, 0, NULL, '2015-06-07 12:59:14', NULL),
(157, 'Prawn With Green Peas', 1, 350, 0, NULL, '2015-06-07 13:00:13', NULL),
(158, 'Thai Fried Rice', 1, 300, 0, NULL, '2015-06-07 13:03:04', NULL),
(159, 'Hiltown Special Fried Rice', 1, 330, 0, NULL, '2015-06-07 13:03:39', NULL),
(160, 'Thai Vegetable Fried Rice', 1, 280, 0, NULL, '2015-06-07 13:04:19', '2015-06-07 13:04:30'),
(161, 'Thai Mixed Vegetable ', 1, 300, 0, NULL, '2015-06-07 13:05:15', NULL),
(162, 'Hiltown Special Vegetable ', 1, 330, 0, NULL, '2015-06-07 13:05:47', NULL),
(163, 'Tomato Shorba', 1, 90, 0, NULL, '2015-06-07 13:08:59', NULL),
(164, 'Mulligatawny Soup', 1, 110, 0, NULL, '2015-06-07 13:09:51', NULL),
(165, 'Rui Fish Large', 1, 160, 0, NULL, '2015-06-10 14:57:00', '2015-06-10 18:10:34'),
(166, 'Rui Fish Small', 1, 120, 0, NULL, '2015-06-10 18:07:06', NULL),
(167, 'Pabda Fish Small', 1, 250, 0, NULL, '2015-06-10 18:07:58', '2015-12-21 15:34:37'),
(168, 'Pabda Fish Large', 1, 350, 0, NULL, '2015-06-10 18:08:31', '2016-03-04 18:37:34'),
(169, 'Rupchada Large', 1, 350, 0, NULL, '2015-06-10 18:09:16', NULL),
(170, 'Rupchada Small', 1, 250, 0, NULL, '2015-06-10 18:09:36', '2016-01-12 14:57:20'),
(171, 'Koi Large', 1, 150, 0, NULL, '2015-06-10 18:10:02', NULL),
(172, 'Chicken Mughlai', 1, 120, 0, NULL, '2015-06-14 18:08:11', NULL),
(173, 'Thai Soup Special', 1, 290, 0, NULL, '2015-06-15 19:29:26', NULL),
(174, 'Tom Yum Gong/ Gai', 1, 380, 0, NULL, '2015-06-15 19:30:05', NULL),
(175, 'Thai Corn Soup', 1, 220, 0, NULL, '2015-06-15 19:30:35', NULL),
(176, 'Thai Clear Vegetable Soup', 1, 250, 0, NULL, '2015-06-15 19:31:25', NULL),
(177, 'Hiltown Special Soup', 1, 350, 0, NULL, '2015-06-15 19:31:54', NULL),
(178, 'Sweet And Sour king Prawn Soup', 1, 550, 0, NULL, '2015-06-15 19:32:44', NULL),
(179, 'Complimentary Breakfast 1', 1, 30, 0, NULL, '2015-06-16 18:42:05', NULL),
(180, 'Complimentary Fresh 1 ( L )', 1, 15, 0, NULL, '2015-06-16 18:42:35', '2016-01-24 09:55:24'),
(181, 'Complimentary Fresh 500 ml', 1, 15, 0, NULL, '2015-06-16 18:42:57', '2016-01-24 09:56:36'),
(182, 'Set Menu 1', 1, 270, 0, NULL, '2015-06-20 15:06:49', NULL),
(183, 'Set Menu 2', 1, 330, 0, NULL, '2015-06-20 15:09:48', NULL),
(184, 'Set Menu 3', 1, 580, 0, NULL, '2015-06-20 15:12:48', NULL),
(185, 'Set Menu 4', 1, 650, 0, NULL, '2015-06-20 15:17:04', '2015-06-20 15:21:24'),
(186, 'VIP Menu', 1, 750, 0, NULL, '2015-06-20 15:20:45', NULL),
(187, 'Chicken Noodles Soup', 1, 170, 0, NULL, '2015-07-22 15:50:37', NULL),
(188, 'M Water 2 Ltr', 1, 35, 0, NULL, '2015-07-23 13:48:53', '2015-07-23 14:32:31'),
(189, 'Chicken Dupiaza', 1, 220, 0, NULL, '2015-07-23 15:19:20', NULL),
(190, 'Hiltown Special Noodles', 1, 280, 0, NULL, '2015-07-23 16:11:58', NULL),
(191, 'Chicken Kurma', 1, 250, 0, NULL, '2015-07-24 15:37:01', NULL),
(192, 'Achari Murgh-1 person', 1, 200, 0, NULL, '2015-08-06 20:00:03', NULL),
(193, 'Beef Achari ', 1, 200, 0, NULL, '2015-08-06 20:01:18', '2016-01-11 16:55:16'),
(194, 'Beef bhuna', 1, 180, 0, NULL, '2015-08-06 20:02:05', '2016-01-11 16:53:28'),
(195, 'Amritsari Tikka Masala', 1, 200, 0, NULL, '2015-08-07 15:04:56', NULL),
(196, 'Mix Salad', 1, 100, 0, NULL, '2015-08-09 17:56:53', NULL),
(197, 'Chiken Mughlai', 1, 120, 0, NULL, '2015-08-09 17:58:00', NULL),
(198, 'chicmas', 1, 280, 0, NULL, '2015-09-22 18:54:02', '2015-10-12 13:32:28'),
(199, 'Fresh Orange Juice', 1, 110, 0, NULL, '2015-10-08 17:10:21', NULL),
(200, 'Fresh Mango Juice', 1, 110, 0, NULL, '2015-10-08 17:10:45', NULL),
(201, 'Ice Cream', 1, 60, 0, NULL, '2015-10-08 17:13:27', NULL),
(202, 'Half Chicken', 1, 86, 0, NULL, '2015-10-08 17:14:42', NULL),
(203, 'Half Beef', 1, 90, 0, NULL, '2015-10-08 17:15:41', '2016-01-11 16:52:52'),
(204, 'Coke 1 Ltr', 1, 60, 0, NULL, '2015-10-13 20:47:38', NULL),
(205, 'Parata', 3, 10, 0, NULL, '2015-10-13 20:48:53', '2015-10-13 20:49:53'),
(206, 'chapati', 3, 10, 0, NULL, '2015-10-13 20:49:44', NULL),
(207, 'Vegetable', 3, 10, 0, NULL, '2015-10-13 20:50:20', NULL),
(208, 'Omelette', 3, 10, 0, NULL, '2015-10-13 20:50:43', NULL),
(209, 'Tea', 3, 10, 0, NULL, '2015-10-13 20:51:04', NULL),
(210, 'Coffee', 3, 10, 0, NULL, '2015-10-13 20:51:33', NULL),
(211, 'Plain pulao', 1, 60, 0, NULL, '2015-10-14 20:08:59', NULL),
(212, 'Karahi Murgh', 1, 190, 0, NULL, '2015-10-14 20:20:21', NULL),
(213, 'Murgh Mirch masala', 1, 190, 0, NULL, '2015-10-14 20:21:15', NULL),
(214, 'Beef Panjabi', 1, 190, 0, NULL, '2015-10-14 20:21:45', '2016-01-11 16:31:12'),
(215, 'Beef Karahi', 1, 240, 0, NULL, '2015-10-14 20:22:23', '2016-01-11 16:29:53'),
(216, 'Achari Mutton', 1, 195, 0, NULL, '2015-10-14 20:23:03', NULL),
(217, 'Bhuna Mutton', 1, 190, 0, NULL, '2015-10-14 20:23:29', NULL),
(218, 'Mutton Karahi', 1, 250, 0, NULL, '2015-10-14 20:24:08', NULL),
(219, 'Prawn Masala', 1, 300, 0, NULL, '2015-10-14 20:25:02', NULL),
(220, 'Karahi Prawns', 1, 350, 0, NULL, '2015-10-14 20:25:40', NULL),
(221, 'Mixed Vegetable', 1, 85, 0, NULL, '2015-10-14 20:27:55', NULL),
(224, 'vegetable dupiaza', 0, 95, 0, NULL, '2015-10-14 21:05:34', NULL),
(225, 'vegetable curry', 1, 85, 0, NULL, '2015-10-14 21:14:17', NULL),
(226, 'daal tharka', 1, 90, 0, NULL, '2015-10-14 21:17:18', NULL),
(227, 'daal butter fry ', 1, 110, 0, NULL, '2015-10-14 21:19:06', NULL),
(228, 'Lunch Box- 3', 1, 270, 0, NULL, '2015-10-21 20:22:23', '2015-10-21 21:14:43'),
(229, 'Lunch Box 4', 1, 200, 0, NULL, '2015-10-21 20:24:29', NULL),
(230, 'Lunch Box 1', 1, 350, 0, NULL, '2015-10-21 21:15:32', NULL),
(231, 'Lunch Box 2', 1, 320, 0, NULL, '2015-10-21 21:15:53', NULL),
(232, 'Bowal Small', 1, 250, 0, NULL, '2015-10-23 19:15:33', '2015-12-29 15:06:13'),
(233, 'Bowal Big', 1, 300, 0, NULL, '2015-10-23 19:16:08', '2015-10-23 19:23:10'),
(234, 'Half Beef', 1, 90, 0, NULL, '2015-12-29 15:04:20', '2016-01-11 16:25:13'),
(235, 'Chicken Biriyani Bangla', 1, 125, 0, NULL, '2016-01-08 16:39:41', '2016-01-13 15:29:00'),
(236, 'Thai Fried Chicken (Half)', 1, 190, 0, NULL, '2016-01-08 16:40:33', NULL),
(237, 'Glass Of Milk', 1, 80, 0, NULL, '2016-01-10 19:26:13', NULL),
(238, 'Begun Bharta', 1, 60, 0, NULL, '2016-01-13 21:34:00', '2016-03-04 18:40:22'),
(239, 'Shutki Bharta', 1, 60, 0, NULL, '2016-01-13 21:34:48', '2016-03-04 18:40:05'),
(240, 'Fish Bharta', 1, 100, 0, NULL, '2016-01-13 21:35:54', '2016-03-04 18:41:41'),
(241, 'Alu Bharta', 1, 60, 0, NULL, '2016-01-13 21:36:45', '2016-03-04 18:40:42'),
(242, 'ShimBhazi', 1, 60, 0, NULL, '2016-01-13 21:37:34', '2016-03-04 18:39:30'),
(243, 'Half Vegetable', 1, 30, 0, NULL, '2016-01-16 19:29:10', NULL),
(244, 'Boiled Egg', 1, 25, 0, NULL, '2016-01-17 13:54:22', NULL),
(245, 'Bread Toast With butter Jem (2) p.c.s', 1, 60, 0, NULL, '2016-01-18 09:55:47', NULL),
(246, 'Complimentary.Mum 500', 1, 15, 0, NULL, '2016-01-29 12:31:13', NULL),
(247, 'Rupchada Medium', 1, 300, 0, NULL, '2016-01-29 15:55:40', NULL),
(248, 'Thai Soup Half', 1, 145, 0, NULL, '2016-01-31 20:53:47', NULL),
(249, 'Mum 1500 ml', 1, 20, 0, NULL, '2016-02-05 09:40:38', NULL),
(251, 'Pabda Medium ', 1, 300, 0, NULL, '2016-03-04 18:38:20', NULL),
(252, 'Berger', 0, 40, 0, NULL, '2019-12-29 06:32:11', NULL),
(253, 'Chicken Pasta', 1, 125, 0, NULL, '2019-12-30 22:45:56', NULL),
(254, 'Naga Pasta', 1, 130, 0, NULL, '2019-12-30 22:47:16', NULL),
(255, 'KidzVilla Special Pasta', 0, 180, 0, NULL, '2019-12-30 22:47:54', '2019-12-31 23:59:20'),
(256, 'Oven Bake Pasta', 1, 190, 0, NULL, '2019-12-30 22:48:24', '2019-12-31 23:59:02'),
(257, 'Chicken Chowmein', 1, 130, 0, NULL, '2019-12-30 22:49:16', '2019-12-31 23:58:27'),
(258, 'Sze-Chuan Chowmein', 1, 140, 0, NULL, '2019-12-30 22:50:01', '2019-12-31 23:58:01'),
(259, 'KidzVilla Special Chowmein', 1, 160, 0, NULL, '2019-12-30 22:50:35', '2019-12-31 23:57:43'),
(260, 'Fried Chicken 1PC', 1, 80, 0, NULL, '2019-12-30 22:56:01', '2019-12-31 23:56:16'),
(261, 'Crispy Chicken Drumstick 1PC', 1, 120, 0, NULL, '2019-12-30 22:57:04', '2019-12-31 23:55:51'),
(262, 'Crispy Chicken Wings 4PCs with French Fry', 1, 280, 0, NULL, '2019-12-30 22:58:46', NULL),
(263, 'BBQ Chicken 1PC', 1, 140, 0, NULL, '2019-12-30 22:59:34', '2019-12-31 23:52:53'),
(264, 'French Fry', 1, 80, 0, NULL, '2019-12-30 23:00:07', NULL),
(265, 'Chicken Sub Sandwich', 1, 100, 0, NULL, '2019-12-30 23:00:56', NULL),
(266, 'Chicken Cheese Sub Sandwich', 1, 150, 0, NULL, '2019-12-30 23:01:35', NULL),
(267, 'Crispy Chicken Sub Sandwich', 1, 130, 0, NULL, '2019-12-30 23:02:16', NULL),
(268, 'Naga Chicken Sub Sandwich', 1, 125, 0, NULL, '2019-12-30 23:02:55', NULL),
(269, 'Chicken Pizza 6 inch', 1, 260, 0, NULL, '2019-12-30 23:04:07', NULL),
(270, 'Chicken Pizza 10 inch', 1, 380, 0, NULL, '2019-12-30 23:04:38', NULL),
(271, 'Chicken BBQ Pizza 6 inch', 1, 300, 0, NULL, '2019-12-30 23:05:24', NULL),
(272, 'Chicken BBQ Pizza 10 inch', 1, 420, 0, NULL, '2019-12-30 23:06:02', NULL),
(273, 'KidzVilla Special Pizza 6 inch', 1, 380, 0, NULL, '2019-12-30 23:06:56', NULL),
(274, 'KidzVilla Special Pizza 10 inch', 1, 540, 0, NULL, '2019-12-30 23:07:20', NULL),
(275, 'Mexican Chicken Pizza 6 inch', 1, 380, 0, NULL, '2019-12-30 23:08:05', NULL),
(276, 'Mexican Chicken Pizza 10 inch', 1, 550, 0, NULL, '2019-12-30 23:08:28', NULL),
(278, 'Chicken Crispy Burger', 0, 100, 0, NULL, '2019-12-30 23:13:16', NULL),
(279, 'Chicken Crispy Burger', 1, 100, 0, NULL, '2019-12-30 23:14:07', NULL),
(280, 'Chicken Cheese Burger', 1, 120, 0, NULL, '2019-12-30 23:15:08', NULL),
(281, 'Double Crunch Chicken Burger', 1, 200, 0, NULL, '2019-12-30 23:15:47', NULL),
(282, 'KidzVilla Special Burger', 1, 230, 0, NULL, '2019-12-30 23:16:24', NULL),
(283, 'Chicken Naga Burger', 1, 140, 0, NULL, '2019-12-30 23:17:02', NULL),
(284, 'Chicken Naga Burger', 1, 140, 0, NULL, '2019-12-30 23:18:05', NULL),
(285, 'Chicken Party Burger', 1, 120, 0, NULL, '2019-12-30 23:18:38', NULL),
(286, 'BBQ Chicken Burger', 1, 120, 0, NULL, '2019-12-30 23:19:09', NULL),
(287, 'Chicken Corn Soup', 1, 100, 0, NULL, '2019-12-30 23:20:31', NULL),
(288, 'Vegetable Soup', 1, 80, 0, NULL, '2019-12-30 23:23:20', NULL),
(289, 'Cold Coffee', 1, 80, 0, NULL, '2019-12-30 23:24:53', NULL),
(290, 'Hot Coffee', 1, 70, 0, NULL, '2019-12-30 23:25:31', NULL),
(291, 'Dark Coffee', 1, 70, 0, NULL, '2019-12-30 23:25:57', NULL),
(292, 'Cappuccino Coffee', 1, 80, 0, NULL, '2019-12-30 23:26:33', NULL),
(293, 'Hot Chocolate Coffee', 1, 80, 0, NULL, '2019-12-30 23:27:14', NULL),
(294, 'Strawberry Red Lemon', 1, 80, 0, NULL, '2019-12-30 23:28:05', NULL),
(295, 'Mint Lime', 1, 100, 0, NULL, '2019-12-30 23:29:27', NULL),
(296, 'Virgin Mojoto', 1, 80, 0, NULL, '2019-12-30 23:30:03', NULL),
(297, 'Orio Shake', 1, 130, 0, NULL, '2019-12-30 23:57:48', NULL),
(298, 'Strawberry Shake', 1, 120, 0, NULL, '2019-12-30 23:59:01', NULL),
(299, 'Vanilla Shake', 1, 120, 0, NULL, '2019-12-30 23:59:26', NULL),
(300, 'Mango Shake', 1, 110, 0, NULL, '2019-12-31 00:00:29', NULL),
(301, 'Chocolate Shake', 1, 110, 0, NULL, '2019-12-31 00:00:59', NULL),
(302, 'Scoope-Vanila', 1, 70, 0, NULL, '2019-12-31 00:02:05', NULL),
(303, 'Scoope-Strawberry', 1, 70, 0, NULL, '2019-12-31 00:17:09', NULL),
(304, 'Scoope-Chocolate', 1, 70, 0, NULL, '2019-12-31 00:17:36', NULL),
(305, 'Scoope-Mango', 1, 70, 0, NULL, '2019-12-31 00:18:09', NULL),
(306, '3 Scoope Mix', 1, 120, 0, NULL, '2019-12-31 00:18:42', NULL),
(307, 'Chicken Pasta', 1, 125, 0, NULL, '2019-12-31 08:14:02', NULL),
(308, 'Water 250ml', 1, 10, 0, NULL, '2020-01-01 03:08:35', NULL),
(309, 'Water 500ml', 1, 15, 0, NULL, '2020-01-01 03:09:48', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `service_in_room`
--

CREATE TABLE `service_in_room` (
  `serv_room_id` int(11) NOT NULL,
  `reservation_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `service_date` date DEFAULT NULL,
  `service_time` time DEFAULT NULL,
  `service_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `is_complete` tinyint(1) DEFAULT 0,
  `status` tinyint(1) DEFAULT 0,
  `userID` int(11) DEFAULT NULL,
  `DOC` int(11) DEFAULT NULL,
  `DOM` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_in_room`
--

INSERT INTO `service_in_room` (`serv_room_id`, `reservation_id`, `room_id`, `service_date`, `service_time`, `service_id`, `quantity`, `is_complete`, `status`, `userID`, `DOC`, `DOM`) VALUES
(1, 0, 0, '2019-12-29', '19:12:49', 12, 2, 1, 0, 12, NULL, NULL),
(2, 0, 0, '2019-12-29', '19:12:52', 12, 2, 1, 0, 12, NULL, NULL),
(3, 0, 0, '2019-12-29', '19:13:01', 12, 2, 1, 0, 12, NULL, NULL),
(4, 0, 0, '2019-12-29', '19:14:43', 130, 2, 1, 0, 12, NULL, NULL),
(5, 0, 0, '2019-12-29', '19:15:14', 130, 2, 1, 0, 12, NULL, NULL),
(6, 0, 0, '2019-12-29', '19:15:14', 130, 2, 1, 0, 12, NULL, NULL),
(7, 0, 0, '2019-12-29', '19:15:15', 130, 2, 1, 0, 12, NULL, NULL),
(8, 0, 0, '2019-12-29', '19:15:15', 130, 2, 1, 0, 12, NULL, NULL),
(9, 0, 0, '2019-12-29', '19:15:19', 130, 2, 1, 0, 12, NULL, NULL),
(10, 0, 0, '2019-12-29', '19:15:34', 130, 2, 1, 0, 12, NULL, NULL),
(11, 0, 0, '2019-12-29', '19:15:34', 130, 2, 1, 0, 12, NULL, NULL),
(12, 0, 0, '2019-12-29', '19:15:35', 130, 2, 1, 0, 12, NULL, NULL),
(13, 0, 0, '2019-12-29', '19:15:35', 130, 2, 1, 0, 12, NULL, NULL),
(14, 0, 0, '2019-12-29', '19:15:38', 130, 2, 1, 0, 12, NULL, NULL),
(15, 0, 0, '2019-12-29', '19:15:38', 130, 2, 1, 0, 12, NULL, NULL),
(16, 0, 0, '2019-12-29', '19:15:38', 130, 2, 1, 0, 12, NULL, NULL),
(17, 0, 0, '2019-12-29', '19:17:18', 163, 2, 1, 0, 12, NULL, NULL),
(18, 0, 0, '2019-12-29', '19:17:28', 163, 2, 1, 0, 12, NULL, NULL),
(19, 0, 0, '2019-12-29', '19:17:30', 163, 2, 1, 0, 12, NULL, NULL),
(20, 0, 0, '2019-12-29', '19:17:40', 163, 2, 1, 0, 12, NULL, NULL),
(21, 0, 0, '2019-12-29', '19:17:49', 163, 2, 1, 0, 12, NULL, NULL),
(22, 0, 0, '2019-12-29', '19:20:41', 13, 2, 1, 0, 12, NULL, NULL),
(23, 0, 0, '2019-12-29', '19:26:45', 148, 3, 1, 0, 12, NULL, NULL),
(24, 0, 0, '2019-12-29', '19:26:57', 132, 2, 1, 0, 12, NULL, NULL),
(25, 0, 0, '2019-12-29', '19:34:02', 252, 2, 1, 0, 12, NULL, NULL),
(26, 0, 0, '2019-12-30', '19:03:23', 252, 1, 1, 0, 12, NULL, NULL),
(28, 0, 0, '2019-12-30', '23:24:20', 252, 2, 1, 0, 12, NULL, NULL),
(29, 0, 0, '2019-12-31', '10:24:07', 252, 2, 1, 0, 12, NULL, NULL),
(30, 0, 0, '2019-12-31', '11:23:02', 252, 2, 1, 0, 12, NULL, NULL),
(31, 0, 0, '2019-12-31', '13:39:42', 304, 1, 1, 0, 12, NULL, NULL),
(32, 0, 0, '2019-12-31', '13:40:11', 294, 1, 1, 0, 12, NULL, NULL),
(33, 0, 0, '2019-12-31', '13:42:16', 264, 1, 1, 0, 12, NULL, NULL),
(34, 0, 0, '2019-12-31', '13:42:16', 264, 1, 1, 0, 12, NULL, NULL),
(35, 0, 0, '2019-12-31', '13:43:08', 265, 1, 1, 0, 12, NULL, NULL),
(36, 0, 0, '2019-12-31', '13:44:30', 72, 1, 1, 0, 12, NULL, NULL),
(37, 0, 0, '2019-12-31', '16:58:50', 264, 1, 1, 0, 12, NULL, NULL),
(38, 0, 0, '2019-12-31', '17:03:09', 264, 1, 1, 0, 12, NULL, NULL),
(39, 0, 0, '2019-12-31', '17:03:23', 292, 1, 1, 0, 12, NULL, NULL),
(40, 0, 0, '2019-12-31', '17:03:41', 293, 1, 1, 0, 12, NULL, NULL),
(41, 0, 0, '2019-12-31', '17:08:52', 293, 2, 1, 0, 12, NULL, NULL),
(42, 0, 0, '2019-12-31', '17:40:30', 260, 2, 1, 0, 12, NULL, NULL),
(43, 0, 0, '2019-12-31', '17:41:22', 260, 3, 1, 0, 12, NULL, NULL),
(44, 0, 0, '2019-12-31', '17:41:41', 264, 1, 1, 0, 12, NULL, NULL),
(45, 0, 0, '2019-12-31', '17:41:54', 290, 2, 1, 0, 12, NULL, NULL),
(46, 0, 0, '2019-12-31', '17:57:37', 302, 1, 1, 0, 12, NULL, NULL),
(47, 0, 0, '2019-12-31', '18:02:15', 302, 1, 1, 0, 12, NULL, NULL),
(48, 0, 0, '2019-12-31', '18:05:43', 290, 1, 1, 0, 12, NULL, NULL),
(49, 0, 0, '2019-12-31', '18:11:27', 264, 1, 1, 0, 12, NULL, NULL),
(50, 0, 0, '2019-12-31', '18:46:36', 290, 2, 1, 0, 12, NULL, NULL),
(51, 0, 0, '2019-12-31', '18:48:34', 290, 2, 1, 0, 12, NULL, NULL),
(52, 0, 0, '2019-12-31', '18:50:38', 260, 2, 1, 0, 12, NULL, NULL),
(53, 0, 0, '2019-12-31', '19:01:38', 280, 1, 1, 0, 12, NULL, NULL),
(54, 0, 0, '2019-12-31', '19:23:06', 260, 4, 1, 0, 12, NULL, NULL),
(55, 0, 0, '2019-12-31', '19:23:25', 264, 1, 1, 0, 12, NULL, NULL),
(56, 0, 0, '2019-12-31', '21:01:25', 260, 2, 1, 0, 12, NULL, NULL),
(57, 0, 0, '2019-12-31', '21:01:37', 261, 2, 1, 0, 12, NULL, NULL),
(58, 0, 0, '2019-12-31', '21:01:49', 254, 1, 1, 0, 12, NULL, NULL),
(59, 0, 0, '2019-12-31', '21:08:10', 290, 3, 1, 0, 12, NULL, NULL),
(60, 0, 0, '2019-12-31', '21:08:29', 253, 1, 1, 0, 12, NULL, NULL),
(61, 0, 0, '2019-12-31', '21:08:56', 253, 1, 1, 0, 12, NULL, NULL),
(62, 0, 0, '2019-12-31', '21:09:43', 253, 1, 1, 0, 12, NULL, NULL),
(63, 0, 0, '2019-12-31', '21:10:03', 253, 1, 1, 0, 12, NULL, NULL),
(64, 0, 0, '2019-12-31', '21:10:29', 253, 1, 1, 0, 12, NULL, NULL),
(65, 0, 0, '2019-12-31', '21:10:45', 254, 1, 1, 0, 12, NULL, NULL),
(66, 0, 0, '2019-12-31', '21:10:59', 253, 1, 1, 0, 12, NULL, NULL),
(67, 0, 0, '2019-12-31', '21:11:24', 255, 1, 1, 0, 12, NULL, NULL),
(68, 0, 0, '2019-12-31', '21:14:23', 253, 1, 1, 0, 12, NULL, NULL),
(69, 0, 0, '2019-12-31', '21:14:32', 253, 1, 1, 0, 12, NULL, NULL),
(70, 0, 0, '2019-12-31', '21:14:55', 254, 1, 1, 0, 12, NULL, NULL),
(71, 0, 0, '2019-12-31', '21:15:06', 290, 3, 1, 0, 12, NULL, NULL),
(72, 0, 0, '2019-12-31', '21:36:29', 264, 2, 1, 0, 12, NULL, NULL),
(73, 0, 0, '2019-12-31', '21:36:42', 296, 1, 1, 0, 12, NULL, NULL),
(74, 0, 0, '2019-12-31', '21:39:15', 257, 1, 1, 0, 12, NULL, NULL),
(75, 0, 0, '2019-12-31', '21:39:31', 260, 3, 1, 0, 12, NULL, NULL),
(76, 0, 0, '2020-01-01', '12:09:05', 260, 1, 1, 0, 12, NULL, NULL),
(77, 0, 0, '2020-01-01', '12:09:15', 261, 1, 1, 0, 12, NULL, NULL),
(78, 0, 0, '2020-01-01', '12:09:24', 263, 1, 1, 0, 12, NULL, NULL),
(79, 0, 0, '2020-01-01', '12:18:54', 253, 1, 1, 0, 12, NULL, NULL),
(80, 0, 0, '2020-01-01', '12:19:42', 260, 1, 1, 0, 12, NULL, NULL),
(81, 0, 0, '2020-01-01', '12:19:48', 261, 1, 1, 0, 12, NULL, NULL),
(82, 0, 0, '2020-01-01', '12:20:03', 263, 1, 1, 0, 12, NULL, NULL),
(83, 0, 0, '2020-01-01', '12:20:09', 253, 1, 1, 0, 12, NULL, NULL),
(84, 0, 0, '2020-01-01', '12:20:34', 253, 1, 1, 0, 12, NULL, NULL),
(85, 0, 0, '2020-01-01', '12:20:40', 254, 1, 1, 0, 12, NULL, NULL),
(86, 0, 0, '2020-01-01', '14:58:26', 252, 2, 1, 0, 12, NULL, NULL),
(87, 0, 0, '2020-01-01', '15:01:51', 85, 2, 1, 0, 12, NULL, NULL),
(88, 0, 0, '2020-01-01', '15:06:04', 294, 2, 1, 0, 12, NULL, NULL),
(89, 0, 0, '2020-01-01', '15:06:04', 294, 2, 1, 0, 12, NULL, NULL),
(90, 0, 0, '2020-01-01', '16:43:48', 278, 1, 1, 0, 12, NULL, NULL),
(91, 0, 0, '2020-01-01', '16:44:03', 280, 2, 1, 0, 12, NULL, NULL),
(92, 0, 0, '2020-01-01', '16:44:51', 308, 3, 1, 0, 12, NULL, NULL),
(93, 0, 0, '2020-01-01', '17:08:14', 257, 1, 1, 0, 12, NULL, NULL),
(94, 0, 0, '2020-01-01', '17:08:32', 293, 2, 1, 0, 12, NULL, NULL),
(95, 0, 0, '2020-01-01', '17:08:47', 264, 1, 1, 0, 12, NULL, NULL),
(96, 0, 0, '2020-01-01', '17:29:32', 309, 1, 1, 0, 12, NULL, NULL),
(97, 0, 0, '2020-01-01', '18:42:09', 265, 1, 1, 0, 12, NULL, NULL),
(98, 0, 0, '2020-01-01', '18:42:33', 264, 1, 1, 0, 12, NULL, NULL),
(99, 0, 0, '2020-01-01', '18:42:43', 257, 1, 1, 0, 12, NULL, NULL),
(100, 0, 0, '2020-01-01', '19:24:41', 260, 1, 1, 0, 12, NULL, NULL),
(101, 0, 0, '2020-01-01', '19:24:51', 264, 1, 1, 0, 12, NULL, NULL),
(104, 0, 0, '2020-01-01', '19:59:51', 260, 3, 1, 0, 12, NULL, NULL),
(105, 0, 0, '2020-01-01', '20:00:05', 264, 2, 1, 0, 12, NULL, NULL),
(106, 0, 0, '2020-01-01', '20:00:25', 257, 1, 1, 0, 12, NULL, NULL),
(107, 0, 0, '2020-01-01', '20:01:41', 309, 2, 1, 0, 12, NULL, NULL),
(108, 0, 0, '2020-01-01', '20:23:37', 265, 1, 1, 0, 12, NULL, NULL),
(109, 0, 0, '2020-01-01', '20:26:27', 308, 1, 1, 0, 12, NULL, NULL),
(111, 0, 0, '2020-01-02', '13:19:07', 260, 4, 1, 0, 12, NULL, NULL),
(112, 0, 0, '2020-01-02', '13:19:28', 264, 2, 1, 0, 12, NULL, NULL),
(113, 0, 0, '2020-01-02', '13:19:47', 309, 1, 1, 0, 12, NULL, NULL),
(114, 0, 0, '2020-01-02', '14:00:31', 308, 1, 1, 0, 12, NULL, NULL),
(115, 0, 0, '2020-01-02', '14:05:00', 264, 1, 1, 0, 12, NULL, NULL),
(116, 0, 0, '2020-01-02', '15:50:38', 290, 2, 1, 0, 12, NULL, NULL),
(117, 0, 0, '2020-01-02', '16:38:58', 287, 1, 1, 0, 12, NULL, NULL),
(118, 0, 0, '2020-01-02', '17:15:44', 260, 6, 1, 0, 12, NULL, NULL),
(119, 0, 0, '2020-01-02', '17:15:57', 264, 3, 1, 0, 12, NULL, NULL),
(120, 0, 0, '2020-01-02', '17:16:19', 280, 10, 1, 0, 12, NULL, NULL),
(121, 0, 0, '2020-01-02', '17:16:29', 309, 2, 1, 0, 12, NULL, NULL),
(122, 0, 0, '2020-01-02', '17:17:29', 253, 2, 1, 0, 12, NULL, NULL),
(123, 0, 0, '2020-01-02', '17:17:57', 253, 2, 1, 0, 12, NULL, NULL),
(124, 0, 0, '2020-01-02', '17:19:57', 253, 2, 1, 0, 12, NULL, NULL),
(125, 0, 0, '2020-01-02', '17:23:23', 253, 2, 1, 0, 12, NULL, NULL),
(126, 0, 0, '2020-01-02', '17:23:47', 253, 2, 1, 0, 12, NULL, NULL),
(127, 0, 0, '2020-01-02', '17:24:34', 280, 10, 1, 0, 12, NULL, NULL),
(128, 0, 0, '2020-01-02', '17:24:48', 264, 3, 1, 0, 12, NULL, NULL),
(129, 0, 0, '2020-01-02', '17:24:59', 260, 6, 1, 0, 12, NULL, NULL),
(130, 0, 0, '2020-01-02', '17:25:10', 253, 2, 1, 0, 12, NULL, NULL),
(131, 0, 0, '2020-01-02', '17:25:23', 253, 2, 1, 0, 12, NULL, NULL),
(132, 0, 0, '2020-01-02', '17:25:39', 253, 2, 1, 0, 12, NULL, NULL),
(133, 0, 0, '2020-01-02', '17:29:08', 253, 2, 1, 0, 12, NULL, NULL),
(134, 0, 0, '2020-01-02', '17:29:19', 253, 2, 1, 0, 12, NULL, NULL),
(135, 0, 0, '2020-01-02', '17:29:46', 253, 2, 1, 0, 12, NULL, NULL),
(136, 0, 0, '2020-01-02', '17:30:09', 253, 2, 1, 0, 12, NULL, NULL),
(137, 0, 0, '2020-01-02', '17:30:40', 260, 6, 1, 0, 12, NULL, NULL),
(138, 0, 0, '2020-01-02', '17:31:00', 264, 3, 1, 0, 12, NULL, NULL),
(139, 0, 0, '2020-01-02', '17:31:17', 280, 10, 1, 0, 12, NULL, NULL),
(140, 0, 0, '2020-01-02', '17:31:36', 253, 2, 1, 0, 12, NULL, NULL),
(141, 0, 0, '2020-01-02', '17:31:53', 309, 2, 1, 0, 12, NULL, NULL),
(142, 0, 0, '2020-01-02', '17:32:10', 253, 2, 1, 0, 12, NULL, NULL),
(143, 0, 0, '2020-01-02', '17:36:52', 308, 1, 1, 0, 12, NULL, NULL),
(144, 0, 0, '2020-01-02', '17:43:17', 253, 2, 1, 0, 12, NULL, NULL),
(145, 0, 0, '2020-01-02', '17:58:50', 264, 2, 1, 0, 12, NULL, NULL),
(146, 0, 0, '2020-01-02', '18:35:49', 308, 1, 1, 0, 12, NULL, NULL),
(147, 0, 0, '2020-01-02', '18:36:03', 290, 2, 1, 0, 12, NULL, NULL),
(148, 0, 0, '2020-01-02', '18:48:33', 307, 2, 1, 0, 12, NULL, NULL),
(149, 0, 0, '2020-01-02', '18:54:35', 278, 3, 1, 0, 12, NULL, NULL),
(150, 0, 0, '2020-01-02', '18:55:02', 264, 1, 1, 0, 12, NULL, NULL),
(151, 0, 0, '2020-01-02', '18:57:03', 264, 1, 1, 0, 12, NULL, NULL),
(152, 0, 0, '2020-01-02', '18:57:03', 264, 1, 1, 0, 12, NULL, NULL),
(153, 0, 0, '2020-01-02', '18:57:42', 264, 1, 1, 0, 12, NULL, NULL),
(154, 0, 0, '2020-01-02', '18:57:53', 280, 1, 1, 0, 12, NULL, NULL),
(155, 0, 0, '2020-01-02', '18:58:01', 290, 1, 1, 0, 12, NULL, NULL),
(156, 0, 0, '2020-01-02', '19:18:34', 309, 1, 1, 0, 12, NULL, NULL),
(157, 0, 0, '2020-01-03', '16:18:10', 259, 1, 1, 0, 12, NULL, NULL),
(158, 0, 0, '2020-01-03', '16:18:37', 265, 1, 1, 0, 12, NULL, NULL),
(159, 0, 0, '2020-01-03', '16:21:56', 259, 1, 1, 0, 12, NULL, NULL),
(160, 0, 0, '2020-01-03', '16:59:30', 255, 1, 1, 0, 12, NULL, NULL),
(161, 0, 0, '2020-01-03', '17:00:42', 255, 1, 1, 0, 12, NULL, NULL),
(162, 0, 0, '2020-01-03', '17:01:51', 255, 1, 1, 0, 12, NULL, NULL),
(163, 0, 0, '2020-01-03', '17:02:58', 255, 1, 1, 0, 12, NULL, NULL),
(164, 0, 0, '2020-01-03', '17:02:59', 255, 1, 1, 0, 12, NULL, NULL),
(165, 0, 0, '2020-01-03', '17:28:37', 278, 1, 1, 0, 12, NULL, NULL),
(166, 0, 0, '2020-01-03', '17:29:10', 264, 1, 1, 0, 12, NULL, NULL),
(168, 0, 0, '2020-01-03', '17:35:07', 290, 1, 1, 0, 12, NULL, NULL),
(169, 0, 0, '2020-01-03', '17:48:36', 264, 2, 1, 0, 12, NULL, NULL),
(170, 0, 0, '2020-01-03', '17:48:36', 264, 2, 1, 0, 12, NULL, NULL),
(171, 0, 0, '2020-01-03', '17:55:20', 264, 1, 1, 0, 12, NULL, NULL),
(172, 0, 0, '2020-01-03', '17:55:20', 264, 1, 1, 0, 12, NULL, NULL),
(174, 0, 0, '2020-01-03', '18:36:29', 264, 2, 1, 0, 12, NULL, NULL),
(175, 0, 0, '2020-01-03', '18:37:05', 280, 2, 1, 0, 12, NULL, NULL),
(176, 0, 0, '2020-01-03', '18:37:45', 280, 1, 1, 0, 12, NULL, NULL),
(177, 0, 0, '2020-01-03', '18:37:59', 254, 1, 1, 0, 12, NULL, NULL),
(178, 0, 0, '2020-01-03', '18:38:12', 309, 1, 1, 0, 12, NULL, NULL),
(179, 0, 0, '2020-01-03', '18:41:44', 253, 1, 1, 0, 12, NULL, NULL),
(180, 0, 0, '2020-01-03', '18:42:19', 253, 1, 1, 0, 12, NULL, NULL),
(181, 0, 0, '2020-01-03', '18:47:07', 253, 1, 1, 0, 12, NULL, NULL),
(183, 0, 0, '2020-01-03', '18:50:39', 264, 1, 1, 0, 12, NULL, NULL),
(184, 0, 0, '2020-01-03', '20:24:54', 308, 3, 1, 0, 12, NULL, NULL),
(185, 0, 0, '2020-01-03', '20:32:35', 308, 1, 1, 0, 12, NULL, NULL),
(187, 0, 0, '2020-01-03', '20:35:01', 262, 1, 1, 0, 12, NULL, NULL),
(188, 0, 0, '2020-01-03', '20:41:31', 257, 1, 1, 0, 12, NULL, NULL),
(189, 0, 0, '2020-01-03', '20:41:40', 264, 1, 1, 0, 12, NULL, NULL),
(190, 0, 0, '2020-01-03', '20:43:57', 296, 1, 1, 0, 12, NULL, NULL),
(191, 0, 0, '2020-01-03', '20:44:41', 296, 1, 1, 0, 12, NULL, NULL),
(192, 0, 0, '2020-01-04', '11:18:02', 269, 1, 1, 0, 12, NULL, NULL),
(193, 0, 0, '2020-01-04', '11:18:11', 265, 2, 1, 0, 12, NULL, NULL),
(194, 0, 0, '2020-01-04', '13:28:53', 265, 1, 1, 0, 12, NULL, NULL),
(195, 0, 0, '2020-01-04', '13:29:18', 253, 1, 1, 0, 12, NULL, NULL),
(196, 0, 0, '2020-01-04', '13:29:30', 264, 1, 1, 0, 12, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `service_typ`
--

CREATE TABLE `service_typ` (
  `service_typ_id` int(11) NOT NULL,
  `service_typ_name` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `userID` int(11) NOT NULL,
  `DOC` datetime NOT NULL DEFAULT current_timestamp(),
  `DOM` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_typ`
--

INSERT INTO `service_typ` (`service_typ_id`, `service_typ_name`, `status`, `userID`, `DOC`, `DOM`) VALUES
(1, 'Food', 0, 0, '2015-05-01 02:16:06', '2015-05-01 02:33:32'),
(2, 'Travel', 0, 0, '2015-05-01 02:17:04', '2015-05-01 02:37:11'),
(3, 'Complementry', 0, 0, '2015-05-01 08:45:14', '2015-05-01 10:00:36');

-- --------------------------------------------------------

--
-- Table structure for table `stuff_info`
--

CREATE TABLE `stuff_info` (
  `stuff_id` int(11) NOT NULL,
  `stuff_name` varchar(100) NOT NULL,
  `contact` varchar(18) NOT NULL,
  `address` varchar(230) NOT NULL,
  `resignation` varchar(50) NOT NULL,
  `active_status` tinyint(1) NOT NULL,
  `DOC` date NOT NULL,
  `creator` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stuff_info`
--

INSERT INTO `stuff_info` (`stuff_id`, `stuff_name`, `contact`, `address`, `resignation`, `active_status`, `DOC`, `creator`) VALUES
(1, 'Ashraf Hasan', '01714486835', 'Modhushohid,Sylhet', 'Restaurant Manager', 0, '2015-05-27', 12),
(2, 'Anas Ahmed', '01714725005', 'Jalalabad, Sylhet', 'IT Manager', 0, '2015-05-27', 12),
(3, 'Rayhan Miah Choudhury', '01726926535', 'Sunamgonj, Sylhet', 'Front Desk Officer', 0, '2015-05-27', 12),
(4, 'Sadekur Rahman (R.C.O).', '01779382726', 'Borolekha, Moulivibazar', 'RCO', 0, '2015-06-02', 15),
(5, 'Kholil-ullah', '01671879131', 'Amberkhana, Sylhet', 'Accountant', 0, '2015-06-02', 15),
(6, 'Md Mahbub Alom', '01862145868', 'Shunamgong', 'Painty Boy', 0, '2015-06-03', 14),
(7, 'Mamunur Rashid', '', '', 'Marketing Maneger', 0, '2015-06-06', 14),
(8, 'Laptop Source', '01611527867', 'Hiltown Hotel, Taltola,Sylhet', 'Laptop Shop', 0, '2015-06-06', 15),
(9, 'Ashikur Rahman', '01753044254', 'Modina Market, Sylhet', 'Front Desk Officer', 0, '2015-06-07', 15),
(10, 'Shuhag Ahmed', '01748003364', 'Laksmipur, Chittagong', 'Waiter', 0, '2015-06-09', 14),
(11, 'Arif Ahmed', '01768642739', 'Jokigonj, Sylhet', 'Asst. Chef', 0, '2015-06-10', 14),
(13, 'balal ahmed', '01965234510', 'B bareya', 'panty boy', 0, '2015-06-16', 14),
(14, 'Abdul Amin', '01775200322', 'jogonnath, Syhet', 'Panty Boy', 0, '2015-06-17', 14),
(15, 'Nikhil Das', '0187866825', 'Sunamgonj', 'Cleaner', 0, '2015-09-22', 17),
(16, 'Kasir Ahmed', '01712724836', 'Jokigonj', 'Front Officer', 0, '2015-09-22', 17),
(17, 'Aminul Islam', '01915883726', 'Jokigonj', 'Room Service', 0, '2015-09-22', 17),
(18, 'Riaj Ahmed', '01780311238', 'Sunamgonj', 'Room Service', 0, '2015-09-22', 17),
(19, 'Md Alom', '01727717728', 'Sunamgonj', 'Bell Boy', 0, '2015-09-30', 15),
(20, 'Shibbir Ahmed', '01741612200', 'Jokigonj', 'Room Service', 0, '2015-10-04', 17),
(21, 'Munna Ahmed', '01794459925', 'Golapgonj', 'Panty Boy', 0, '2015-10-04', 17),
(22, 'Mahbub Ahmed', '01862145868', 'Sunamgonj', 'Pantry Boy', 0, '2015-10-04', 17),
(23, 'Rubel Ahmed', '01750772879', 'Kamal Bazar, Biswanath,Sylhet', 'Receptionist', 0, '2015-10-04', 17),
(24, 'Nasir Uddin', '01712322397', 'Sunamgonj', 'Supervisor', 0, '2015-10-04', 17),
(25, 'Jamal ', '00', 'Sylhet', 'Cleaner', 0, '2015-10-04', 17),
(26, 'Mamun', '00', '', 'Cleaner', 0, '2015-10-04', 17),
(27, 'Malek', '01674856158', 'Fenchugonj', 'Maintenance ', 0, '2015-10-04', 17),
(28, 'Shofi-ullah', '01753112254', 'Comilla', 'Secuirity', 0, '2015-10-04', 17),
(29, 'Rahi D/W', '0177355529', '', 'Dish Wash', 0, '2015-10-07', 15),
(30, 'Rasel D/W', '0000', 'Sunamgonj', 'Dish Wash', 0, '2015-10-07', 15),
(31, 'Nazmul R/S', '0000', '', 'Room Service', 0, '2015-10-08', 17),
(32, 'Shahin Ahmed', '0000', 'jogonnathpur', 'Waiter', 0, '2015-10-08', 17),
(33, 'Abdul Malek', '01743001617', 'Biswanath', 'R C O', 0, '2015-10-08', 17),
(34, 'Alom Ahmed', '000000', 'Jokigonj', 'Dish Wash', 0, '2015-10-12', 15),
(35, 'Monirul islam', '000', 'Sylhet', 'Super visor', 0, '2015-10-16', 15),
(36, 'Sanjay', '0000', '', 'Room Service', 0, '2015-10-17', 15),
(37, 'Md Abdul Malek', '000000000000', 'Zgonnatpur', 'R.C.O', 0, '2015-10-19', 15),
(38, 'Ahbabur rahman ahbab', '01723191952', 'Biswanath sylhet', 'R.C.O', 0, '2015-10-19', 15),
(39, 'Ahbab Rahman', '01723191952', 'Biswanath, Sylhet', 'R C O', 0, '2015-11-14', 17),
(40, 'Mozammel Hossain', '01709096365', 'Sunamgonj, Sylhet', 'Waiter', 0, '2015-12-06', 19),
(41, 'Shamim Ahmed', '0000000000', 'Sunamgonj', 'Cleanar', 0, '2015-12-07', 15),
(42, 'Rana', '01911915593', 'Brmmonbaria', 'Room Service', 0, '2016-01-12', 19),
(43, 'Md.Sanuwar Hussain', '01766869201', 'Zogonnatpur.', 'R/S', 0, '2016-01-13', 15),
(44, 'Md.Alom Miah', '01926626989', 'Sunamgonj', 'Room Service', 0, '2016-01-16', 15),
(45, 'Rihad Ahmed', '0744814863', 'Jogonnathpur', 'R/S', 0, '2016-01-19', 15),
(46, 'Kobir Clenar', '', 'Borishal', 'clenar', 0, '2016-01-26', 15),
(47, 'Md.Shofiullah', '0000000', 'Kumillah', 'Security Guard ', 0, '2016-01-26', 15),
(48, 'Abdul malek Etc', '01780626233', 'South Surma', 'Electrician', 0, '2016-02-09', 15),
(49, 'Junayed Miah', '000000000', 'Bisshonath', 'Cleanar', 0, '2016-02-13', 15),
(50, 'Test Name', '01715928034', 'My Address', 'Waiter', 1, '2016-03-20', 12);

-- --------------------------------------------------------

--
-- Table structure for table `stuff_order_info`
--

CREATE TABLE `stuff_order_info` (
  `stuff_order_id` int(11) NOT NULL,
  `order_info_id` int(10) NOT NULL,
  `stuff_info_id` int(10) NOT NULL,
  `doc` datetime NOT NULL DEFAULT current_timestamp(),
  `dom` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `creator` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stuff_order_info`
--

INSERT INTO `stuff_order_info` (`stuff_order_id`, `order_info_id`, `stuff_info_id`, `doc`, `dom`, `creator`) VALUES
(1, 9, 2, '2015-06-02 16:08:16', '2015-06-02 10:08:16', 15),
(2, 10, 5, '2015-06-02 16:22:57', '2015-06-02 10:22:57', 15),
(3, 29, 7, '2015-06-06 16:01:39', '2015-06-06 10:01:39', 14),
(4, 30, 7, '2015-06-06 16:03:17', '2015-06-06 10:03:17', 14),
(5, 31, 5, '2015-06-06 16:06:24', '2015-06-06 10:06:24', 14),
(6, 32, 5, '2015-06-06 16:09:58', '2015-06-06 10:09:58', 14),
(7, 37, 8, '2015-06-06 19:23:07', '2015-06-06 13:23:07', 15),
(8, 46, 9, '2015-06-07 11:40:11', '2015-06-07 05:40:11', 15),
(9, 53, 8, '2015-06-07 17:54:06', '2015-06-07 11:54:06', 12),
(10, 58, 3, '2015-06-08 12:22:20', '2015-06-08 06:22:20', 15),
(11, 59, 0, '2015-06-08 19:45:24', '2015-06-08 13:45:24', 14),
(12, 74, 10, '2015-06-09 14:37:11', '2015-06-09 08:37:11', 14),
(13, 75, 2, '2015-06-09 14:40:47', '2015-06-09 08:40:47', 14),
(14, 78, 7, '2015-06-09 15:24:44', '2015-06-09 09:24:44', 15),
(15, 79, 8, '2015-06-09 16:18:04', '2015-06-09 10:18:04', 15),
(16, 101, 1, '2015-06-10 16:21:05', '2015-06-10 10:21:05', 14),
(17, 102, 5, '2015-06-10 16:23:00', '2015-06-10 10:23:00', 14),
(18, 103, 7, '2015-06-10 16:24:21', '2015-06-10 10:24:21', 14),
(19, 104, 7, '2015-06-10 16:26:06', '2015-06-10 10:26:06', 14),
(20, 105, 5, '2015-06-10 16:40:35', '2015-06-10 10:40:35', 14),
(21, 106, 8, '2015-06-10 18:11:08', '2015-06-10 12:11:08', 14),
(22, 107, 8, '2015-06-10 18:11:08', '2015-06-10 12:11:08', 14),
(23, 109, 11, '2015-06-10 18:34:12', '2015-06-10 12:34:12', 14),
(24, 111, 7, '2015-06-10 20:57:19', '2015-06-10 14:57:19', 14),
(25, 112, 7, '2015-06-10 21:02:17', '2015-06-10 15:02:17', 14),
(26, 113, 7, '2015-06-10 21:02:17', '2015-06-10 15:02:17', 14),
(27, 121, 8, '2015-06-11 16:11:01', '2015-06-11 10:11:01', 14),
(28, 122, 7, '2015-06-11 16:14:29', '2015-06-11 10:14:29', 14),
(29, 149, 0, '2015-06-12 20:49:00', '2015-06-12 14:49:00', 15),
(30, 150, 0, '2015-06-12 20:59:15', '2015-06-12 14:59:15', 15),
(31, 151, 0, '2015-06-12 21:03:35', '2015-06-12 15:03:35', 15),
(32, 152, 0, '2015-06-12 21:10:33', '2015-06-12 15:10:33', 15),
(33, 167, 7, '2015-06-13 14:55:29', '2015-06-13 08:55:29', 15),
(34, 170, 8, '2015-06-13 15:11:06', '2015-06-13 09:11:06', 15),
(35, 179, 7, '2015-06-14 14:49:15', '2015-06-14 08:49:15', 15),
(36, 180, 8, '2015-06-14 14:50:48', '2015-06-14 08:50:48', 15),
(37, 181, 5, '2015-06-14 15:50:00', '2015-06-14 09:50:00', 15),
(38, 183, 5, '2015-06-14 15:56:00', '2015-06-14 09:56:00', 15),
(39, 194, 7, '2015-06-15 14:45:26', '2015-06-15 08:45:26', 14),
(40, 195, 7, '2015-06-15 14:47:47', '2015-06-15 08:47:47', 14),
(41, 196, 8, '2015-06-15 14:50:52', '2015-06-15 08:50:52', 15),
(42, 205, 7, '2015-06-16 14:22:23', '2015-06-16 08:22:23', 14),
(43, 210, 8, '2015-06-16 16:49:34', '2015-06-16 10:49:34', 14),
(44, 217, 8, '2015-06-16 21:31:39', '2015-06-16 15:31:39', 15),
(45, 218, 9, '2015-06-16 21:33:37', '2015-06-16 15:33:37', 15),
(46, 221, 10, '2015-06-16 21:42:10', '2015-06-16 15:42:10', 15),
(47, 229, 7, '2015-06-17 15:05:15', '2015-06-17 09:05:15', 14),
(48, 230, 7, '2015-06-17 15:06:54', '2015-06-17 09:06:54', 14),
(49, 231, 7, '2015-06-17 17:03:20', '2015-06-17 11:03:20', 14),
(50, 232, 7, '2015-06-17 17:05:42', '2015-06-17 11:05:42', 14),
(51, 237, 14, '2015-06-17 19:33:42', '2015-06-17 13:33:42', 14),
(52, 239, 7, '2015-06-18 17:37:23', '2015-06-18 11:37:23', 15),
(53, 240, 8, '2015-06-18 17:39:23', '2015-06-18 11:39:23', 15),
(54, 242, 9, '2015-06-18 19:56:08', '2015-06-18 13:56:08', 15),
(55, 255, 4, '2015-06-24 15:15:28', '2015-06-24 09:15:28', 15),
(56, 276, 0, '2015-07-19 13:12:42', '2015-07-19 07:12:42', 14),
(57, 305, 0, '2015-07-20 13:50:26', '2015-07-20 07:50:26', 14),
(58, 306, 0, '2015-07-20 14:54:14', '2015-07-20 08:54:14', 14),
(59, 332, 0, '2015-07-21 08:24:31', '2015-07-21 02:24:31', 14),
(60, 333, 0, '2015-07-21 08:26:37', '2015-07-21 02:26:37', 14),
(61, 334, 0, '2015-07-21 08:27:45', '2015-07-21 02:27:45', 14),
(62, 335, 0, '2015-07-21 08:28:59', '2015-07-21 02:28:59', 14),
(63, 336, 0, '2015-07-21 08:30:06', '2015-07-21 02:30:06', 14),
(64, 361, 0, '2015-07-23 14:48:50', '2015-07-23 08:48:50', 14),
(65, 362, 0, '2015-07-23 15:14:43', '2015-07-23 09:14:43', 14),
(66, 389, 2, '2015-07-24 16:02:07', '2015-07-24 10:02:07', 14),
(67, 400, 2, '2015-07-25 15:12:51', '2015-07-25 09:12:51', 14),
(68, 401, 7, '2015-07-25 15:14:16', '2015-07-25 09:14:16', 14),
(69, 402, 8, '2015-07-25 15:15:04', '2015-07-25 09:15:04', 14),
(70, 411, 0, '2015-07-27 22:03:06', '2015-07-27 16:03:06', 14),
(71, 873, 10, '2015-08-20 08:08:49', '2015-08-20 02:08:49', 14),
(72, 1148, 0, '2015-09-05 16:25:54', '2015-09-05 10:25:54', 14),
(73, 1149, 0, '2015-09-05 18:17:57', '2015-09-05 12:17:57', 14),
(74, 1150, 0, '2015-09-05 18:18:33', '2015-09-05 12:18:33', 14),
(75, 1151, 0, '2015-09-05 18:19:11', '2015-09-05 12:19:11', 14),
(76, 1152, 0, '2015-09-05 18:19:48', '2015-09-05 12:19:48', 14),
(77, 1153, 0, '2015-09-05 18:20:23', '2015-09-05 12:20:23', 14),
(78, 1154, 0, '2015-09-05 18:48:56', '2015-09-05 12:48:56', 14),
(79, 1155, 0, '2015-09-05 19:31:05', '2015-09-05 13:31:05', 14),
(80, 1156, 0, '2015-09-05 19:31:46', '2015-09-05 13:31:46', 14),
(81, 1157, 0, '2015-09-05 19:52:26', '2015-09-05 13:52:26', 14),
(82, 1158, 0, '2015-09-05 20:01:21', '2015-09-05 14:01:21', 14),
(83, 1159, 0, '2015-09-05 20:40:51', '2015-09-05 14:40:51', 14),
(84, 1160, 0, '2015-09-05 21:10:05', '2015-09-05 15:10:05', 14),
(85, 1161, 0, '2015-09-05 21:18:31', '2015-09-05 15:18:31', 14),
(86, 1162, 0, '2015-09-05 22:14:12', '2015-09-05 16:14:12', 14),
(87, 1163, 0, '2015-09-05 22:24:29', '2015-09-05 16:24:29', 14),
(88, 1164, 0, '2015-09-05 22:34:03', '2015-09-05 16:34:03', 14),
(89, 1165, 0, '2015-09-05 22:39:18', '2015-09-05 16:39:18', 14),
(90, 1166, 0, '2015-09-05 22:42:50', '2015-09-05 16:42:50', 14),
(91, 1167, 0, '2015-09-05 22:44:03', '2015-09-05 16:44:03', 14),
(92, 1168, 0, '2015-09-05 23:03:15', '2015-09-05 17:03:15', 14),
(93, 1169, 0, '2015-09-05 23:05:11', '2015-09-05 17:05:11', 14),
(94, 1363, 8, '2015-09-16 14:33:23', '2015-09-16 08:33:23', 14),
(95, 1364, 0, '2015-09-16 14:37:23', '2015-09-16 08:37:23', 14),
(96, 1370, 2, '2015-09-16 17:20:54', '2015-09-16 11:20:54', 17),
(97, 1371, 2, '2015-09-16 19:01:18', '2015-09-16 13:01:18', 17),
(98, 1372, 2, '2015-09-16 19:34:02', '2015-09-16 13:34:02', 17),
(99, 1376, 0, '2015-09-16 21:26:19', '2015-09-16 15:26:19', 17),
(100, 1377, 0, '2015-09-16 21:27:30', '2015-09-16 15:27:30', 17),
(101, 1378, 0, '2015-09-16 21:32:02', '2015-09-16 15:32:02', 17),
(102, 1408, 8, '2015-09-17 15:19:44', '2015-09-17 09:19:44', 14),
(103, 1409, 8, '2015-09-17 15:20:47', '2015-09-17 09:20:47', 14),
(104, 1410, 8, '2015-09-17 15:30:49', '2015-09-17 09:30:49', 14),
(105, 1411, 8, '2015-09-17 15:37:00', '2015-09-17 09:37:00', 14),
(106, 1412, 9, '2015-09-17 15:46:52', '2015-09-17 09:46:52', 14),
(107, 1413, 9, '2015-09-17 15:49:10', '2015-09-17 09:49:10', 14),
(108, 1414, 9, '2015-09-17 16:37:08', '2015-09-17 10:37:08', 14),
(109, 1415, 9, '2015-09-17 16:38:44', '2015-09-17 10:38:44', 14),
(110, 1565, 0, '2015-09-22 18:24:02', '2015-09-22 12:24:02', 17),
(111, 1566, 0, '2015-09-22 18:26:17', '2015-09-22 12:26:17', 17),
(112, 1567, 8, '2015-09-22 18:28:04', '2015-09-22 12:28:04', 17),
(113, 1569, 8, '2015-09-22 19:18:48', '2015-09-22 13:18:48', 17),
(114, 1570, 8, '2015-09-22 19:20:30', '2015-09-22 13:20:30', 17),
(115, 1571, 8, '2015-09-22 19:21:54', '2015-09-22 13:21:54', 17),
(116, 1576, 5, '2015-09-22 20:23:23', '2015-09-22 14:23:23', 17),
(117, 1577, 15, '2015-09-22 20:26:25', '2015-09-22 14:26:25', 17),
(118, 1578, 16, '2015-09-22 20:27:40', '2015-09-22 14:27:40', 17),
(119, 1579, 17, '2015-09-22 20:32:56', '2015-09-22 14:32:56', 17),
(120, 1616, 13, '2015-09-26 14:58:55', '2015-09-26 08:58:55', 17),
(121, 1705, 19, '2015-09-30 19:24:32', '2015-09-30 13:24:32', 15),
(122, 1706, 19, '2015-09-30 19:44:38', '2015-09-30 13:44:38', 15),
(123, 1707, 19, '2015-09-30 20:11:43', '2015-09-30 14:11:43', 15),
(124, 1708, 19, '2015-09-30 20:12:17', '2015-09-30 14:12:17', 15),
(125, 1709, 19, '2015-09-30 20:13:12', '2015-09-30 14:13:12', 15),
(126, 1766, 8, '2015-10-04 18:27:32', '2015-10-04 12:27:32', 17),
(127, 1769, 12, '2015-10-04 21:02:59', '2015-10-04 15:02:59', 17),
(128, 1800, 10, '2015-10-07 18:47:59', '2015-10-07 12:47:59', 15),
(129, 1801, 8, '2015-10-07 18:49:24', '2015-10-07 12:49:24', 15),
(130, 1803, 29, '2015-10-07 18:57:25', '2015-10-07 12:57:25', 15),
(131, 1809, 0, '2015-10-07 21:27:24', '2015-10-07 15:27:24', 17),
(132, 1810, 0, '2015-10-07 21:34:50', '2015-10-07 15:34:50', 17),
(133, 1811, 26, '2015-10-07 21:35:44', '2015-10-07 15:35:44', 17),
(134, 1812, 17, '2015-10-07 21:46:44', '2015-10-07 15:46:44', 17),
(135, 1823, 32, '2015-10-08 17:07:46', '2015-10-08 11:07:46', 17),
(136, 1825, 2, '2015-10-08 17:16:19', '2015-10-08 11:16:19', 17),
(137, 1826, 33, '2015-10-08 17:21:44', '2015-10-08 11:21:44', 17),
(138, 1827, 33, '2015-10-08 17:25:55', '2015-10-08 11:25:55', 17),
(139, 1832, 5, '2015-10-08 22:15:34', '2015-10-08 16:15:34', 17),
(140, 1841, 32, '2015-10-09 18:53:02', '2015-10-09 12:53:02', 15),
(141, 1847, 8, '2015-10-10 19:57:27', '2015-10-10 13:57:27', 17),
(142, 1850, 16, '2015-10-10 20:07:47', '2015-10-10 14:07:47', 17),
(143, 1851, 16, '2015-10-10 20:09:28', '2015-10-10 14:09:28', 17),
(144, 1852, 17, '2015-10-10 20:11:01', '2015-10-10 14:11:01', 17),
(145, 1856, 0, '2015-10-10 22:09:02', '2015-10-10 16:09:02', 15),
(146, 1857, 17, '2015-10-10 22:10:19', '2015-10-10 16:10:19', 15),
(147, 1859, 23, '2015-10-11 09:35:51', '2015-10-11 03:35:51', 15),
(148, 1860, 13, '2015-10-11 09:37:21', '2015-10-11 03:37:21', 15),
(149, 1865, 0, '2015-10-11 21:44:34', '2015-10-11 15:44:34', 17),
(150, 1866, 0, '2015-10-11 21:53:10', '2015-10-11 15:53:10', 17),
(151, 1867, 0, '2015-10-11 22:04:42', '2015-10-11 16:04:42', 17),
(152, 1868, 0, '2015-10-11 22:11:31', '2015-10-11 16:11:31', 17),
(153, 1869, 0, '2015-10-11 22:25:05', '2015-10-11 16:25:05', 17),
(154, 1882, 8, '2015-10-12 14:48:12', '2015-10-12 08:48:12', 17),
(155, 1885, 8, '2015-10-12 15:19:58', '2015-10-12 09:19:58', 17),
(156, 1889, 2, '2015-10-12 17:08:49', '2015-10-12 11:08:49', 17),
(157, 1892, 8, '2015-10-12 19:33:25', '2015-10-12 13:33:25', 17),
(158, 1896, 31, '2015-10-12 21:28:06', '2015-10-12 15:28:06', 15),
(159, 1897, 23, '2015-10-12 21:29:21', '2015-10-12 15:29:21', 15),
(160, 1898, 34, '2015-10-12 21:32:19', '2015-10-12 15:32:19', 15),
(161, 1903, 16, '2015-10-12 22:37:31', '2015-10-12 16:37:31', 15),
(162, 1908, 8, '2015-10-13 11:54:24', '2015-10-13 05:54:24', 15),
(163, 1911, 8, '2015-10-13 14:35:14', '2015-10-13 08:35:14', 15),
(164, 1927, 27, '2015-10-13 22:15:49', '2015-10-13 16:15:49', 17),
(165, 1934, 8, '2015-10-14 11:44:12', '2015-10-14 05:44:12', 17),
(166, 1935, 8, '2015-10-14 11:51:16', '2015-10-14 05:51:16', 17),
(167, 1941, 8, '2015-10-14 15:09:11', '2015-10-14 09:09:11', 17),
(168, 1943, 8, '2015-10-14 15:21:13', '2015-10-14 09:21:13', 15),
(169, 1944, 23, '2015-10-14 15:56:05', '2015-10-14 09:56:05', 15),
(170, 1946, 34, '2015-10-14 19:49:14', '2015-10-14 13:49:14', 15),
(171, 1947, 2, '2015-10-14 19:51:27', '2015-10-14 13:51:27', 15),
(172, 1950, 24, '2015-10-14 22:02:40', '2015-10-14 16:02:40', 15),
(173, 1955, 0, '2015-10-15 07:38:17', '2015-10-15 01:38:17', 17),
(174, 1960, 23, '2015-10-15 13:11:00', '2015-10-15 07:11:00', 17),
(175, 1961, 23, '2015-10-15 14:01:21', '2015-10-15 08:01:21', 17),
(176, 1964, 8, '2015-10-15 15:36:20', '2015-10-15 09:36:20', 15),
(177, 1971, 17, '2015-10-15 19:59:11', '2015-10-15 13:59:11', 15),
(178, 1979, 31, '2015-10-15 21:02:10', '2015-10-15 15:02:10', 15),
(179, 1983, 16, '2015-10-15 22:00:29', '2015-10-15 16:00:29', 15),
(180, 1990, 32, '2015-10-15 23:26:08', '2015-10-15 17:26:08', 15),
(181, 1997, 31, '2015-10-16 08:54:22', '2015-10-16 02:54:22', 17),
(182, 1998, 31, '2015-10-16 08:55:40', '2015-10-16 02:55:40', 17),
(183, 1999, 0, '2015-10-16 08:57:55', '2015-10-16 02:57:55', 17),
(184, 2003, 34, '2015-10-16 10:00:15', '2015-10-16 04:00:15', 17),
(185, 2016, 5, '2015-10-16 18:08:53', '2015-10-16 12:08:53', 17),
(186, 2024, 29, '2015-10-16 19:53:39', '2015-10-16 13:53:39', 17),
(187, 2028, 35, '2015-10-16 20:52:04', '2015-10-16 14:52:04', 15),
(188, 2045, 5, '2015-10-17 14:45:28', '2015-10-17 08:45:28', 15),
(189, 2046, 8, '2015-10-17 14:46:45', '2015-10-17 08:46:45', 15),
(190, 2047, 13, '2015-10-17 14:48:11', '2015-10-17 08:48:11', 15),
(191, 2048, 34, '2015-10-17 14:48:57', '2015-10-17 08:48:57', 15),
(192, 2049, 33, '2015-10-17 14:49:57', '2015-10-17 08:49:57', 15),
(193, 2050, 0, '2015-10-17 14:51:38', '2015-10-17 08:51:38', 15),
(194, 2051, 8, '2015-10-17 15:58:06', '2015-10-17 09:58:06', 15),
(195, 2052, 2, '2015-10-17 15:59:35', '2015-10-17 09:59:35', 15),
(196, 2058, 0, '2015-10-17 19:08:26', '2015-10-17 13:08:26', 17),
(197, 2080, 8, '2015-10-18 15:14:49', '2015-10-18 09:14:49', 17),
(198, 2081, 16, '2015-10-18 15:43:17', '2015-10-18 09:43:17', 17),
(199, 2082, 32, '2015-10-18 16:29:29', '2015-10-18 10:29:29', 17),
(200, 2083, 29, '2015-10-18 17:06:27', '2015-10-18 11:06:27', 17),
(201, 2084, 27, '2015-10-18 17:10:49', '2015-10-18 11:10:49', 17),
(202, 2086, 11, '2015-10-18 17:52:25', '2015-10-18 11:52:25', 17),
(203, 2087, 11, '2015-10-18 19:09:13', '2015-10-18 13:09:13', 17),
(204, 2096, 8, '2015-10-19 11:01:56', '2015-10-19 05:01:56', 15),
(205, 2097, 37, '2015-10-19 12:24:46', '2015-10-19 06:24:46', 15),
(206, 2099, 8, '2015-10-19 15:00:31', '2015-10-19 09:00:31', 15),
(207, 2100, 16, '2015-10-19 15:35:26', '2015-10-19 09:35:26', 15),
(208, 2101, 17, '2015-10-19 15:36:32', '2015-10-19 09:36:32', 15),
(209, 2104, 35, '2015-10-19 19:06:42', '2015-10-19 13:06:42', 15),
(210, 2114, 18, '2015-10-20 11:19:56', '2015-10-20 05:19:56', 15),
(211, 2116, 8, '2015-10-20 14:35:14', '2015-10-20 08:35:14', 15),
(212, 2126, 21, '2015-10-20 21:44:01', '2015-10-20 15:44:01', 15),
(213, 2127, 10, '2015-10-20 21:47:51', '2015-10-20 15:47:51', 15),
(214, 2131, 38, '2015-10-20 22:53:24', '2015-10-20 16:53:24', 15),
(215, 2133, 32, '2015-10-20 23:25:56', '2015-10-20 17:25:56', 15),
(216, 2134, 23, '2015-10-20 23:27:14', '2015-10-20 17:27:14', 15),
(217, 2144, 8, '2015-10-21 11:07:17', '2015-10-21 05:07:17', 17),
(218, 2148, 0, '2015-10-21 15:15:25', '2015-10-21 09:15:25', 17),
(219, 2149, 8, '2015-10-21 15:17:42', '2015-10-21 09:17:42', 17),
(220, 2154, 32, '2015-10-21 18:22:49', '2015-10-21 12:22:49', 17),
(221, 2160, 5, '2015-10-21 20:07:04', '2015-10-21 14:07:04', 17),
(222, 2161, 5, '2015-10-21 20:11:27', '2015-10-21 14:11:27', 17),
(223, 2163, 34, '2015-10-21 20:28:19', '2015-10-21 14:28:19', 17),
(224, 2164, 34, '2015-10-21 20:30:11', '2015-10-21 14:30:11', 17),
(225, 2165, 34, '2015-10-21 20:30:11', '2015-10-21 14:30:11', 17),
(226, 2166, 2, '2015-10-21 20:32:48', '2015-10-21 14:32:48', 17),
(227, 2168, 31, '2015-10-21 21:01:53', '2015-10-21 15:01:53', 17),
(228, 2190, 0, '2015-10-22 14:46:30', '2015-10-22 08:46:30', 17),
(229, 2191, 8, '2015-10-22 15:10:18', '2015-10-22 09:10:18', 17),
(230, 2209, 32, '2015-10-22 18:21:47', '2015-10-22 12:21:47', 17),
(231, 2214, 2, '2015-10-22 19:09:50', '2015-10-22 13:09:50', 17),
(232, 2215, 0, '2015-10-22 19:17:31', '2015-10-22 13:17:31', 17),
(233, 2332, 0, '2015-10-23 23:30:32', '2015-10-23 17:30:32', 17),
(234, 2365, 8, '2015-10-24 14:53:59', '2015-10-24 08:53:59', 17),
(235, 2367, 29, '2015-10-24 16:38:12', '2015-10-24 10:38:12', 17),
(236, 2373, 32, '2015-10-24 19:54:02', '2015-10-24 13:54:02', 17),
(237, 2374, 20, '2015-10-24 20:01:05', '2015-10-24 14:01:05', 17),
(238, 2375, 26, '2015-10-24 20:03:31', '2015-10-24 14:03:31', 17),
(239, 2384, 16, '2015-10-24 22:28:03', '2015-10-24 16:28:03', 17),
(240, 2391, 13, '2015-10-25 07:55:09', '2015-10-25 01:55:09', 17),
(241, 2392, 20, '2015-10-25 07:56:01', '2015-10-25 01:56:01', 17),
(242, 2397, 26, '2015-10-25 09:43:22', '2015-10-25 03:43:22', 17),
(243, 2411, 5, '2015-10-25 20:08:56', '2015-10-25 14:08:56', 17),
(244, 2412, 0, '2015-10-25 20:16:51', '2015-10-25 14:16:51', 17),
(245, 2413, 32, '2015-10-25 20:18:17', '2015-10-25 14:18:17', 17),
(246, 2414, 15, '2015-10-25 20:21:40', '2015-10-25 14:21:40', 17),
(247, 2416, 0, '2015-10-25 20:28:28', '2015-10-25 14:28:28', 17),
(248, 2417, 18, '2015-10-25 20:28:58', '2015-10-25 14:28:58', 17),
(249, 2418, 17, '2015-10-25 21:06:24', '2015-10-25 15:06:24', 17),
(250, 2422, 16, '2015-10-25 22:56:06', '2015-10-25 16:56:06', 17),
(251, 2431, 8, '2015-10-26 15:05:50', '2015-10-26 09:05:50', 17),
(252, 2432, 23, '2015-10-26 15:08:13', '2015-10-26 09:08:13', 17),
(253, 2442, 17, '2015-10-26 20:48:37', '2015-10-26 14:48:37', 17),
(254, 2443, 23, '2015-10-26 20:51:26', '2015-10-26 14:51:26', 17),
(255, 2446, 21, '2015-10-27 07:57:14', '2015-10-27 01:57:14', 15),
(256, 2447, 32, '2015-10-27 07:59:31', '2015-10-27 01:59:31', 15),
(257, 2453, 37, '2015-10-27 15:23:30', '2015-10-27 09:23:30', 17),
(258, 2455, 8, '2015-10-27 15:40:47', '2015-10-27 09:40:47', 17),
(259, 2459, 8, '2015-10-27 19:02:46', '2015-10-27 13:02:46', 17),
(260, 2460, 2, '2015-10-27 19:06:24', '2015-10-27 13:06:24', 17),
(261, 2464, 34, '2015-10-27 20:51:46', '2015-10-27 14:51:46', 17),
(262, 2465, 21, '2015-10-27 22:02:55', '2015-10-27 16:02:55', 17),
(263, 2471, 23, '2015-10-28 07:58:03', '2015-10-28 01:58:03', 15),
(264, 2470, 23, '2015-10-28 07:58:03', '2015-10-28 01:58:03', 15),
(265, 2472, 23, '2015-10-28 07:59:50', '2015-10-28 01:59:50', 15),
(266, 2476, 8, '2015-10-28 10:59:05', '2015-10-28 04:59:05', 15),
(267, 2480, 0, '2015-10-28 13:02:39', '2015-10-28 07:02:39', 15),
(268, 2482, 34, '2015-10-28 14:18:58', '2015-10-28 08:18:58', 15),
(269, 2483, 8, '2015-10-28 14:27:52', '2015-10-28 08:27:52', 15),
(270, 2484, 16, '2015-10-28 15:23:36', '2015-10-28 09:23:36', 15),
(271, 2491, 26, '2015-10-28 20:07:03', '2015-10-28 14:07:03', 15),
(272, 2492, 32, '2015-10-28 20:42:51', '2015-10-28 14:42:51', 15),
(273, 2493, 31, '2015-10-28 20:59:39', '2015-10-28 14:59:39', 15),
(274, 2510, 8, '2015-10-29 14:31:58', '2015-10-29 08:31:58', 17),
(275, 2525, 32, '2015-10-29 20:43:32', '2015-10-29 14:43:32', 17),
(276, 2530, 16, '2015-10-29 22:36:20', '2015-10-29 16:36:20', 17),
(277, 2533, 27, '2015-10-30 08:59:44', '2015-10-30 02:59:44', 17),
(278, 2534, 20, '2015-10-30 09:04:16', '2015-10-30 03:04:16', 17),
(279, 2545, 10, '2015-10-30 12:36:32', '2015-10-30 06:36:32', 17),
(280, 2546, 23, '2015-10-30 12:38:32', '2015-10-30 06:38:32', 17),
(281, 2550, 32, '2015-10-30 15:54:34', '2015-10-30 09:54:34', 17),
(282, 2553, 16, '2015-10-30 16:53:38', '2015-10-30 10:53:38', 17),
(283, 2556, 0, '2015-10-30 18:45:42', '2015-10-30 12:45:42', 17),
(284, 2559, 0, '2015-10-30 20:55:49', '2015-10-30 14:55:49', 17),
(285, 2564, 24, '2015-10-30 21:24:12', '2015-10-30 15:24:12', 17),
(286, 2572, 21, '2015-10-31 08:32:00', '2015-10-31 02:32:00', 17),
(287, 2579, 16, '2015-10-31 11:18:21', '2015-10-31 05:18:21', 17),
(288, 2582, 0, '2015-10-31 12:46:16', '2015-10-31 06:46:16', 17),
(289, 2583, 8, '2015-10-31 12:59:28', '2015-10-31 06:59:28', 17),
(290, 2586, 8, '2015-10-31 15:02:47', '2015-10-31 09:02:47', 17),
(291, 2590, 23, '2015-10-31 18:01:29', '2015-10-31 12:01:29', 17),
(292, 2598, 15, '2015-10-31 20:15:50', '2015-10-31 14:15:50', 17),
(293, 2599, 17, '2015-10-31 20:21:10', '2015-10-31 14:21:10', 17),
(294, 2602, 27, '2015-10-31 22:01:47', '2015-10-31 16:01:47', 17),
(295, 2605, 23, '2015-10-31 22:30:00', '2015-10-31 16:30:00', 17),
(296, 2608, 23, '2015-11-01 08:22:16', '2015-11-01 02:22:16', 17),
(297, 2609, 23, '2015-11-01 08:56:59', '2015-11-01 02:56:59', 17),
(298, 2614, 34, '2015-11-01 10:18:14', '2015-11-01 04:18:14', 17),
(299, 2615, 32, '2015-11-01 10:47:56', '2015-11-01 04:47:56', 17),
(300, 2623, 8, '2015-11-01 15:03:03', '2015-11-01 09:03:03', 17),
(301, 2627, 0, '2015-11-01 19:27:51', '2015-11-01 13:27:51', 17),
(302, 2628, 29, '2015-11-01 19:29:04', '2015-11-01 13:29:04', 17),
(303, 2629, 31, '2015-11-01 20:16:36', '2015-11-01 14:16:36', 17),
(304, 2630, 0, '2015-11-01 20:48:51', '2015-11-01 14:48:51', 17),
(305, 2634, 32, '2015-11-01 21:50:42', '2015-11-01 15:50:42', 17),
(306, 2636, 27, '2015-11-01 22:20:00', '2015-11-01 16:20:00', 17),
(307, 2642, 0, '2015-11-02 10:58:47', '2015-11-02 04:58:47', 17),
(308, 2644, 32, '2015-11-02 12:07:58', '2015-11-02 06:07:58', 17),
(309, 2645, 23, '2015-11-02 12:33:56', '2015-11-02 06:33:56', 17),
(310, 2647, 33, '2015-11-02 14:06:46', '2015-11-02 08:06:46', 17),
(311, 2649, 8, '2015-11-02 15:37:14', '2015-11-02 09:37:14', 17),
(312, 2650, 2, '2015-11-02 15:45:41', '2015-11-02 09:45:41', 17),
(313, 2654, 29, '2015-11-02 20:09:04', '2015-11-02 14:09:04', 17),
(314, 2655, 27, '2015-11-03 08:24:39', '2015-11-03 02:24:39', 17),
(315, 2656, 27, '2015-11-03 08:28:19', '2015-11-03 02:28:19', 17),
(316, 2657, 0, '2015-11-03 08:35:08', '2015-11-03 02:35:08', 17),
(317, 2658, 17, '2015-11-03 08:36:39', '2015-11-03 02:36:39', 17),
(318, 2659, 13, '2015-11-03 08:37:28', '2015-11-03 02:37:28', 17),
(319, 2660, 29, '2015-11-03 08:38:21', '2015-11-03 02:38:21', 17),
(320, 2661, 8, '2015-11-03 12:07:52', '2015-11-03 06:07:52', 17),
(321, 2663, 35, '2015-11-03 13:14:10', '2015-11-03 07:14:10', 17),
(322, 2666, 8, '2015-11-03 15:08:02', '2015-11-03 09:08:02', 17),
(323, 2669, 29, '2015-11-03 18:22:29', '2015-11-03 12:22:29', 17),
(324, 2671, 6, '2015-11-03 21:58:20', '2015-11-03 15:58:20', 17),
(325, 2672, 21, '2015-11-03 22:09:50', '2015-11-03 16:09:50', 17),
(326, 2673, 32, '2015-11-03 22:20:42', '2015-11-03 16:20:42', 17),
(327, 2674, 29, '2015-11-04 07:35:43', '2015-11-04 01:35:43', 17),
(328, 2675, 17, '2015-11-04 07:37:00', '2015-11-04 01:37:00', 17),
(329, 2676, 38, '2015-11-04 07:56:28', '2015-11-04 01:56:28', 17),
(330, 2678, 8, '2015-11-04 13:21:26', '2015-11-04 07:21:26', 17),
(331, 2680, 2, '2015-11-04 16:57:41', '2015-11-04 10:57:41', 17),
(332, 2681, 8, '2015-11-04 16:58:45', '2015-11-04 10:58:45', 17),
(333, 2690, 8, '2015-11-05 11:22:00', '2015-11-05 05:22:00', 17),
(334, 2691, 17, '2015-11-05 13:05:14', '2015-11-05 07:05:14', 17),
(335, 2693, 0, '2015-11-05 16:44:05', '2015-11-05 10:44:05', 15),
(336, 2695, 33, '2015-11-05 20:28:24', '2015-11-05 14:28:24', 17),
(337, 2705, 32, '2015-11-06 08:33:05', '2015-11-06 02:33:05', 15),
(338, 2706, 32, '2015-11-06 09:05:42', '2015-11-06 03:05:42', 15),
(339, 2713, 15, '2015-11-06 20:36:24', '2015-11-06 14:36:24', 17),
(340, 2714, 6, '2015-11-06 20:38:04', '2015-11-06 14:38:04', 17),
(341, 2721, 6, '2015-11-07 10:39:56', '2015-11-07 04:39:56', 15),
(342, 2723, 31, '2015-11-07 13:57:48', '2015-11-07 07:57:48', 15),
(343, 2724, 8, '2015-11-07 14:59:35', '2015-11-07 08:59:35', 15),
(344, 2727, 32, '2015-11-07 19:18:27', '2015-11-07 13:18:27', 17),
(345, 2729, 2, '2015-11-07 20:25:09', '2015-11-07 14:25:09', 17),
(346, 2730, 21, '2015-11-07 21:34:42', '2015-11-07 15:34:42', 17),
(347, 2738, 8, '2015-11-08 14:26:45', '2015-11-08 08:26:45', 15),
(348, 2739, 35, '2015-11-08 15:57:06', '2015-11-08 09:57:06', 15),
(349, 2740, 35, '2015-11-08 15:57:06', '2015-11-08 09:57:06', 15),
(350, 2747, 22, '2015-11-08 19:35:49', '2015-11-08 13:35:49', 15),
(351, 2748, 13, '2015-11-08 19:36:31', '2015-11-08 13:36:31', 15),
(352, 2751, 3, '2015-11-08 21:31:07', '2015-11-08 15:31:07', 15),
(353, 2755, 29, '2015-11-09 09:44:46', '2015-11-09 03:44:46', 17),
(354, 2760, 2, '2015-11-09 14:10:06', '2015-11-09 08:10:06', 17),
(355, 2762, 8, '2015-11-09 16:38:04', '2015-11-09 10:38:04', 17),
(356, 2770, 17, '2015-11-10 08:01:01', '2015-11-10 02:01:01', 15),
(357, 2771, 29, '2015-11-10 08:01:54', '2015-11-10 02:01:54', 15),
(358, 2774, 8, '2015-11-10 14:37:42', '2015-11-10 08:37:42', 15),
(359, 2783, 10, '2015-11-10 20:48:43', '2015-11-10 14:48:43', 15),
(360, 2786, 35, '2015-11-10 22:25:43', '2015-11-10 16:25:43', 15),
(361, 2791, 15, '2015-11-11 10:39:49', '2015-11-11 04:39:49', 17),
(362, 2795, 16, '2015-11-11 13:15:06', '2015-11-11 07:15:06', 17),
(363, 2797, 8, '2015-11-11 14:59:31', '2015-11-11 08:59:31', 15),
(364, 2810, 34, '2015-11-12 08:34:25', '2015-11-12 02:34:25', 17),
(365, 2817, 35, '2015-11-12 12:13:33', '2015-11-12 06:13:33', 17),
(366, 2823, 8, '2015-11-12 15:55:36', '2015-11-12 09:55:36', 17),
(367, 2830, 32, '2015-11-13 07:01:27', '2015-11-13 01:01:27', 15),
(368, 2843, 11, '2015-11-13 13:38:28', '2015-11-13 07:38:28', 15),
(369, 2862, 32, '2015-11-13 21:12:09', '2015-11-13 15:12:09', 15),
(370, 2910, 27, '2015-11-14 17:34:21', '2015-11-14 11:34:21', 17),
(371, 2914, 21, '2015-11-14 18:18:00', '2015-11-14 12:18:00', 17),
(372, 2920, 31, '2015-11-14 20:38:34', '2015-11-14 14:38:34', 17),
(373, 2926, 8, '2015-11-14 22:08:16', '2015-11-14 16:08:16', 17),
(374, 2927, 33, '2015-11-14 22:19:16', '2015-11-14 16:19:16', 17),
(375, 2941, 8, '2015-11-15 11:51:17', '2015-11-15 05:51:17', 17),
(376, 2944, 11, '2015-11-15 15:17:55', '2015-11-15 09:17:55', 17),
(377, 2946, 8, '2015-11-15 15:32:49', '2015-11-15 09:32:49', 17),
(378, 2953, 32, '2015-11-16 08:46:12', '2015-11-16 02:46:12', 17),
(379, 2957, 8, '2015-11-16 14:38:49', '2015-11-16 08:38:49', 17),
(380, 2963, 8, '2015-11-16 20:09:19', '2015-11-16 14:09:19', 17),
(381, 2964, 36, '2015-11-16 20:11:16', '2015-11-16 14:11:36', 17),
(382, 2969, 31, '2015-11-16 21:46:27', '2015-11-16 15:46:27', 17),
(383, 2977, 32, '2015-11-17 11:17:33', '2015-11-17 05:17:33', 17),
(384, 2978, 6, '2015-11-17 12:06:33', '2015-11-17 06:06:33', 17),
(385, 2979, 8, '2015-11-17 14:38:23', '2015-11-17 08:38:23', 15),
(386, 2980, 39, '2015-11-17 14:40:45', '2015-11-17 08:40:45', 15),
(387, 2997, 32, '2015-11-18 10:30:16', '2015-11-18 04:30:16', 17),
(388, 3003, 38, '2015-11-18 12:14:40', '2015-11-18 06:14:40', 17),
(389, 3005, 8, '2015-11-18 14:27:41', '2015-11-18 08:27:41', 15),
(390, 3006, 23, '2015-11-18 17:25:05', '2015-11-18 11:25:05', 15),
(391, 3010, 32, '2015-11-19 09:00:03', '2015-11-19 03:00:03', 15),
(392, 3015, 2, '2015-11-19 15:09:00', '2015-11-19 09:09:00', 15),
(393, 3016, 2, '2015-11-19 15:09:00', '2015-11-19 09:09:00', 15),
(394, 3021, 23, '2015-11-19 22:14:22', '2015-11-19 16:14:22', 15),
(395, 3020, 23, '2015-11-19 22:14:22', '2015-11-19 16:14:22', 15),
(396, 3022, 6, '2015-11-19 22:15:08', '2015-11-19 16:15:08', 15),
(397, 3032, 16, '2015-11-20 16:12:52', '2015-11-20 10:12:52', 17),
(398, 3045, 32, '2015-11-21 12:01:03', '2015-11-21 06:01:03', 17),
(399, 3046, 32, '2015-11-21 13:15:05', '2015-11-21 07:15:05', 17),
(400, 3051, 0, '2015-11-21 14:52:49', '2015-11-21 08:52:49', 17),
(401, 3052, 0, '2015-11-21 14:53:25', '2015-11-21 08:53:25', 17),
(402, 3053, 8, '2015-11-21 14:54:01', '2015-11-21 08:54:01', 17),
(403, 3054, 2, '2015-11-21 15:51:32', '2015-11-21 09:51:32', 17),
(404, 3055, 5, '2015-11-21 15:52:45', '2015-11-21 09:52:45', 17),
(405, 3067, 37, '2015-11-22 07:53:33', '2015-11-22 01:53:33', 17),
(406, 3074, 8, '2015-11-22 14:59:49', '2015-11-22 08:59:49', 17),
(407, 3075, 4, '2015-11-22 16:45:50', '2015-11-22 10:45:50', 17),
(408, 3079, 16, '2015-11-22 18:24:45', '2015-11-22 12:24:45', 17),
(409, 3081, 23, '2015-11-22 22:19:34', '2015-11-22 16:19:34', 17),
(410, 3092, 34, '2015-11-23 17:24:28', '2015-11-23 11:24:28', 17),
(411, 3094, 20, '2015-11-23 17:54:33', '2015-11-23 11:54:33', 17),
(412, 3095, 4, '2015-11-23 18:03:44', '2015-11-23 12:03:44', 17),
(413, 3097, 34, '2015-11-23 18:53:04', '2015-11-23 12:53:04', 15),
(414, 3100, 23, '2015-11-23 21:25:42', '2015-11-23 15:25:42', 19),
(415, 3105, 23, '2015-11-24 07:20:53', '2015-11-24 01:20:53', 15),
(416, 3111, 0, '2015-11-24 14:10:02', '2015-11-24 08:10:02', 15),
(417, 3112, 8, '2015-11-24 14:10:30', '2015-11-24 08:10:30', 15),
(418, 3116, 23, '2015-11-24 17:41:23', '2015-11-24 11:41:23', 17),
(419, 3117, 2, '2015-11-24 18:14:50', '2015-11-24 12:14:50', 17),
(420, 3118, 15, '2015-11-24 20:13:20', '2015-11-24 14:13:20', 17),
(421, 3119, 31, '2015-11-24 20:40:33', '2015-11-24 14:40:33', 17),
(422, 3120, 31, '2015-11-24 20:44:28', '2015-11-24 14:44:28', 17),
(423, 3125, 32, '2015-11-25 09:46:11', '2015-11-25 03:46:11', 15),
(424, 3129, 8, '2015-11-25 15:45:55', '2015-11-25 09:45:55', 15),
(425, 3130, 33, '2015-11-25 17:43:58', '2015-11-25 11:43:58', 15),
(426, 3131, 2, '2015-11-25 18:06:50', '2015-11-25 12:06:50', 15),
(427, 3149, 5, '2015-11-26 10:27:01', '2015-11-26 04:27:01', 15),
(428, 3151, 38, '2015-11-26 11:06:16', '2015-11-26 05:06:16', 15),
(429, 3152, 4, '2015-11-26 12:29:54', '2015-11-26 06:29:54', 15),
(430, 3158, 8, '2015-11-26 15:31:14', '2015-11-26 09:31:14', 15),
(431, 3166, 35, '2015-11-26 19:49:51', '2015-11-26 13:49:51', 15),
(432, 3167, 5, '2015-11-26 19:55:42', '2015-11-26 13:55:42', 15),
(433, 3180, 0, '2015-11-27 16:53:10', '2015-11-27 10:53:10', 17),
(434, 3184, 26, '2015-11-27 18:52:03', '2015-11-27 12:52:03', 17),
(435, 3188, 0, '2015-11-27 20:23:32', '2015-11-27 14:23:32', 17),
(436, 3189, 35, '2015-11-27 20:24:31', '2015-11-27 14:24:31', 17),
(437, 3190, 24, '2015-11-27 20:25:17', '2015-11-27 14:25:17', 17),
(438, 3191, 32, '2015-11-27 20:26:09', '2015-11-27 14:26:09', 17),
(439, 3192, 21, '2015-11-27 20:27:22', '2015-11-27 14:27:22', 17),
(440, 3193, 2, '2015-11-27 20:28:15', '2015-11-27 14:28:15', 17),
(441, 3201, 23, '2015-11-28 07:55:10', '2015-11-28 01:55:10', 17),
(442, 3208, 33, '2015-11-28 13:04:17', '2015-11-28 07:04:17', 17),
(443, 3211, 8, '2015-11-28 14:47:31', '2015-11-28 08:47:31', 17),
(444, 3216, 35, '2015-11-28 18:25:34', '2015-11-28 12:25:34', 17),
(445, 3219, 0, '2015-11-28 21:19:45', '2015-11-28 15:19:45', 17),
(446, 3223, 13, '2015-11-29 10:42:08', '2015-11-29 04:42:08', 19),
(447, 3224, 21, '2015-11-29 10:43:12', '2015-11-29 04:43:12', 19),
(448, 3226, 32, '2015-11-29 11:26:52', '2015-11-29 05:26:52', 19),
(449, 3228, 8, '2015-11-29 13:43:41', '2015-11-29 07:43:41', 19),
(450, 3233, 23, '2015-11-30 08:15:44', '2015-11-30 02:15:44', 19),
(451, 3234, 8, '2015-11-30 13:55:25', '2015-11-30 07:55:25', 19),
(452, 3243, 10, '2015-11-30 20:54:53', '2015-11-30 14:54:53', 19),
(453, 3255, 32, '2015-12-01 12:25:26', '2015-12-01 06:25:26', 17),
(454, 3256, 33, '2015-12-01 12:45:01', '2015-12-01 06:45:01', 17),
(455, 3257, 21, '2015-12-01 12:45:34', '2015-12-01 06:45:34', 17),
(456, 3259, 8, '2015-12-01 14:26:54', '2015-12-01 08:26:54', 17),
(457, 3262, 16, '2015-12-01 17:38:05', '2015-12-01 11:38:05', 17),
(458, 3265, 3, '2015-12-01 22:30:31', '2015-12-01 16:30:31', 17),
(459, 3266, 3, '2015-12-01 22:31:29', '2015-12-01 16:31:29', 17),
(460, 3274, 8, '2015-12-02 14:21:38', '2015-12-02 08:21:38', 19),
(461, 3275, 32, '2015-12-02 14:54:55', '2015-12-02 08:54:55', 19),
(462, 3276, 32, '2015-12-02 15:53:06', '2015-12-02 09:53:06', 19),
(463, 3280, 0, '2015-12-02 20:15:49', '2015-12-02 14:15:49', 19),
(464, 3281, 21, '2015-12-02 21:06:36', '2015-12-02 15:06:36', 19),
(465, 3282, 2, '2015-12-02 21:08:41', '2015-12-02 15:08:41', 19),
(466, 3283, 32, '2015-12-02 21:09:12', '2015-12-02 15:09:12', 19),
(467, 3290, 31, '2015-12-03 07:59:50', '2015-12-03 01:59:50', 19),
(468, 3291, 31, '2015-12-03 08:08:15', '2015-12-03 02:08:15', 19),
(469, 3304, 8, '2015-12-03 15:02:24', '2015-12-03 09:02:24', 19),
(470, 3307, 16, '2015-12-03 16:43:42', '2015-12-03 10:43:42', 19),
(473, 3309, 35, '2015-12-03 18:53:32', '2015-12-03 12:53:32', 17),
(474, 3319, 33, '2015-12-03 22:33:12', '2015-12-03 16:33:12', 17),
(475, 3336, 8, '2015-12-04 16:31:34', '2015-12-04 10:31:34', 15),
(476, 3340, 21, '2015-12-04 17:58:17', '2015-12-04 11:58:17', 15),
(477, 3345, 23, '2015-12-04 20:04:19', '2015-12-04 14:04:19', 15),
(478, 3346, 10, '2015-12-04 20:05:46', '2015-12-04 14:05:46', 15),
(479, 3348, 32, '2015-12-04 20:57:28', '2015-12-04 14:57:28', 15),
(480, 3352, 35, '2015-12-04 22:40:20', '2015-12-04 16:40:20', 15),
(481, 3359, 8, '2015-12-05 14:29:56', '2015-12-05 08:29:56', 15),
(482, 3365, 8, '2015-12-05 18:47:36', '2015-12-05 12:47:36', 15),
(483, 3371, 16, '2015-12-05 20:21:09', '2015-12-05 14:21:09', 15),
(484, 3377, 36, '2015-12-05 22:21:33', '2015-12-05 16:21:33', 15),
(485, 3386, 32, '2015-12-06 10:43:30', '2015-12-06 04:43:30', 15),
(486, 3388, 33, '2015-12-06 13:48:06', '2015-12-06 07:48:06', 15),
(487, 3389, 21, '2015-12-06 14:17:39', '2015-12-06 08:17:39', 15),
(488, 3390, 8, '2015-12-06 14:51:06', '2015-12-06 08:51:06', 19),
(489, 3401, 41, '2015-12-07 07:29:59', '2015-12-07 01:29:59', 15),
(490, 3402, 41, '2015-12-07 07:29:59', '2015-12-07 01:29:59', 15),
(491, 3406, 8, '2015-12-07 13:59:32', '2015-12-07 07:59:32', 15),
(492, 3419, 8, '2015-12-08 14:39:23', '2015-12-08 08:39:23', 19),
(493, 3420, 8, '2015-12-08 14:40:32', '2015-12-08 08:40:32', 19),
(494, 3423, 39, '2015-12-08 17:32:04', '2015-12-08 11:32:04', 19),
(495, 3424, 20, '2015-12-08 19:50:49', '2015-12-08 13:50:49', 19),
(496, 3426, 39, '2015-12-09 09:21:47', '2015-12-09 03:21:47', 19),
(497, 3427, 8, '2015-12-09 14:03:56', '2015-12-09 08:03:56', 19),
(498, 3428, 5, '2015-12-09 19:01:50', '2015-12-09 13:01:50', 19),
(499, 3429, 36, '2015-12-09 21:10:50', '2015-12-09 15:10:50', 15),
(500, 3433, 8, '2015-12-10 14:21:59', '2015-12-10 08:21:59', 19),
(501, 3438, 2, '2015-12-10 17:41:57', '2015-12-10 11:41:57', 19),
(502, 3447, 5, '2015-12-10 22:29:42', '2015-12-10 16:29:42', 19),
(503, 3451, 24, '2015-12-11 09:11:06', '2015-12-11 03:11:06', 19),
(504, 3452, 10, '2015-12-11 09:19:05', '2015-12-11 03:19:05', 19),
(505, 3455, 21, '2015-12-11 17:57:23', '2015-12-11 11:57:23', 15),
(506, 3461, 33, '2015-12-11 21:05:07', '2015-12-11 15:05:07', 15),
(507, 3462, 33, '2015-12-11 21:30:03', '2015-12-11 15:30:03', 15),
(508, 3470, 35, '2015-12-12 10:37:31', '2015-12-12 04:37:31', 15),
(509, 3471, 20, '2015-12-12 11:15:32', '2015-12-12 05:15:32', 15),
(510, 3473, 8, '2015-12-12 14:26:51', '2015-12-12 08:26:51', 15),
(511, 3478, 39, '2015-12-12 15:48:06', '2015-12-12 09:48:06', 15),
(512, 3479, 32, '2015-12-12 17:10:57', '2015-12-12 11:10:57', 19),
(513, 3494, 13, '2015-12-13 08:19:52', '2015-12-13 02:19:52', 15),
(514, 3500, 10, '2015-12-13 11:01:05', '2015-12-13 05:01:05', 15),
(515, 3501, 4, '2015-12-13 12:35:33', '2015-12-13 06:35:33', 15),
(516, 3503, 8, '2015-12-13 15:10:11', '2015-12-13 09:10:11', 19),
(517, 3504, 8, '2015-12-13 15:15:14', '2015-12-13 09:15:14', 19),
(518, 3507, 5, '2015-12-13 19:26:30', '2015-12-13 13:26:30', 19),
(519, 3508, 5, '2015-12-13 19:26:30', '2015-12-13 13:26:30', 19),
(520, 3509, 34, '2015-12-13 21:20:53', '2015-12-13 15:20:53', 19),
(521, 3530, 34, '2015-12-14 11:33:52', '2015-12-14 05:33:52', 19),
(522, 3531, 32, '2015-12-14 11:38:52', '2015-12-14 05:38:52', 19),
(523, 3533, 32, '2015-12-14 13:24:25', '2015-12-14 07:24:25', 19),
(524, 3535, 8, '2015-12-14 15:01:36', '2015-12-14 09:01:36', 19),
(525, 3539, 8, '2015-12-14 16:38:55', '2015-12-14 10:38:55', 19),
(527, 3543, 5, '2015-12-14 19:27:40', '2015-12-14 13:27:40', 19),
(529, 3549, 40, '2015-12-14 22:31:31', '2015-12-14 16:31:41', 19),
(530, 3550, 40, '2015-12-15 07:49:18', '2015-12-15 01:49:18', 19),
(531, 3559, 0, '2015-12-15 09:27:21', '2015-12-15 03:27:21', 19),
(532, 3562, 39, '2015-12-15 14:05:56', '2015-12-15 08:05:56', 19),
(533, 3563, 8, '2015-12-15 14:10:24', '2015-12-15 08:10:24', 19),
(534, 3564, 8, '2015-12-15 14:25:53', '2015-12-15 08:25:53', 19),
(535, 3582, 27, '2015-12-16 07:14:35', '2015-12-16 01:14:35', 19),
(536, 3612, 8, '2015-12-16 15:22:14', '2015-12-16 09:22:14', 19),
(537, 3671, 8, '2015-12-17 14:54:28', '2015-12-17 08:54:28', 15),
(538, 3691, 13, '2015-12-17 21:26:10', '2015-12-17 15:26:10', 15),
(539, 3692, 33, '2015-12-17 21:27:10', '2015-12-17 15:27:10', 15),
(540, 3701, 41, '2015-12-17 23:32:16', '2015-12-17 17:32:16', 15),
(541, 3747, 2, '2015-12-18 20:51:06', '2015-12-18 14:51:06', 19),
(542, 3748, 33, '2015-12-18 20:52:09', '2015-12-18 14:52:09', 19),
(543, 3749, 19, '2015-12-18 21:28:18', '2015-12-18 15:28:18', 19),
(544, 3750, 31, '2015-12-18 21:29:34', '2015-12-18 15:29:34', 19),
(545, 3751, 24, '2015-12-18 21:30:45', '2015-12-18 15:30:45', 19),
(546, 3776, 8, '2015-12-19 17:02:51', '2015-12-19 11:02:51', 19),
(547, 3782, 39, '2015-12-19 20:31:59', '2015-12-19 14:31:59', 19),
(548, 3799, 2, '2015-12-20 16:48:01', '2015-12-20 10:48:01', 19),
(549, 3816, 8, '2015-12-20 23:46:45', '2015-12-20 17:46:45', 19),
(550, 3819, 19, '2015-12-21 07:30:03', '2015-12-21 01:30:03', 15),
(551, 3820, 36, '2015-12-21 07:31:05', '2015-12-21 01:31:05', 15),
(552, 3839, 36, '2015-12-21 20:27:23', '2015-12-21 14:27:23', 15),
(553, 3857, 8, '2015-12-22 14:22:00', '2015-12-22 08:22:00', 15),
(554, 3871, 0, '2015-12-22 20:09:41', '2015-12-22 14:09:41', 15),
(556, 3899, 8, '2015-12-23 14:32:21', '2015-12-23 08:32:21', 19),
(557, 3908, 26, '2015-12-23 18:34:57', '2015-12-23 12:34:57', 19),
(558, 3942, 8, '2015-12-24 14:24:24', '2015-12-24 08:24:24', 19),
(560, 3947, 2, '2015-12-24 17:06:26', '2015-12-24 11:06:26', 19),
(561, 4018, 36, '2015-12-25 21:50:49', '2015-12-25 15:50:49', 19),
(562, 4020, 33, '2015-12-25 22:20:40', '2015-12-25 16:20:40', 19),
(563, 4066, 15, '2015-12-27 08:40:04', '2015-12-27 02:40:24', 15),
(564, 4077, 8, '2015-12-27 14:04:30', '2015-12-27 08:04:30', 15),
(565, 4079, 0, '2015-12-27 15:35:06', '2015-12-27 09:35:06', 15),
(566, 4104, 2, '2015-12-28 15:50:11', '2015-12-28 09:50:11', 15),
(567, 4111, 26, '2015-12-28 20:25:47', '2015-12-28 14:25:47', 15),
(568, 4113, 35, '2015-12-28 21:40:26', '2015-12-28 15:40:26', 15),
(569, 4114, 35, '2015-12-28 21:42:29', '2015-12-28 15:42:29', 15),
(570, 4121, 35, '2015-12-29 09:49:51', '2015-12-29 03:49:51', 15),
(571, 4127, 8, '2015-12-29 14:43:47', '2015-12-29 08:43:47', 15),
(572, 4129, 2, '2015-12-29 16:37:23', '2015-12-29 10:37:23', 19),
(573, 4130, 4, '2015-12-29 16:38:40', '2015-12-29 10:38:40', 19),
(574, 4131, 31, '2015-12-29 17:31:09', '2015-12-29 11:31:09', 19),
(575, 4132, 36, '2015-12-29 17:33:01', '2015-12-29 11:33:01', 19),
(576, 4134, 13, '2015-12-29 20:52:35', '2015-12-29 14:52:35', 19),
(577, 4142, 21, '2015-12-30 12:39:17', '2015-12-30 06:39:17', 19),
(578, 4143, 10, '2015-12-30 14:04:41', '2015-12-30 08:04:41', 19),
(579, 4144, 8, '2015-12-30 14:28:27', '2015-12-30 08:28:27', 19),
(580, 4153, 15, '2016-01-04 07:36:19', '2016-01-04 01:36:19', 15),
(581, 4159, 32, '2016-01-04 10:22:13', '2016-01-04 04:22:13', 15),
(582, 4162, 35, '2016-01-04 14:32:54', '2016-01-04 08:32:54', 15),
(583, 4164, 2, '2016-01-04 16:31:45', '2016-01-04 10:31:45', 19),
(584, 4165, 39, '2016-01-04 16:33:09', '2016-01-04 10:33:09', 19),
(585, 4169, 36, '2016-01-04 21:37:07', '2016-01-04 15:37:07', 19),
(586, 4171, 32, '2016-01-04 22:38:58', '2016-01-04 16:38:58', 19),
(587, 4177, 38, '2016-01-05 17:01:28', '2016-01-05 11:01:28', 19),
(588, 4187, 3, '2016-01-05 22:20:45', '2016-01-05 16:20:45', 19),
(589, 4188, 15, '2016-01-06 07:44:37', '2016-01-06 01:44:37', 15),
(590, 4194, 38, '2016-01-06 17:13:12', '2016-01-06 11:13:12', 19),
(591, 4200, 32, '2016-01-06 21:19:16', '2016-01-06 15:19:16', 19),
(592, 4201, 26, '2016-01-06 21:28:20', '2016-01-06 15:28:20', 19),
(593, 4202, 0, '2016-01-06 21:41:03', '2016-01-06 15:41:03', 19),
(594, 4212, 0, '2016-01-07 11:34:13', '2016-01-07 05:34:13', 15),
(595, 4215, 35, '2016-01-07 13:52:30', '2016-01-07 07:52:30', 15),
(596, 4216, 32, '2016-01-07 15:55:37', '2016-01-07 09:55:37', 19),
(597, 4221, 32, '2016-01-07 20:18:13', '2016-01-07 14:18:13', 19),
(598, 4222, 27, '2016-01-07 20:21:08', '2016-01-07 14:21:08', 19),
(599, 4226, 38, '2016-01-08 08:43:02', '2016-01-08 02:43:02', 15),
(600, 4253, 32, '2016-01-09 08:03:05', '2016-01-09 02:03:05', 15),
(601, 4259, 3, '2016-01-09 11:10:28', '2016-01-09 05:10:28', 15),
(602, 4264, 15, '2016-01-09 19:01:30', '2016-01-09 13:01:30', 19),
(603, 4273, 32, '2016-01-10 07:36:17', '2016-01-10 01:36:17', 19),
(605, 4283, 13, '2016-01-10 13:55:40', '2016-01-10 07:55:40', 19),
(606, 4284, 8, '2016-01-10 15:45:40', '2016-01-10 09:45:40', 19),
(607, 4289, 3, '2016-01-10 21:19:17', '2016-01-10 15:19:17', 19),
(608, 4322, 0, '2016-01-11 22:24:58', '2016-01-11 16:24:58', 15),
(609, 4345, 0, '2016-01-12 19:39:23', '2016-01-12 13:39:23', 19),
(610, 4348, 42, '2016-01-12 20:49:23', '2016-01-12 14:49:23', 19),
(611, 4349, 21, '2016-01-12 20:51:25', '2016-01-12 14:51:25', 19),
(612, 4355, 13, '2016-01-12 22:00:49', '2016-01-12 16:00:49', 19),
(613, 4383, 43, '2016-01-13 20:21:42', '2016-01-13 14:21:42', 15),
(614, 4392, 8, '2016-01-14 14:54:56', '2016-01-14 08:54:56', 19),
(615, 4393, 32, '2016-01-14 15:05:22', '2016-01-14 09:05:22', 19),
(616, 4402, 2, '2016-01-14 20:01:52', '2016-01-14 14:01:52', 19),
(617, 4403, 33, '2016-01-14 20:35:17', '2016-01-14 14:35:17', 19),
(618, 4423, 0, '2016-01-15 22:26:45', '2016-01-15 16:26:45', 15),
(619, 4435, 21, '2016-01-16 13:58:23', '2016-01-16 07:58:23', 15),
(620, 4438, 8, '2016-01-16 15:33:25', '2016-01-16 09:33:25', 15),
(621, 4445, 31, '2016-01-16 18:54:23', '2016-01-16 12:54:23', 15),
(622, 4449, 44, '2016-01-16 19:46:44', '2016-01-16 13:46:44', 15),
(623, 4452, 3, '2016-01-16 21:02:08', '2016-01-16 15:02:08', 15),
(624, 4459, 4, '2016-01-17 10:59:52', '2016-01-17 04:59:52', 15),
(625, 4461, 8, '2016-01-17 12:29:26', '2016-01-17 06:29:26', 15),
(626, 4466, 39, '2016-01-17 16:05:42', '2016-01-17 10:05:42', 19),
(627, 4467, 32, '2016-01-17 18:44:51', '2016-01-17 12:44:51', 19),
(628, 4469, 13, '2016-01-17 19:32:35', '2016-01-17 13:32:35', 19),
(629, 4470, 0, '2016-01-17 19:36:27', '2016-01-17 13:36:27', 19),
(630, 4474, 19, '2016-01-17 21:18:10', '2016-01-17 15:18:10', 19),
(631, 4485, 21, '2016-01-18 14:25:12', '2016-01-18 08:25:12', 15),
(632, 4491, 2, '2016-01-18 19:00:18', '2016-01-18 13:00:18', 19),
(633, 4494, 4, '2016-01-18 21:25:28', '2016-01-18 15:25:28', 19),
(634, 4509, 45, '2016-01-19 11:37:03', '2016-01-19 05:37:03', 15),
(635, 4512, 39, '2016-01-19 16:03:08', '2016-01-19 10:03:08', 19),
(636, 4526, 8, '2016-01-20 14:52:03', '2016-01-20 08:52:03', 19),
(637, 4527, 35, '2016-01-20 15:21:30', '2016-01-20 09:21:30', 19),
(638, 4531, 31, '2016-01-20 20:03:36', '2016-01-20 14:03:36', 19),
(639, 4557, 43, '2016-01-21 09:17:23', '2016-01-21 03:17:23', 19),
(640, 4579, 37, '2016-01-21 17:52:49', '2016-01-21 11:52:49', 19),
(641, 4582, 4, '2016-01-21 19:14:04', '2016-01-21 13:14:04', 19),
(642, 4605, 31, '2016-01-22 21:28:11', '2016-01-22 15:28:11', 19),
(643, 4617, 5, '2016-01-23 11:37:12', '2016-01-23 05:37:12', 19),
(644, 4624, 45, '2016-01-24 07:26:49', '2016-01-24 01:26:49', 19),
(645, 4629, 13, '2016-01-24 13:44:20', '2016-01-24 07:44:20', 19),
(646, 4635, 33, '2016-01-24 18:48:43', '2016-01-24 12:48:43', 19),
(647, 4656, 40, '2016-01-25 13:03:11', '2016-01-25 07:03:11', 15),
(648, 4660, 28, '2016-01-25 19:03:09', '2016-01-25 13:03:09', 15),
(649, 4664, 39, '2016-01-25 23:34:03', '2016-01-25 17:34:03', 19),
(650, 4668, 28, '2016-01-26 08:39:54', '2016-01-26 02:39:54', 19),
(651, 4679, 40, '2016-01-26 16:27:23', '2016-01-26 10:27:23', 19),
(652, 4682, 46, '2016-01-26 20:05:28', '2016-01-26 14:05:28', 15),
(653, 4687, 47, '2016-01-26 22:53:59', '2016-01-26 16:53:59', 15),
(654, 4695, 8, '2016-01-27 16:48:03', '2016-01-27 10:48:03', 19),
(655, 4702, 31, '2016-01-27 23:22:35', '2016-01-27 17:22:35', 19),
(656, 4703, 10, '2016-01-27 23:23:34', '2016-01-27 17:23:34', 19),
(657, 4704, 42, '2016-01-27 23:24:20', '2016-01-27 17:24:20', 19),
(658, 4705, 36, '2016-01-27 23:25:18', '2016-01-27 17:25:18', 19),
(659, 4734, 5, '2016-01-29 17:29:50', '2016-01-29 11:29:50', 19),
(660, 4742, 40, '2016-01-30 14:53:45', '2016-01-30 08:53:45', 19),
(662, 4743, 0, '2016-01-30 15:35:21', '2016-01-30 09:35:21', 19),
(663, 4757, 27, '2016-01-31 16:36:56', '2016-01-31 10:36:56', 15),
(664, 4758, 39, '2016-01-31 16:40:24', '2016-01-31 10:40:24', 15),
(665, 4762, 45, '2016-01-31 20:04:42', '2016-01-31 14:04:42', 15),
(666, 4763, 5, '2016-01-31 20:21:31', '2016-01-31 14:21:31', 15),
(667, 4760, 2, '2016-01-31 20:27:57', '2016-01-31 14:27:57', 15),
(668, 4782, 32, '2016-02-01 22:15:20', '2016-02-01 16:15:20', 15),
(669, 4783, 13, '2016-02-02 07:44:36', '2016-02-02 01:44:36', 19),
(670, 4789, 39, '2016-02-02 16:06:11', '2016-02-02 10:06:11', 19),
(671, 4791, 36, '2016-02-02 20:11:41', '2016-02-02 14:11:41', 19),
(672, 4792, 31, '2016-02-02 20:13:47', '2016-02-02 14:13:47', 19),
(673, 4794, 37, '2016-02-02 21:19:34', '2016-02-02 15:19:34', 19),
(674, 4803, 13, '2016-02-03 13:52:27', '2016-02-03 07:52:27', 19),
(675, 4816, 2, '2016-02-04 19:13:36', '2016-02-04 13:13:36', 15),
(676, 4817, 36, '2016-02-04 19:21:46', '2016-02-04 13:21:46', 15),
(677, 4818, 46, '2016-02-04 19:22:51', '2016-02-04 13:22:51', 15),
(678, 4819, 27, '2016-02-04 19:47:44', '2016-02-04 13:47:44', 15),
(679, 4820, 44, '2016-02-04 20:48:29', '2016-02-04 14:48:29', 15),
(680, 4839, 5, '2016-02-05 18:18:45', '2016-02-05 12:18:45', 15),
(681, 4841, 46, '2016-02-05 19:00:05', '2016-02-05 13:00:05', 15),
(682, 4842, 13, '2016-02-05 19:01:00', '2016-02-05 13:01:00', 15),
(683, 4844, 24, '2016-02-05 20:40:58', '2016-02-05 14:40:58', 15),
(684, 4845, 36, '2016-02-05 20:59:57', '2016-02-05 14:59:57', 15),
(685, 4856, 2, '2016-02-06 16:04:52', '2016-02-06 10:04:52', 15),
(686, 4881, 5, '2016-02-07 21:54:05', '2016-02-07 15:54:05', 15),
(687, 4885, 37, '2016-02-08 07:57:42', '2016-02-08 01:57:42', 15),
(688, 4900, 42, '2016-02-08 21:25:16', '2016-02-08 15:25:16', 15),
(689, 4901, 32, '2016-02-08 22:03:13', '2016-02-08 16:03:13', 15),
(690, 4902, 32, '2016-02-08 22:09:17', '2016-02-08 16:09:17', 15),
(691, 4904, 13, '2016-02-09 07:47:17', '2016-02-09 01:47:17', 19),
(692, 4916, 37, '2016-02-09 20:43:16', '2016-02-09 14:43:16', 20),
(693, 4917, 26, '2016-02-09 20:44:06', '2016-02-09 14:44:06', 20),
(694, 4918, 31, '2016-02-09 20:46:00', '2016-02-09 14:46:00', 20),
(695, 4919, 24, '2016-02-09 20:48:01', '2016-02-09 14:48:01', 20),
(696, 4921, 46, '2016-02-09 20:53:17', '2016-02-09 14:53:17', 20),
(697, 4922, 42, '2016-02-09 20:57:27', '2016-02-09 14:57:27', 20),
(698, 4923, 27, '2016-02-09 21:11:04', '2016-02-09 15:11:04', 15),
(699, 4924, 48, '2016-02-09 21:11:59', '2016-02-09 15:11:59', 15),
(700, 4930, 40, '2016-02-10 10:10:47', '2016-02-10 04:10:47', 15),
(701, 4933, 33, '2016-02-10 14:27:49', '2016-02-10 08:27:49', 15),
(702, 4934, 40, '2016-02-10 14:32:30', '2016-02-10 08:32:30', 15),
(703, 4935, 10, '2016-02-10 14:54:34', '2016-02-10 08:54:34', 15),
(704, 4936, 2, '2016-02-10 15:51:36', '2016-02-10 09:51:36', 15),
(705, 4941, 39, '2016-02-10 19:22:15', '2016-02-10 13:22:15', 15),
(706, 4942, 21, '2016-02-10 20:11:41', '2016-02-10 14:11:41', 15),
(707, 4943, 5, '2016-02-10 20:34:42', '2016-02-10 14:34:42', 15),
(708, 4946, 32, '2016-02-11 08:51:35', '2016-02-11 02:51:35', 15),
(709, 4964, 13, '2016-02-11 19:50:04', '2016-02-11 13:50:04', 19),
(710, 4965, 26, '2016-02-11 20:02:46', '2016-02-11 14:02:46', 19),
(711, 4955, 2, '2016-02-11 20:11:27', '2016-02-11 14:11:27', 19),
(712, 4977, 32, '2016-02-11 23:31:57', '2016-02-11 17:31:57', 19),
(713, 4978, 32, '2016-02-11 23:43:58', '2016-02-11 17:43:58', 19),
(714, 5003, 13, '2016-02-12 15:46:55', '2016-02-12 09:46:55', 19),
(715, 5007, 21, '2016-02-12 18:52:45', '2016-02-12 12:52:45', 19),
(716, 5027, 49, '2016-02-13 10:30:09', '2016-02-13 04:30:09', 15),
(717, 5037, 2, '2016-02-13 16:12:35', '2016-02-13 10:12:35', 19),
(718, 5046, 40, '2016-02-13 20:31:42', '2016-02-13 14:31:42', 19),
(719, 5047, 39, '2016-02-13 20:58:27', '2016-02-13 14:58:27', 19),
(720, 5048, 35, '2016-02-13 21:25:08', '2016-02-13 15:25:08', 19),
(721, 5063, 0, '2016-02-14 12:49:13', '2016-02-14 06:49:13', 19),
(722, 5064, 0, '2016-02-14 15:36:25', '2016-02-14 09:36:25', 19),
(723, 5069, 16, '2016-02-14 21:49:51', '2016-02-14 15:49:51', 19),
(724, 5070, 32, '2016-02-14 21:50:33', '2016-02-14 15:50:33', 19),
(725, 5075, 32, '2016-02-15 07:19:19', '2016-02-15 01:19:19', 19),
(726, 5077, 38, '2016-02-15 10:16:27', '2016-02-15 04:16:27', 19),
(727, 5087, 26, '2016-02-15 20:25:10', '2016-02-15 14:25:10', 15),
(728, 5096, 32, '2016-02-16 10:22:44', '2016-02-16 04:22:44', 19),
(729, 5103, 49, '2016-02-16 15:06:34', '2016-02-16 09:06:34', 15),
(730, 5128, 2, '2016-02-17 20:31:24', '2016-02-17 14:31:24', 19),
(731, 5129, 5, '2016-02-17 20:32:22', '2016-02-17 14:32:22', 19),
(732, 5134, 35, '2016-02-17 21:48:08', '2016-02-17 15:48:08', 19),
(733, 5206, 39, '2016-02-19 20:54:31', '2016-02-19 14:54:31', 19),
(734, 5236, 19, '2016-02-20 09:27:55', '2016-02-20 03:27:55', 19),
(735, 5263, 5, '2016-02-20 16:29:46', '2016-02-20 10:29:46', 19),
(736, 5348, 2, '2016-02-22 17:47:26', '2016-02-22 11:47:26', 19),
(737, 5350, 16, '2016-02-23 13:16:14', '2016-02-23 07:16:14', 19),
(738, 5353, 33, '2016-02-23 16:42:47', '2016-02-23 10:42:47', 19),
(739, 5357, 35, '2016-02-23 21:09:46', '2016-02-23 15:09:46', 19),
(740, 5363, 39, '2016-02-23 22:16:21', '2016-02-23 16:16:21', 19),
(741, 5367, 22, '2016-02-24 13:59:55', '2016-02-24 07:59:55', 19),
(742, 5374, 38, '2016-02-24 19:16:46', '2016-02-24 13:16:46', 19),
(743, 5382, 37, '2016-02-25 09:37:21', '2016-02-25 03:37:21', 19),
(745, 5384, 21, '2016-02-25 09:47:29', '2016-02-25 03:47:29', 19),
(746, 5391, 2, '2016-02-25 17:44:06', '2016-02-25 11:44:06', 19),
(747, 5392, 2, '2016-02-25 17:57:48', '2016-02-25 11:57:48', 19),
(748, 5442, 2, '2016-02-27 17:19:48', '2016-02-27 11:19:48', 19),
(749, 5458, 8, '2016-02-28 14:47:34', '2016-02-28 08:47:34', 19),
(750, 5460, 38, '2016-02-28 15:30:41', '2016-02-28 09:30:41', 19),
(751, 5461, 37, '2016-02-28 16:43:09', '2016-02-28 10:43:09', 19),
(752, 5465, 21, '2016-02-28 21:38:03', '2016-02-28 15:38:03', 19),
(753, 5477, 8, '2016-02-29 19:56:39', '2016-02-29 13:56:39', 19),
(754, 5478, 37, '2016-02-29 21:04:45', '2016-02-29 15:04:45', 19),
(755, 5479, 37, '2016-02-29 22:04:14', '2016-02-29 16:04:14', 19),
(756, 5480, 37, '2016-02-29 22:11:03', '2016-02-29 16:11:03', 19),
(757, 5485, 8, '2016-03-01 14:38:49', '2016-03-01 08:38:49', 19),
(758, 5490, 16, '2016-03-01 21:37:36', '2016-03-01 15:37:36', 19),
(759, 5491, 24, '2016-03-01 21:38:52', '2016-03-01 15:38:52', 19),
(760, 5492, 18, '2016-03-01 21:40:20', '2016-03-01 15:40:20', 19),
(761, 5497, 2, '2016-03-01 22:21:43', '2016-03-01 16:21:43', 19),
(762, 5500, 33, '2016-03-01 23:06:44', '2016-03-01 17:06:44', 19),
(763, 5504, 33, '2016-03-02 14:51:31', '2016-03-02 08:51:31', 17),
(764, 5514, 21, '2016-03-02 22:09:37', '2016-03-02 16:09:37', 17),
(765, 5521, 21, '2016-03-03 07:57:37', '2016-03-03 01:57:37', 17),
(766, 5533, 2, '2016-03-03 15:08:16', '2016-03-03 09:08:16', 17),
(767, 5534, 37, '2016-03-03 15:09:00', '2016-03-03 09:09:00', 17),
(768, 5538, 37, '2016-03-03 19:18:46', '2016-03-03 13:18:46', 19),
(769, 5546, 13, '2016-03-03 20:16:22', '2016-03-03 14:16:22', 19),
(770, 5580, 33, '2016-03-04 21:03:15', '2016-03-04 15:03:15', 17),
(771, 5596, 17, '2016-03-05 12:46:32', '2016-03-05 06:46:32', 19),
(772, 5597, 8, '2016-03-05 14:16:15', '2016-03-05 08:16:15', 19),
(773, 5608, 0, '2016-03-05 21:09:56', '2016-03-05 15:09:56', 17),
(774, 5622, 32, '2016-03-06 13:57:14', '2016-03-06 07:57:14', 19),
(775, 5623, 32, '2016-03-06 14:06:19', '2016-03-06 08:06:19', 19),
(776, 5625, 8, '2016-03-06 14:34:32', '2016-03-06 08:34:32', 19),
(777, 5637, 13, '2016-03-07 09:54:01', '2016-03-07 03:54:01', 17),
(778, 5638, 13, '2016-03-07 09:54:01', '2016-03-07 03:54:01', 17),
(779, 5639, 13, '2016-03-07 09:56:37', '2016-03-07 03:56:37', 17),
(780, 5648, 38, '2016-03-07 19:44:04', '2016-03-07 13:44:04', 19),
(781, 5651, 37, '2016-03-08 07:36:00', '2016-03-08 01:36:00', 19),
(782, 5652, 13, '2016-03-08 07:52:51', '2016-03-08 01:52:51', 19),
(783, 5654, 40, '2016-03-08 12:54:11', '2016-03-08 06:54:11', 19),
(784, 5656, 21, '2016-03-08 17:08:18', '2016-03-08 11:08:18', 17);
INSERT INTO `stuff_order_info` (`stuff_order_id`, `order_info_id`, `stuff_info_id`, `doc`, `dom`, `creator`) VALUES
(785, 5658, 21, '2016-03-08 20:10:04', '2016-03-08 14:10:04', 17),
(786, 5659, 2, '2016-03-08 20:16:08', '2016-03-08 14:16:08', 17),
(787, 5660, 16, '2016-03-08 20:17:59', '2016-03-08 14:17:59', 17),
(788, 5672, 38, '2016-03-09 15:22:15', '2016-03-09 09:22:15', 19),
(789, 5676, 0, '2016-03-09 20:55:57', '2016-03-09 14:55:57', 17),
(790, 5677, 32, '2016-03-09 21:33:24', '2016-03-09 15:33:24', 17),
(791, 5678, 13, '2016-03-09 21:35:11', '2016-03-09 15:35:11', 17),
(792, 5679, 0, '2016-03-09 21:38:50', '2016-03-09 15:38:50', 17),
(793, 5690, 38, '2016-03-10 14:42:53', '2016-03-10 08:42:53', 17),
(794, 5691, 8, '2016-03-10 15:19:25', '2016-03-10 09:19:25', 17),
(795, 5701, 10, '2016-03-10 21:22:15', '2016-03-10 15:22:15', 17),
(796, 5704, 2, '2016-03-10 22:22:51', '2016-03-10 16:22:51', 17),
(797, 5705, 3, '2016-03-10 22:27:06', '2016-03-10 16:27:06', 17),
(798, 5706, 3, '2016-03-10 22:37:47', '2016-03-10 16:37:47', 17),
(799, 5710, 16, '2016-03-10 23:13:49', '2016-03-10 17:13:49', 17),
(800, 5730, 5, '2016-03-11 15:03:21', '2016-03-11 09:03:21', 19),
(801, 5759, 35, '2016-03-12 14:18:09', '2016-03-12 08:18:09', 17),
(802, 5760, 8, '2016-03-12 15:09:22', '2016-03-12 09:09:22', 17),
(803, 5762, 5, '2016-03-12 16:49:05', '2016-03-12 10:49:05', 17),
(804, 5766, 0, '2016-03-12 19:52:06', '2016-03-12 13:52:06', 17),
(805, 5770, 16, '2016-03-12 22:11:12', '2016-03-12 16:11:12', 17),
(806, 5781, 8, '2016-03-13 14:42:50', '2016-03-13 08:42:50', 17),
(807, 5784, 40, '2016-03-13 18:10:06', '2016-03-13 12:10:06', 17),
(808, 5788, 32, '2016-03-13 22:22:43', '2016-03-13 16:22:43', 17),
(809, 5789, 10, '2016-03-13 22:23:37', '2016-03-13 16:23:37', 17);

-- --------------------------------------------------------

--
-- Table structure for table `table_info`
--

CREATE TABLE `table_info` (
  `table_id` int(11) NOT NULL,
  `table_name` varchar(100) NOT NULL,
  `table_number` varchar(50) NOT NULL,
  `capacity` int(3) NOT NULL,
  `active` varchar(50) NOT NULL,
  `status` varchar(100) NOT NULL,
  `creator` int(20) NOT NULL,
  `xaxis_one` varchar(5) NOT NULL,
  `yaxis_one` varchar(5) NOT NULL,
  `xaxis_two` varchar(5) NOT NULL,
  `yaxis_two` varchar(5) NOT NULL,
  `back_color` varchar(10) NOT NULL,
  `font_color` varchar(10) NOT NULL,
  `border_color` varchar(10) NOT NULL,
  `border_width` int(3) NOT NULL,
  `border_radius` int(3) NOT NULL,
  `doc` datetime NOT NULL,
  `dom` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_info`
--

INSERT INTO `table_info` (`table_id`, `table_name`, `table_number`, `capacity`, `active`, `status`, `creator`, `xaxis_one`, `yaxis_one`, `xaxis_two`, `yaxis_two`, `back_color`, `font_color`, `border_color`, `border_width`, `border_radius`, `doc`, `dom`) VALUES
(3, 'KidzVilla-03', '03', 40, 'YES', 'Available', 14, '116px', '212px', '156px', '89px', '#000000', '#ffffff', '#400080', 3, 6, '2015-10-03 00:00:00', '2020-01-02 11:23:42'),
(7, 'KidzVilla-04', '04', 40, 'YES', 'Available', 14, '179px', '483px', '256px', '79px', '#ffffff', '#000000', '#000000', 3, 6, '2015-10-03 00:00:00', '2020-01-02 11:24:05'),
(15, 'KidzVilla-01', '01', 40, 'YES', 'Available', 12, '5px', '9px', '230px', '87px', '#ff0000', '#000000', '#400080', 3, 6, '2019-12-30 00:00:00', '2020-01-02 11:23:24'),
(16, 'KidzVilla-02', '02', 40, 'YES', 'Available', 12, '113px', '35px', '130px', '80px', '#000000', '#ffffff', '#400080', 3, 6, '2019-12-30 00:00:00', '2020-01-02 11:23:33'),
(17, 'KidzVilla-05', '05', 40, 'YES', 'Available', 12, '221px', '10px', '94px', '79px', '#000000', '#ffffff', '#000000', 0, 0, '2019-12-30 00:00:00', '2020-01-02 11:24:13'),
(18, 'KidzVilla-06', '06', 40, 'YES', 'Available', 12, '44px', '383px', '96px', '80px', '#000000', '#ffffff', '#000000', 0, 0, '2019-12-30 00:00:00', '2020-01-02 11:24:21'),
(19, 'KidzVilla-07', '07', 40, 'YES', 'Available', 12, '47px', '491px', '118px', '74px', '#000000', '#ffffff', '#000000', 0, 0, '2019-12-30 00:00:00', '2020-01-02 11:24:30'),
(20, 'KidzVilla-08', '08', 40, 'YES', 'Available', 12, '53px', '623px', '92px', '117px', '#000000', '#ffffff', '#000000', 0, 0, '2019-12-30 00:00:00', '2020-01-02 11:24:51'),
(21, 'KidzVilla-Large', '08', 10, 'YES', 'Available', 12, '268px', '459px', '282px', '87px', '#000000', '#ffffff', '#000000', 0, 0, '2019-12-30 00:00:00', '2019-12-31 09:38:38'),
(22, 'KidzVilla-08', '08', 80, 'YES', 'Available', 12, '215px', '118px', '211px', '141px', '#000000', '#ffffff', '#000000', 0, 0, '2019-12-30 00:00:00', '2020-01-02 11:27:39');

-- --------------------------------------------------------

--
-- Table structure for table `temp_preparation_option`
--

CREATE TABLE `temp_preparation_option` (
  `temp_prep_option_id` int(11) NOT NULL,
  `product_id` int(20) NOT NULL,
  `order_id` int(20) NOT NULL,
  `pre_option_id` int(20) NOT NULL,
  `sale_details_id` int(30) NOT NULL,
  `doc` varchar(16) NOT NULL,
  `dom` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `creator` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_preparation_option`
--

INSERT INTO `temp_preparation_option` (`temp_prep_option_id`, `product_id`, `order_id`, `pre_option_id`, `sale_details_id`, `doc`, `dom`, `creator`) VALUES
(1, 122, 5106, 1, 12889, '2016-02-16', '2016-02-16 10:54:04', 15),
(2, 122, 5106, 1, 12889, '2016-02-16', '2016-02-16 10:54:04', 15),
(3, 122, 5105, 1, 12890, '2016-02-16', '2016-02-16 11:26:04', 15),
(4, 122, 5105, 1, 12890, '2016-02-16', '2016-02-16 11:26:04', 15),
(5, 122, 5105, 1, 12890, '2016-02-16', '2016-02-16 11:26:04', 15);

-- --------------------------------------------------------

--
-- Table structure for table `usage_resource_info`
--

CREATE TABLE `usage_resource_info` (
  `usage_infoID` int(11) NOT NULL,
  `product_id` int(10) NOT NULL,
  `category` int(4) NOT NULL,
  `amount` int(7) NOT NULL,
  `description` varchar(200) NOT NULL,
  `creator` int(8) NOT NULL,
  `doc` date NOT NULL,
  `dom` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `username` varchar(250) COLLATE utf8_bin NOT NULL,
  `password` varchar(250) COLLATE utf8_bin NOT NULL,
  `hotel_id` int(3) NOT NULL,
  `user_type` varchar(250) COLLATE utf8_bin NOT NULL,
  `user_full_name` varchar(250) COLLATE utf8_bin NOT NULL,
  `user_address` varchar(250) COLLATE utf8_bin NOT NULL,
  `email` varchar(250) COLLATE utf8_bin NOT NULL,
  `activated` tinyint(1) NOT NULL DEFAULT 1,
  `banned` tinyint(1) NOT NULL DEFAULT 0,
  `ban_reason` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `new_password_key` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  `new_password_requested` datetime DEFAULT NULL,
  `new_email` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  `new_email_key` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  `last_ip` varchar(250) COLLATE utf8_bin NOT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `hotel_id`, `user_type`, `user_full_name`, `user_address`, `email`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`) VALUES
(12, 'kidz_admin', '$2a$08$TnEEan0qlOY7KJE4rbR.p.CyI1eln41s7hNuwH1XSLwmCn.SFqA32', 1, 'superadmin', 'Nazmul Hussain', 'IT Lab Solutions', '65494949', 1, 0, NULL, NULL, NULL, NULL, NULL, '118.179.77.178', '2020-01-04 10:06:10', '2015-02-03 11:13:32', '2020-01-04 10:06:10');

-- --------------------------------------------------------

--
-- Table structure for table `user_autologin`
--

CREATE TABLE `user_autologin` (
  `key_id` char(32) COLLATE utf8_bin NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE `user_profiles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `country` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `user_profiles`
--

INSERT INTO `user_profiles` (`id`, `user_id`, `country`, `website`) VALUES
(1, 12, NULL, NULL),
(2, 13, NULL, NULL),
(3, 14, NULL, NULL),
(4, 15, NULL, NULL),
(5, 16, NULL, NULL),
(6, 17, NULL, NULL),
(7, 18, NULL, NULL),
(8, 19, NULL, NULL),
(9, 20, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_setup`
--

CREATE TABLE `user_setup` (
  `userID` int(11) NOT NULL,
  `hotelID` int(5) NOT NULL,
  `userTypeID` int(2) NOT NULL,
  `userName` varchar(80) NOT NULL,
  `userContactAddress` varchar(200) NOT NULL,
  `userContactNo` varchar(20) NOT NULL,
  `DOC` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DOM` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_type_setup`
--

CREATE TABLE `user_type_setup` (
  `userTypeID` int(11) NOT NULL,
  `hotelID` int(5) NOT NULL,
  `userTypeName` varchar(20) NOT NULL,
  `userTypeDescription` varchar(200) NOT NULL,
  `userLevel` varchar(50) NOT NULL,
  `DOC` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DOM` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_table`
--
ALTER TABLE `account_table`
  ADD PRIMARY KEY (`ref`);

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`actLogID`);

--
-- Indexes for table `agents`
--
ALTER TABLE `agents`
  ADD PRIMARY KEY (`agent_id`);

--
-- Indexes for table `agent_total`
--
ALTER TABLE `agent_total`
  ADD PRIMARY KEY (`agent_total_id`),
  ADD UNIQUE KEY `uniq_agent` (`reservation_id`,`agent_id`);

--
-- Indexes for table `cashbox_info`
--
ALTER TABLE `cashbox_info`
  ADD PRIMARY KEY (`cashbox_id`);

--
-- Indexes for table `cashbox_option`
--
ALTER TABLE `cashbox_option`
  ADD PRIMARY KEY (`cashbox_id`);

--
-- Indexes for table `catering_info`
--
ALTER TABLE `catering_info`
  ADD PRIMARY KEY (`catering_id`);

--
-- Indexes for table `catering_log`
--
ALTER TABLE `catering_log`
  ADD PRIMARY KEY (`catering_log_id`);

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`session_id`);

--
-- Indexes for table `client_info`
--
ALTER TABLE `client_info`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`country_id`);

--
-- Indexes for table `discount_client`
--
ALTER TABLE `discount_client`
  ADD PRIMARY KEY (`discount_id`);

--
-- Indexes for table `employee_salary_log`
--
ALTER TABLE `employee_salary_log`
  ADD PRIMARY KEY (`salary_log_id`);

--
-- Indexes for table `entertainment_info`
--
ALTER TABLE `entertainment_info`
  ADD PRIMARY KEY (`entertainment_id`);

--
-- Indexes for table `entertainment_order_info`
--
ALTER TABLE `entertainment_order_info`
  ADD PRIMARY KEY (`entertainment_order_id`);

--
-- Indexes for table `extra_charge`
--
ALTER TABLE `extra_charge`
  ADD PRIMARY KEY (`extra_charge_id`);

--
-- Indexes for table `extra_service`
--
ALTER TABLE `extra_service`
  ADD PRIMARY KEY (`extra_service_id`);

--
-- Indexes for table `hotel_setup`
--
ALTER TABLE `hotel_setup`
  ADD PRIMARY KEY (`hotel_id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `name_title`
--
ALTER TABLE `name_title`
  ADD PRIMARY KEY (`name_title_id`);

--
-- Indexes for table `order_cancel_reason`
--
ALTER TABLE `order_cancel_reason`
  ADD PRIMARY KEY (`reason_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`order_details_id`);

--
-- Indexes for table `order_info`
--
ALTER TABLE `order_info`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_reference_table`
--
ALTER TABLE `order_reference_table`
  ADD PRIMARY KEY (`reference_id`);

--
-- Indexes for table `package_info`
--
ALTER TABLE `package_info`
  ADD PRIMARY KEY (`package_info_id`);

--
-- Indexes for table `payment_history`
--
ALTER TABLE `payment_history`
  ADD PRIMARY KEY (`payment_history_id`);

--
-- Indexes for table `prep_options`
--
ALTER TABLE `prep_options`
  ADD PRIMARY KEY (`prep_options_id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `product_info`
--
ALTER TABLE `product_info`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_unit_name`
--
ALTER TABLE `product_unit_name`
  ADD PRIMARY KEY (`unit_name_id`);

--
-- Indexes for table `rate_setup`
--
ALTER TABLE `rate_setup`
  ADD PRIMARY KEY (`rate_id`),
  ADD UNIQUE KEY `unik` (`main_rate_typ`,`rate_type_id`,`room_typ_id`,`class_id`,`status`);

--
-- Indexes for table `reservation_new`
--
ALTER TABLE `reservation_new`
  ADD PRIMARY KEY (`reservation_id`);

--
-- Indexes for table `reserved_room`
--
ALTER TABLE `reserved_room`
  ADD PRIMARY KEY (`reserved_room_id`);

--
-- Indexes for table `restaurant_booking`
--
ALTER TABLE `restaurant_booking`
  ADD PRIMARY KEY (`res_booking_id`);

--
-- Indexes for table `restaurant_booking_menu`
--
ALTER TABLE `restaurant_booking_menu`
  ADD PRIMARY KEY (`booking_menu_id`);

--
-- Indexes for table `restaurant_booking_other`
--
ALTER TABLE `restaurant_booking_other`
  ADD PRIMARY KEY (`booking_other_id`);

--
-- Indexes for table `restaurant_expense`
--
ALTER TABLE `restaurant_expense`
  ADD PRIMARY KEY (`restaurant_expense_id`);

--
-- Indexes for table `restaurant_transaction`
--
ALTER TABLE `restaurant_transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `rest_access_auth`
--
ALTER TABLE `rest_access_auth`
  ADD PRIMARY KEY (`access_auth_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `room_type`
--
ALTER TABLE `room_type`
  ADD PRIMARY KEY (`room_typ_id`),
  ADD UNIQUE KEY `uniq_name` (`room_typ_name`,`status`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `service_in_room`
--
ALTER TABLE `service_in_room`
  ADD PRIMARY KEY (`serv_room_id`);

--
-- Indexes for table `service_typ`
--
ALTER TABLE `service_typ`
  ADD PRIMARY KEY (`service_typ_id`);

--
-- Indexes for table `stuff_info`
--
ALTER TABLE `stuff_info`
  ADD PRIMARY KEY (`stuff_id`);

--
-- Indexes for table `stuff_order_info`
--
ALTER TABLE `stuff_order_info`
  ADD PRIMARY KEY (`stuff_order_id`);

--
-- Indexes for table `table_info`
--
ALTER TABLE `table_info`
  ADD PRIMARY KEY (`table_id`);

--
-- Indexes for table `temp_preparation_option`
--
ALTER TABLE `temp_preparation_option`
  ADD PRIMARY KEY (`temp_prep_option_id`);

--
-- Indexes for table `usage_resource_info`
--
ALTER TABLE `usage_resource_info`
  ADD PRIMARY KEY (`usage_infoID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_autologin`
--
ALTER TABLE `user_autologin`
  ADD PRIMARY KEY (`key_id`,`user_id`);

--
-- Indexes for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_setup`
--
ALTER TABLE `user_setup`
  ADD PRIMARY KEY (`userID`);

--
-- Indexes for table `user_type_setup`
--
ALTER TABLE `user_type_setup`
  ADD PRIMARY KEY (`userTypeID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_table`
--
ALTER TABLE `account_table`
  MODIFY `ref` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `actLogID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `agents`
--
ALTER TABLE `agents`
  MODIFY `agent_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `agent_total`
--
ALTER TABLE `agent_total`
  MODIFY `agent_total_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cashbox_info`
--
ALTER TABLE `cashbox_info`
  MODIFY `cashbox_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `cashbox_option`
--
ALTER TABLE `cashbox_option`
  MODIFY `cashbox_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `catering_info`
--
ALTER TABLE `catering_info`
  MODIFY `catering_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `catering_log`
--
ALTER TABLE `catering_log`
  MODIFY `catering_log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `client_info`
--
ALTER TABLE `client_info`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=240;

--
-- AUTO_INCREMENT for table `discount_client`
--
ALTER TABLE `discount_client`
  MODIFY `discount_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `employee_salary_log`
--
ALTER TABLE `employee_salary_log`
  MODIFY `salary_log_id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `entertainment_info`
--
ALTER TABLE `entertainment_info`
  MODIFY `entertainment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `entertainment_order_info`
--
ALTER TABLE `entertainment_order_info`
  MODIFY `entertainment_order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `extra_charge`
--
ALTER TABLE `extra_charge`
  MODIFY `extra_charge_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `extra_service`
--
ALTER TABLE `extra_service`
  MODIFY `extra_service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hotel_setup`
--
ALTER TABLE `hotel_setup`
  MODIFY `hotel_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `name_title`
--
ALTER TABLE `name_title`
  MODIFY `name_title_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `order_cancel_reason`
--
ALTER TABLE `order_cancel_reason`
  MODIFY `reason_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `order_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=176;

--
-- AUTO_INCREMENT for table `order_info`
--
ALTER TABLE `order_info`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- AUTO_INCREMENT for table `order_reference_table`
--
ALTER TABLE `order_reference_table`
  MODIFY `reference_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- AUTO_INCREMENT for table `package_info`
--
ALTER TABLE `package_info`
  MODIFY `package_info_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `payment_history`
--
ALTER TABLE `payment_history`
  MODIFY `payment_history_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prep_options`
--
ALTER TABLE `prep_options`
  MODIFY `prep_options_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `product_info`
--
ALTER TABLE `product_info`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=302;

--
-- AUTO_INCREMENT for table `product_unit_name`
--
ALTER TABLE `product_unit_name`
  MODIFY `unit_name_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `rate_setup`
--
ALTER TABLE `rate_setup`
  MODIFY `rate_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reservation_new`
--
ALTER TABLE `reservation_new`
  MODIFY `reservation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `reserved_room`
--
ALTER TABLE `reserved_room`
  MODIFY `reserved_room_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `restaurant_booking`
--
ALTER TABLE `restaurant_booking`
  MODIFY `res_booking_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `restaurant_booking_menu`
--
ALTER TABLE `restaurant_booking_menu`
  MODIFY `booking_menu_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `restaurant_booking_other`
--
ALTER TABLE `restaurant_booking_other`
  MODIFY `booking_other_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `restaurant_expense`
--
ALTER TABLE `restaurant_expense`
  MODIFY `restaurant_expense_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `restaurant_transaction`
--
ALTER TABLE `restaurant_transaction`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `rest_access_auth`
--
ALTER TABLE `rest_access_auth`
  MODIFY `access_auth_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `room_type`
--
ALTER TABLE `room_type`
  MODIFY `room_typ_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=310;

--
-- AUTO_INCREMENT for table `service_in_room`
--
ALTER TABLE `service_in_room`
  MODIFY `serv_room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=197;

--
-- AUTO_INCREMENT for table `service_typ`
--
ALTER TABLE `service_typ`
  MODIFY `service_typ_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `stuff_info`
--
ALTER TABLE `stuff_info`
  MODIFY `stuff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `stuff_order_info`
--
ALTER TABLE `stuff_order_info`
  MODIFY `stuff_order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=810;

--
-- AUTO_INCREMENT for table `table_info`
--
ALTER TABLE `table_info`
  MODIFY `table_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `temp_preparation_option`
--
ALTER TABLE `temp_preparation_option`
  MODIFY `temp_prep_option_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `usage_resource_info`
--
ALTER TABLE `usage_resource_info`
  MODIFY `usage_infoID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `user_profiles`
--
ALTER TABLE `user_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_setup`
--
ALTER TABLE `user_setup`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_type_setup`
--
ALTER TABLE `user_type_setup`
  MODIFY `userTypeID` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
